# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Shared markup colorization helpers for parity table tooltips."""

from __future__ import annotations

import html as html_lib
import re
from pathlib import Path
from typing import Any

import yaml

# MiniMax M3 prefixes every structural tag with the `]<]minimax[>[` namespace
# special token (tokenizer id 200058), e.g. `]<]minimax[>[<tool_call>`. It must
# be matched as one whole token *before* the generic `<...>` rule, otherwise the
# inner `<]minimax[>` is mis-split into a red orphan tag with stray `]`/`[`
# around it. The token carries no open/close semantics, so it is colored as
# muted namespace decoration (`tt-ns`) rather than a paired or orphan tag.
_MINIMAX_NS_TOKEN = "]<]minimax[>["
_NS_CLASS = "tt-ns"

# Matches the MiniMax namespace token (first, so it wins over `<...>`), then
# `<...>`, then the Mistral-style `[NAME]`/`[/NAME]` form.
# Brackets only match ALL-CAPS-underscore names so JSON arrays
# (e.g. `[{...}]`, `[1, 2]`) don't get false-matched as tags.
_TAG_RE = re.compile(r"\]<\]minimax\[>\[|<[^<>]+>|\[/?[A-Z][A-Z0-9_]*\]")

# Two coloring schemes share one cycling palette:
#   * Paired open/close: every matched pair gets a *fresh* palette index, so
#     two `<tool_call>...</tool_call>` instances in the same input render as
#     two different colors.
#   * Singletons (e.g. harmony's `<|channel|>` section markers): stable
#     by-role color so all `<|channel|>` tokens share one class everywhere.
_PAIRED_PALETTE_SIZE = 8
_color_seq = 0
_singleton_classes: dict[str, str] = {}


def _next_color_class() -> str:
    global _color_seq
    cls = f"tt-c{_color_seq % _PAIRED_PALETTE_SIZE}"
    _color_seq += 1
    return cls


def _singleton_class_for(name: str) -> str:
    cls = _singleton_classes.get(name)
    if cls is None:
        cls = _next_color_class()
        _singleton_classes[name] = cls
    return cls


_PIPES = ("|", "｜")  # ASCII and FULLWIDTH VERTICAL LINE (U+FF5C)
_BEGIN_SUFFIXES = (
    "_begin",
    "▁begin",
)  # ASCII underscore and LOWER ONE EIGHTH BLOCK (U+2581)
_END_SUFFIXES = ("_end", "▁end")

# Harmony (gpt-oss) tokens are linear state-machine delimiters. Turn-boundary
# tokens form pseudo-pairs: `<|start|>` opens a turn; `<|end|>`, `<|return|>`,
# or `<|call|>` closes it. Each closer flavor gets its own paired color so a
# tool call turn (start -> call) is visually distinct from a normal turn
# (start -> end) or a final turn (start -> return). Section markers stay as
# same-colored singletons.
_HARMONY_TURN_OPEN = "start"
_HARMONY_TURN_CLOSE = frozenset({"end", "return", "call"})
_HARMONY_SECTION_MARKERS = frozenset({"channel", "constrain", "message"})
_HARMONY_TOKEN_RE = re.compile(r"<\|([A-Za-z_]+)\|>")
_HARMONY_SEGMENT_CLASS = {
    "start": "tt-h-start",
    "channel": "tt-h-channel",
    "constrain": "tt-h-constrain",
    "message": "tt-h-message",
    "end": "tt-h-stop",
    "return": "tt-h-stop",
    "call": "tt-h-call",
}


def _colorize_harmony(text: str) -> str:
    """Color Harmony's linear token segments as `<|token|>related-text`.

    Harmony is not paired XML. Tokens such as `<|channel|>` and `<|message|>`
    introduce the header/content span that follows, so each special token is
    grouped with text up to the next Harmony token.
    """
    pieces: list[str] = []
    last = 0
    for m in _HARMONY_TOKEN_RE.finditer(text):
        if m.start() > last:
            pieces.append(html_lib.escape(text[last : m.start()]))
        token_name = m.group(1)
        if token_name in _HARMONY_TURN_CLOSE:
            end = m.end()
        else:
            next_m = _HARMONY_TOKEN_RE.search(text, m.end())
            end = next_m.start() if next_m else len(text)
        cls = _HARMONY_SEGMENT_CLASS.get(token_name, "tt-h-other")
        token = html_lib.escape(m.group(0))
        related = html_lib.escape(text[m.end() : end])
        pieces.append(
            f'<span class="tt-h {cls}"><span class="tt-h-token">{token}</span>{related}</span>'
        )
        last = end
    if last < len(text):
        pieces.append(html_lib.escape(text[last:]))
    return "".join(pieces)


# Declared per-family grammar tokens from the parser-family registry (DIS-2442).
# Consulted BEFORE the heuristic classifier, so a token the heuristics cannot type
# (e.g. Inkling's `<|message_model|>`: pipe-both-sides, no `_begin`/`_end` suffix)
# renders with its declared pairing/coloring instead of as a red `tt-orphan` that
# looks like a parse error. Registering a family's tokens in parser_families.yaml
# is the ONLY step; this module derives its classification from that file.
def _parser_families_path() -> Path:
    """In the repo this module lives at src/tables/ with the registry at ../;
    the render stage keeps that shape. The same-dir candidate covers flat copies
    (mirrors markers._parser_families_path)."""
    here = Path(__file__).resolve()
    for cand in (
        here.parent / "parser_families.yaml",
        here.parent.parent / "parser_families.yaml",
        here.parents[2] / "src" / "parser_families.yaml",
    ):
        if cand.is_file():
            return cand
    raise FileNotFoundError(f"parser_families.yaml not found relative to {here}")


_FAMILY_MARKERS: dict[str, dict] = (
    yaml.safe_load(_parser_families_path().read_text()).get("markers") or {}
)
_declared_cache: dict[str, dict[str, tuple[str, str]]] = {}
_tag_re_cache: dict[str, re.Pattern[str]] = {}
_declared_pattern_cache: dict[str, list[tuple[re.Pattern[str], tuple[str, str]]]] = {}

_COMPOSITE_OPEN = "<|open|>"
_COMPOSITE_CLOSE = "<|close|>"
_COMPOSITE_SEP = "<|sep|>"
_COMPOSITE_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_:-]*$")
_COMPOSITE_ATTRS_PATTERN = (
    r'(?:[ \t]+[A-Za-z_][A-Za-z0-9_:-]*[ \t]*=[ \t]*"(?:\\.|[^"\\])*")*'
)


def _declared_lookup(family: str | None) -> dict[str, tuple[str, str]]:
    """Full-token -> (kind, pair_id) table for the family's declared markers."""
    if not family or family not in _FAMILY_MARKERS:
        return {}
    table = _declared_cache.get(family)
    if table is None:
        decl = _FAMILY_MARKERS[family]
        table = {}
        for open_tok, close_tok in decl.get("pairs") or []:
            table[open_tok] = ("open", open_tok)
            table[close_tok] = ("close", open_tok)
        for tok in decl.get("singletons") or []:
            table[tok] = ("singleton", tok)
        _declared_cache[family] = table
    return table


def _declared_token_pattern(token: str) -> str | None:
    """Regex for declaration-derived composite spellings.

    A declaration ending at the tag name denotes a parameterized opener; a complete
    declaration also accepts the protocol's canonical or space-padded spelling.
    """
    if token.startswith(_COMPOSITE_OPEN):
        body = token[len(_COMPOSITE_OPEN) :]
        if body.endswith(_COMPOSITE_SEP):
            name = body[: -len(_COMPOSITE_SEP)]
            attrs = ""
        else:
            name = body
            attrs = _COMPOSITE_ATTRS_PATTERN
        if _COMPOSITE_NAME_RE.fullmatch(name):
            return (
                re.escape(_COMPOSITE_OPEN)
                + r"[ \t]*"
                + re.escape(name)
                + attrs
                + r"[ \t]*"
                + re.escape(_COMPOSITE_SEP)
            )
    if token.startswith(_COMPOSITE_CLOSE) and token.endswith(_COMPOSITE_SEP):
        name = token[len(_COMPOSITE_CLOSE) : -len(_COMPOSITE_SEP)]
        if _COMPOSITE_NAME_RE.fullmatch(name):
            return (
                re.escape(_COMPOSITE_CLOSE)
                + r"[ \t]*"
                + re.escape(name)
                + r"[ \t]*"
                + re.escape(_COMPOSITE_SEP)
            )
    return None


def _declared_patterns(
    family: str | None,
) -> list[tuple[re.Pattern[str], tuple[str, str]]]:
    if not family:
        return []
    patterns = _declared_pattern_cache.get(family)
    if patterns is None:
        patterns = []
        for token, hit in _declared_lookup(family).items():
            source = _declared_token_pattern(token)
            if source is not None:
                patterns.append((re.compile(source), hit))
        patterns.sort(key=lambda item: len(item[0].pattern), reverse=True)
        _declared_pattern_cache[family] = patterns
    return patterns


def _declared_hit(token: str, family: str | None) -> tuple[str, str] | None:
    hit = _declared_lookup(family).get(token)
    if hit is not None:
        return hit
    for pattern, candidate in _declared_patterns(family):
        if pattern.fullmatch(token):
            return candidate
    return None


def _matches_declared_token(token: str, declaration: str) -> bool:
    if token == declaration:
        return True
    source = _declared_token_pattern(declaration)
    return source is not None and re.fullmatch(source, token) is not None


def _tag_matches(text: str, family: str | None):
    if not family:
        return _TAG_RE.finditer(text)
    pattern = _tag_re_cache.get(family)
    if pattern is None:
        declared = sorted(_declared_lookup(family), key=len, reverse=True)
        composites = [pattern.pattern for pattern, _ in _declared_patterns(family)]
        source = "|".join(
            [*composites, *(re.escape(token) for token in declared), _TAG_RE.pattern]
        )
        pattern = re.compile(source)
        _tag_re_cache[family] = pattern
    return pattern.finditer(text)


def _opaque_span_for(
    token: str, opaque_spans: dict[str, tuple[str, bool]]
) -> tuple[str, bool] | None:
    for declaration, span in opaque_spans.items():
        if _matches_declared_token(token, declaration):
            return span
    return None


def _opens_opaque_pair(token: str, pair_id: str, opaque_pairs: set[str]) -> bool:
    if pair_id in opaque_pairs:
        return True
    for prefix in (_COMPOSITE_OPEN, _COMPOSITE_CLOSE):
        if token.startswith(prefix):
            tail = token[len(prefix) :].lstrip(" \t")
            name = re.split(r"[ \t<]", tail, 1)[0]
            return name in opaque_pairs
    return False


def _declared_opaque(family: str | None) -> tuple[set[str], dict[str, tuple[str, bool]]]:
    """Regions whose body is argument DATA rather than markup.

    Inside such a region nothing is a control token until the region's OWN
    terminator — what the parser does when it reads a value to its terminator, so a
    marker-looking substring in a value survives (`I7`). See `opaque:` in
    parser_families.yaml.

    Returns `(pair_ids, spans)`:
      * `pair_ids` — regions opened by a normal open (or toggle) and closed by that
        pair's own closer: qwen3 `<parameter=K>` .. `</parameter>`, gemma4's
        `<|"|>` .. `<|"|>` quote toggle.
      * `spans` — `{from_token: (to_token, json)}`, for regions whose opener is a
        SINGLETON with no closer of its own, so the terminator must be named: kimi's
        `<|tool_call_argument_begin|>` .. `<|tool_call_end|>`. With `json: true` the
        body is a JSON object and a terminator-looking token INSIDE one of its string
        literals is data — kimi's terminator is the very token that can appear in a
        value, so position alone cannot disambiguate it. Mirrors the parser, which
        parses the JSON blob rather than scanning for the marker.
    """
    if not family or family not in _FAMILY_MARKERS:
        return set(), {}
    pair_ids: set[str] = set()
    spans: dict[str, tuple[str, bool]] = {}
    for entry in _FAMILY_MARKERS[family].get("opaque") or []:
        if isinstance(entry, dict):
            spans[entry["from"]] = (entry["to"], bool(entry.get("json")))
        else:
            pair_ids.add(entry)
    return pair_ids, spans


def declared_markers() -> dict[str, dict[str, list]]:
    """Every family's declared `pairs`/`singletons` (the subset `_declared_lookup`
    consumes), as plain JSON for the JS colorizer. The `leak:` markers are omitted —
    like `_declared_lookup`, they carry no open/close/singleton coloring role."""
    out: dict[str, dict[str, list]] = {}
    for family, decl in _FAMILY_MARKERS.items():
        entry: dict[str, list] = {}
        if decl.get("pairs"):
            entry["pairs"] = [list(p) for p in decl["pairs"]]
        if decl.get("singletons"):
            entry["singletons"] = list(decl["singletons"])
        if decl.get("opaque"):
            entry["opaque"] = list(decl["opaque"])
        if entry:
            out[family] = entry
    return out


def colorize_markup(text: str, family: str | None = None) -> str:
    if family == "harmony" and _HARMONY_TOKEN_RE.search(text):
        return _colorize_harmony(text)
    return _colorize_xml(text, family)


def _strip_suffix(s: str, suffixes: tuple[str, ...]) -> str | None:
    for suf in suffixes:
        if s.endswith(suf) and len(s) > len(suf):
            return s[: -len(suf)]
    return None


def _tag_kind_and_name(inner: str) -> tuple[str | None, str, str | None]:
    """Classify `<...>` tag inner text into an open/close/singleton kind.

    Returns (kind, pair_id, color_override):
      * kind: 'open' | 'close' | 'singleton' | 'toggle' | None
      * pair_id: name used to match open against close on the stack
      * color_override: when set, the paired span uses this name for the
        color class instead of pair_id (lets `<|start|>...<|call|>` color
        differently from `<|start|>...<|end|>` despite sharing pair_id).
    """

    def _name_of(s: str) -> str:
        # Split on whitespace, slash, `>`, OR `=` so that
        # `<function=book_flight>` pairs with `</function>` and
        # `<parameter=destination>` pairs with `</parameter>`.
        if not s:
            return ""
        return re.split(r"[\s/>=]", s, 1)[0].rstrip("|")

    if inner.startswith("/"):
        return ("close", _name_of(inner[1:]), None)
    starts_pipe = inner[:1] in _PIPES
    ends_pipe = inner[-1:] in _PIPES
    if starts_pipe and ends_pipe and len(inner) >= 2:
        middle = inner[1:-1]
        stripped = _strip_suffix(middle, _BEGIN_SUFFIXES)
        if stripped is not None:
            return ("open", stripped, None)
        stripped = _strip_suffix(middle, _END_SUFFIXES)
        if stripped is not None:
            return ("close", stripped, None)
        if middle == _HARMONY_TURN_OPEN:
            return ("open", "__harmony_turn", None)
        if middle in _HARMONY_TURN_CLOSE:
            # Color the pair by which closer flavor was used.
            return ("close", "__harmony_turn", f"__harmony_pair_{middle}")
        if middle in _HARMONY_SECTION_MARKERS:
            return ("singleton", "__harmony_section", None)
        # gemma4 string delimiter `<|"|>` is a self-paired quote token: the
        # same literal both opens and closes the string. Classify it as
        # `toggle` so a matched `<|"|>value<|"|>` pair colors like any other
        # pair, while a dangling (truncated) delimiter still falls through to
        # orphan/red. The open-vs-close decision is made by the stack at use
        # site, since the literal alone cannot say which it is.
        if middle == '"':
            return ("toggle", "__gemma_quote", None)
        return (None, "", None)
    if starts_pipe and inner[:1] == "|":
        return ("open", _name_of(inner[1:]), None)
    if ends_pipe and inner[-1:] == "|":
        return ("close", _name_of(inner[:-1]), None)
    return ("open", _name_of(inner), None)


def _in_json_string(text: str, start: int, pos: int) -> bool:
    """Is `pos` inside a JSON string literal of the object starting at `start`?"""
    in_str = False
    i = start
    while i < pos:
        c = text[i]
        if in_str and c == "\\":
            i += 2
            continue
        if c == '"':
            in_str = not in_str
        i += 1
    return in_str


def _colorize_xml(text: str, family: str | None = None) -> str:
    """HTML-escape `text` and wrap each `<...>` token in a span.
    Paired open/close (stack match by tag name) -> class 'tt-paired'.
    Unmatched close, or open that never closes -> class 'tt-orphan'.

    The family's declared markers (parser_families.yaml `markers:`) classify a
    token first; heuristics cover undeclared/parameterized tokens. Heuristics
    pair standard XML (`<X>...</X>`) AND alt pipe-marker conventions:
      `<|X>...<X|>`          (boundary ASCII pipes)
      `<|X_begin|>...<|X_end|>`  (both-side pipes with _begin/_end suffix)
    Lenient pop-through: a close looks down the stack for the nearest
    name-match; anything un-closed above it is marked orphan. Lets
    no-close singletons localize their orphan-ness without poisoning the
    surrounding pairs.
    """
    declared = _declared_lookup(family)
    opaque_pairs, opaque_spans = _declared_opaque(family)
    # Argument-value region we are inside:
    #   ("pair", pair_id, False, 0) | ("token", end_token, json_body, region_start)
    open_opaque: tuple[str, str, bool, int] | None = None
    pieces: list[str] = []
    stack: list[tuple[str, int]] = []
    last = 0
    for m in _tag_matches(text, family):
        if m.start() > last:
            pieces.append(html_lib.escape(text[last : m.start()]))
        tok = m.group(0)
        if tok == _MINIMAX_NS_TOKEN:
            pieces.append(f'<span class="{_NS_CLASS}">{html_lib.escape(tok)}</span>')
            last = m.end()
            continue
        hit = _declared_hit(tok, family)
        if hit is not None:
            kind, pair_id, color_override = hit[0], hit[1], None
        else:
            kind, pair_id, color_override = _tag_kind_and_name(tok[1:-1])
        esc = html_lib.escape(tok)
        if open_opaque is not None:
            # Inside an argument value: ONLY this region's own terminator ends it.
            # Every other token is part of the value, so it renders as plain data.
            mode, want, json_body, region_start = open_opaque
            if mode == "pair":
                ends = kind in ("close", "toggle") and pair_id == want
            else:
                ends = _matches_declared_token(tok, want) and not (
                    json_body and _in_json_string(text, region_start, m.start())
                )
            if ends:
                open_opaque = None
            else:
                pieces.append(esc)
                last = m.end()
                continue
        if kind is None:
            pieces.append(f'<span class="tt-orphan">{esc}</span>')
        elif kind == "singleton":
            cls = _singleton_class_for(pair_id)
            pieces.append(f'<span class="{cls}">{esc}</span>')
            opaque_span = _opaque_span_for(tok, opaque_spans)
            if opaque_span is not None:
                end_tok, json_body = opaque_span
                open_opaque = ("token", end_tok, json_body, m.end())
        elif kind == "toggle":
            # Self-paired delimiter: close the nearest matching open if one is
            # on the stack, otherwise treat this as the open. A leftover open
            # is orphaned by the end-of-loop cleanup.
            match_at = -1
            for i in range(len(stack) - 1, -1, -1):
                if stack[i][0] == pair_id:
                    match_at = i
                    break
            if match_at >= 0:
                for _, unmatched_idx in stack[match_at + 1 :]:
                    pieces[
                        unmatched_idx
                    ] = f'<span class="tt-orphan">{pieces[unmatched_idx]}</span>'
                open_idx = stack[match_at][1]
                cls = _next_color_class()
                pieces[open_idx] = f'<span class="{cls}">{pieces[open_idx]}</span>'
                pieces.append(f'<span class="{cls}">{esc}</span>')
                del stack[match_at:]
            else:
                pieces.append(esc)
                stack.append((pair_id, len(pieces) - 1))
                if _opens_opaque_pair(tok, pair_id, opaque_pairs):
                    open_opaque = ("pair", pair_id, False, 0)
        elif kind == "close":
            match_at = -1
            for i in range(len(stack) - 1, -1, -1):
                if stack[i][0] == pair_id:
                    match_at = i
                    break
            if match_at >= 0:
                for _, unmatched_idx in stack[match_at + 1 :]:
                    pieces[
                        unmatched_idx
                    ] = f'<span class="tt-orphan">{pieces[unmatched_idx]}</span>'
                open_idx = stack[match_at][1]
                # Per-instance color: every matched pair gets a fresh palette
                # index, so two `<tool_call>...</tool_call>` (or two
                # `<|start|>...<|call|>`) blocks in the same input render as
                # different colors. (color_override unused on the paired
                # path — kept on the singleton-flavor branch only.)
                _ = color_override
                cls = _next_color_class()
                pieces[open_idx] = f'<span class="{cls}">{pieces[open_idx]}</span>'
                pieces.append(f'<span class="{cls}">{esc}</span>')
                del stack[match_at:]
            else:
                pieces.append(f'<span class="tt-orphan">{esc}</span>')
        else:
            pieces.append(esc)
            stack.append((pair_id, len(pieces) - 1))
            opaque_span = _opaque_span_for(tok, opaque_spans)
            if opaque_span is not None:
                end_tok, json_body = opaque_span
                open_opaque = ("token", end_tok, json_body, m.end())
            elif _opens_opaque_pair(tok, pair_id, opaque_pairs):
                open_opaque = ("pair", pair_id, False, 0)
        last = m.end()
    for _, idx in stack:
        pieces[idx] = f'<span class="tt-orphan">{pieces[idx]}</span>'
    if last < len(text):
        pieces.append(html_lib.escape(text[last:]))
    return "".join(pieces)


def _xml_token_intervals(text: str, family: str | None = None) -> list[dict[str, Any]]:
    declared = _declared_lookup(family)
    opaque_pairs, opaque_spans = _declared_opaque(family)
    open_opaque: tuple[str, str, bool, int] | None = None
    intervals: list[dict[str, Any]] = []
    stack: list[tuple[str, int]] = []
    for match in _tag_matches(text, family):
        tok = match.group(0)
        if tok == _MINIMAX_NS_TOKEN:
            intervals.append(
                {"start": match.start(), "end": match.end(), "class": _NS_CLASS}
            )
            continue
        hit = _declared_hit(tok, family)
        if hit is not None:
            kind, pair_id = hit
        else:
            kind, pair_id, _color_override = _tag_kind_and_name(tok[1:-1])
        if open_opaque is not None:
            # Inside an argument value (see _declared_opaque): only this region's own
            # terminator is markup. Everything else gets NO interval, so it renders as
            # plain value text.
            mode, want, json_body, region_start = open_opaque
            if mode == "pair":
                ends = kind in ("close", "toggle") and pair_id == want
            else:
                ends = _matches_declared_token(tok, want) and not (
                    json_body and _in_json_string(text, region_start, match.start())
                )
            if ends:
                open_opaque = None
            else:
                continue
        idx = len(intervals)
        intervals.append({"start": match.start(), "end": match.end(), "class": None})
        if kind is None:
            intervals[idx]["class"] = "tt-orphan"
        elif kind == "singleton":
            intervals[idx]["class"] = _singleton_class_for(pair_id)
            opaque_span = _opaque_span_for(tok, opaque_spans)
            if opaque_span is not None:
                end_tok, json_body = opaque_span
                open_opaque = ("token", end_tok, json_body, match.end())
        elif kind == "toggle":
            match_at = -1
            for i in range(len(stack) - 1, -1, -1):
                if stack[i][0] == pair_id:
                    match_at = i
                    break
            if match_at >= 0:
                for _, unmatched_idx in stack[match_at + 1 :]:
                    intervals[unmatched_idx]["class"] = "tt-orphan"
                cls = _next_color_class()
                intervals[stack[match_at][1]]["class"] = cls
                intervals[idx]["class"] = cls
                del stack[match_at:]
            else:
                stack.append((pair_id, idx))
                if _opens_opaque_pair(tok, pair_id, opaque_pairs):
                    open_opaque = ("pair", pair_id, False, 0)
        elif kind == "close":
            match_at = -1
            for i in range(len(stack) - 1, -1, -1):
                if stack[i][0] == pair_id:
                    match_at = i
                    break
            if match_at >= 0:
                for _, unmatched_idx in stack[match_at + 1 :]:
                    intervals[unmatched_idx]["class"] = "tt-orphan"
                cls = _next_color_class()
                intervals[stack[match_at][1]]["class"] = cls
                intervals[idx]["class"] = cls
                del stack[match_at:]
            else:
                intervals[idx]["class"] = "tt-orphan"
        else:
            stack.append((pair_id, idx))
            opaque_span = _opaque_span_for(tok, opaque_spans)
            if opaque_span is not None:
                end_tok, json_body = opaque_span
                open_opaque = ("token", end_tok, json_body, match.end())
            elif _opens_opaque_pair(tok, pair_id, opaque_pairs):
                open_opaque = ("pair", pair_id, False, 0)
    for _, idx in stack:
        intervals[idx]["class"] = "tt-orphan"
    return intervals


def _harmony_intervals(text: str) -> list[dict[str, Any]]:
    intervals: list[dict[str, Any]] = []
    for match in _HARMONY_TOKEN_RE.finditer(text):
        token_name = match.group(1)
        if token_name in _HARMONY_TURN_CLOSE:
            end = match.end()
        else:
            next_match = _HARMONY_TOKEN_RE.search(text, match.end())
            end = next_match.start() if next_match else len(text)
        intervals.append(
            {
                "start": match.start(),
                "end": end,
                "class": _HARMONY_SEGMENT_CLASS.get(token_name, "tt-h-other"),
                "token_start": match.start(),
                "token_end": match.end(),
                "harmony": True,
            }
        )
    return intervals


def _markup_intervals(text: str, family: str | None) -> list[dict[str, Any]]:
    if family == "harmony" and _HARMONY_TOKEN_RE.search(text):
        return _harmony_intervals(text)
    return _xml_token_intervals(text, family)


def _render_harmony_interval_slice(
    text: str, interval: dict[str, Any], start: int, end: int
) -> str:
    token_start = interval["token_start"]
    token_end = interval["token_end"]
    parts: list[str] = []
    cursor = start
    token_slice_start = max(start, token_start)
    token_slice_end = min(end, token_end)
    if cursor < token_slice_start:
        parts.append(html_lib.escape(text[cursor:token_slice_start]))
        cursor = token_slice_start
    if token_slice_start < token_slice_end:
        parts.append(
            '<span class="tt-h-token">'
            f"{html_lib.escape(text[token_slice_start:token_slice_end])}</span>"
        )
        cursor = token_slice_end
    if cursor < end:
        parts.append(html_lib.escape(text[cursor:end]))
    return f'<span class="tt-h {interval["class"]}">{"".join(parts)}</span>'


def _render_interval_slice(
    text: str, interval: dict[str, Any], start: int, end: int
) -> str:
    if interval.get("harmony"):
        return _render_harmony_interval_slice(text, interval, start, end)
    return (
        f'<span class="{interval["class"] or "tt-orphan"}">'
        f"{html_lib.escape(text[start:end])}</span>"
    )


def _colorize_markup_slice(
    text: str, intervals: list[dict[str, Any]], start: int, end: int
) -> str:
    pieces: list[str] = []
    cursor = start
    for interval in intervals:
        istart = interval["start"]
        iend = interval["end"]
        if iend <= start:
            continue
        if istart >= end:
            break
        overlap_start = max(start, istart)
        overlap_end = min(end, iend)
        if cursor < overlap_start:
            pieces.append(html_lib.escape(text[cursor:overlap_start]))
        pieces.append(
            _render_interval_slice(text, interval, overlap_start, overlap_end)
        )
        cursor = overlap_end
    if cursor < end:
        pieces.append(html_lib.escape(text[cursor:end]))
    return "".join(pieces)


def colorize_stream_deltas(chunks: list[Any], family: str | None) -> list[str]:
    deltas = [
        str(chunk.get("delta_text") or "") if isinstance(chunk, dict) else ""
        for chunk in chunks
    ]
    text = "".join(deltas)
    intervals = _markup_intervals(text, family)
    rendered: list[str] = []
    cursor = 0
    for delta in deltas:
        end = cursor + len(delta)
        rendered.append(_colorize_markup_slice(text, intervals, cursor, end))
        cursor = end
    return rendered
