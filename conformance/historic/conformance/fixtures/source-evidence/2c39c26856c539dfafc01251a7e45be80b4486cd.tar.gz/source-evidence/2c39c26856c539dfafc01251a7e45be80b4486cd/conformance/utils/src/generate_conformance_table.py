#!/usr/bin/env python3
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Generate the conformance table from the YAML fixtures.

Reads every `tests/parity/toolcalling/fixtures/<family>/TOOLCALLING.batch*.yaml` and
emits the conformance table. The HTML page (`--html`) is rendered ENTIRELY by the JS
view from a single JSON data model (DIS-2434): Python computes structured per-cell
`comparison_facts()` (see `markers.py`) and the view renders the glyphs with full
descriptive labels ("vLLM Python batch parser", "Dynamo Rust stream parser", …).

There is no user-facing parser-marker shorthand mini-language. `cell_for` /
`_stream_xeng_marker` still emit compact per-engine agreement strings, but purely as
an INTERNAL representation that `_compute_stats` buckets on — those strings never
reach the page.

Per-cell status semantics:
  =     every compared parser matches the Dynamo baseline (`expected.dynamo_v1` batch
        / `expected.dynamo_v2` stream)
  ↯     the selected parser leaks tool-call markup into the visible `normal_text`
  ?     the divergence has no `explanation:` yet (research-needed)
  !     the parser has `error: <substring>` (expected to crash)
  ✗     the parser ran but failed to parse
  ·     Dynamo Rust-only fixture; peer blocks are unavailable or not captured
  n/a   family/case doesn't apply
  —     no fixture entry exists for this family/case yet

Footnote markers `†` (no vLLM peer) and `§` (no SGLang peer) are auto-derived
from `expected.<impl>.unavailable` across each family's cases.

Run:
    # Markdown table to stdout
    python3 tests/parity/generate_conformance_table.py toolcalling \
        > tests/parity/toolcalling/CONFORMANCE.md
    python3 tests/parity/generate_conformance_table.py toolcalling --mode stream \
        > tests/parity/toolcalling/CONFORMANCE.stream.md

    # HTML table with tabs, clickable YAML links, and hover tooltips. Prefer
    # conformance/utils/render_table_v2.sh so links are computed for the output
    # location.
    python3 tests/parity/generate_conformance_table.py toolcalling --html \
        > tests/parity/toolcalling/CONFORMANCE.html

CONFORMANCE.html is for local viewing only; don't check it in.
"""

from __future__ import annotations

import argparse
import copy
import datetime
import functools
import html as html_lib
import importlib
import json
import os
import re
import subprocess
import sys
import zoneinfo
from pathlib import Path
from typing import Any

import yaml
import yaml_fast  # noqa: F401 — routes safe_load/safe_dump through libyaml
import fixture_disposition
import capture_stimulus
from jinja2 import Environment, FileSystemLoader, StrictUndefined

from tables import common
from tables.common import TOP_N_TOOL_CALLING_FAMILIES as TOP_N_FAMILIES
from tables.common import (
    linkify_text_html,
    parity_cell_class,
)
from tables.markup import (
    colorize_markup,
    colorize_stream_deltas,
    declared_markers,
)
from tables.reasoning import table as reasoning_table
from unified_tools import unified_tools

REPO_ROOT = Path(__file__).resolve().parents[2]
FIXTURES = REPO_ROOT / "tests/parity/toolcalling/fixtures"
# Batch-on-stream overlay: each engine's STREAMING parser run over the v1 batch
# fixture text, keyed by the v1 batch case id. The batch-on-stream tab reuses the
# v1 batch taxonomy/input but renders these stream outputs as `expected`.
STREAM_ON_BATCH_FIXTURES = REPO_ROOT / "tests/parity/toolcalling/fixtures-batch-on-stream-v1"
TOOLCALLING_CASES_MD = REPO_ROOT / "lib/parsers/TOOLCALLING_CASES.md"
# Streaming cases use our own doc (renumbered to the batch+10 taxonomy), not the
# v1 TOOLCALLING_CASES.md.
TOOLCALLING_STREAMING_V1_CASES_MD = REPO_ROOT / "lib/parsers/TOOLCALLING_STREAMING_V1_CASES.md"
PYPROJECT_TOML = REPO_ROOT / "pyproject.toml"
TEMPLATE_DIR = REPO_ROOT / "tests/parity"

RUST_TOOL_CALLING_DIR = REPO_ROOT / "lib/parsers/src/tool_calling"

# Implementation identity (keys, aliases, display, markers) lives in impls.py — the
# single source of truth (audit B1). build_stage_conformance stages impls.py next to
# this file so the import works from the staged tests/parity layout too.
from impls import (  # noqa: E402
    UNIFIED_BATCH_IMPLS,
    UNIFIED_PEER_SOURCES,
    UNIFIED_COMPARISON_DEFAULTS,
    UNIFIED_COMPARISON_SLOT_ENGINES,
    UNIFIED_DISPLAY,
    BATCH_SOURCE_BLOCKERS,
    BATCH_SOURCE_IMPL,
    IMPL_SPECS,
    batch_capture_label,
    BASELINE_BATCH_IMPL,
    BASELINE_IMPLS,
    BASELINE_STREAM_IMPL,
    BATCH_IMPL_KEYS,
    baseline_impl,
    ENGINE_LETTER,
    IMPL_DISPLAY,
    IMPL_KEYS,
    IMPL_LANG_MARKER,
    LEGACY_IMPL_ALIASES,
    PARSER_NOT_CAPTURED,
    PEER_IMPL_KEYS,
    STREAM_IMPL_KEYS,
)

# Comparison + marker semantics live in markers.py (audit B5); re-exported here so the
# rendering code below and the test suite keep referring to them as module attributes.
import markers  # noqa: E402  (module handle: structured comparison model, DIS-2434)
from null_cases import null_group
from case_variants import group_null_variants, group_unified_variants

import unified_taxonomy  # noqa: E402  (shared UNIFIED scenario->numbered-id taxonomy)
import gen_unified_golden  # noqa: E402  (authored Unified scenario scope)
from markers import (  # noqa: E402,F401
    VLLM_RUST_UNAVAILABLE,
    _BATCH_MODE_MARKER,
    _PARSER_ERROR_RE,
    _STREAM_MODE_MARKER,
    _TOOL_CALL_MARKUP_RE,
    _block_tool_call_leaks,
    _canonical_impl_key,
    _canonical_tool_output,
    _dynamo_tool_call_leak,
    _expected,
    _explanation,
    _impl_get,
    _impl_keys_for_output_kind,
    _impl_mode_letter,
    _impl_mode_suffix,
    _is_parser_error_unavailable,
    _is_todo_unavailable,
    _legacy_impl_keys,
    _norm_calls,
    _normalize_impl_mapping,
    _overview_status,
    _parser_marker,
    _sob_calls_consistent,
    _sob_cell_text,
    _sob_status,
    _stream_cross_suffix,
    _stream_parity_explainer_html,
    _stream_xeng_marker,
    peer_status,
)

# Fixture loading + sub-case taxonomy live in fixtures.py (audit B5); re-exported here
# so the rendering code and tests keep referring to them as module attributes. The
# captured-with map is a shared mutable dict (load_all_cases mutates it in place).
import fixtures  # noqa: E402  (module handle: version radios repoint fixtures.FIXTURES)
from fixtures import (  # noqa: E402,F401
    BATCH_SUB_CASE_GROUPS,
    SPLIT_PARENT_SUBCASES,
    STREAM_SUB_CASE_GROUPS,
    SUB_CASE_GROUPS_BY_MODE,
    _CAPTURED_WITH_BY_MODE,
    _SUB_CASE_GROUP_KEY_BY_LABEL_BY_MODE,
    _SUB_CASE_GROUP_KEY_BY_SUB_BY_MODE,
    _attach_streamv1_batch_expected,
    _build_family_inheritance,
    _build_family_to_rust_ref,
    _derive_no_peer_sets,
    _derive_stream_expected,
    _discover_sub_cases,
    _display_order,
    _group_by_sub,
    _group_index_by_sub,
    _natural_sub_sort_key,
    _normalize_split_parent_cases,
    _sub_sort_key,
    _subcase_band_class,
    _subcase_group_key,
    family_suffix,
    load_all_cases,
)


# Row-label / visibility overrides keyed by tool calling family; ‡ is explained
# by the legend note in conformance_table.html.j2.
_TOOL_CALLING_LABEL_OVERRIDES = {
    "qwen3_coder": "Qwen 3 Coder / Nemotron V3‡",
}
# nemotron_nano: an alias for qwen3_coder, hide to avoid duplicate row
# nemotron_deci: for older v2 nemotron models, hide to avoid confusion with nemotron v3 models
_HIDDEN_TOOL_CALLING_FAMILIES = {"nemotron_deci", "nemotron_nano"}
_V2_TOP_N_TOOL_CALLING_FAMILIES = []
for family in TOP_N_FAMILIES:
    _V2_TOP_N_TOOL_CALLING_FAMILIES.append(family)
    if family == "harmony":
        _V2_TOP_N_TOOL_CALLING_FAMILIES.append("harmony_text")


def _model_label_html(model: str) -> str:
    """Escape a model label, styling any ‡ marker like the †/§ suffixes."""
    return html_lib.escape(model).replace("‡", '<span class="parser-suffix">‡</span>')


def _make_jinja_env() -> Environment:
    return Environment(
        loader=FileSystemLoader(TEMPLATE_DIR),
        trim_blocks=False,
        lstrip_blocks=True,
        undefined=StrictUndefined,
    )


def _read_asset(name: str) -> str:
    """Inline a static CSS/JS asset (audit B7) into the rendered page.

    The page is a single self-contained HTML file (no external requests), so the
    CSS/JS live in `tests/parity/assets/` as editable files and get inlined at
    render time rather than hard-coded in the Jinja template.
    """
    return (TEMPLATE_DIR / "assets" / name).read_text(encoding="utf-8")


def _resolve_output_path(
    output_path: Path | None,
    artifact_root: Path,
    default_output: str,
) -> Path:
    path = output_path or Path(default_output)
    if not path.is_absolute():
        path = artifact_root / path
    return path.resolve()


def _display_path(path: Path, artifact_root: Path) -> str:
    try:
        return path.relative_to(artifact_root).as_posix()
    except ValueError:
        return path.as_posix()


# Destination-aware link resolution lives in tables.common (`set_links` / `LINKS`).


_VISIBLE_CONFORMANCE_REPLACEMENTS = (
    ("All engines parity", "All engines match"),
    ("Parity harness flags used for this result:", "Conformance harness flags used for this result:"),
    ("Not set by this parser-level parity harness:", "Not set by this parser-level conformance harness:"),
    ("parser-level parity harness", "parser-level conformance harness"),
    ("parser-level parity result", "parser-level conformance result"),
    ("captured-peer parity", "captured-peer conformance"),
    ("Dynamo Parser Parity Table", "Dynamo Parser Conformance Table"),
    ("Dynamo Reasoning Parser - Parity Table", "Dynamo Reasoning Parser v2 Conformance Table"),
    ("Dynamo Tool Calling Parser - Parity Table", "Dynamo Tool Calling Parser v2 Conformance Table"),
    ("Parity Table", "Conformance Table"),
    ("parity table", "conformance table"),
    ("tests/parity/README.md", "parser fixture README"),
)


def _scrub_visible_conformance_text(text: str) -> str:
    """Keep the v2 page conformance-branded without renaming internal CSS/JS hooks."""
    for old, new in _VISIBLE_CONFORMANCE_REPLACEMENTS:
        text = text.replace(old, new)
    return text


def _commit_sha() -> str | None:
    """HEAD SHA at table-generation time, or None if not in a git tree."""
    try:
        out = (
            subprocess.check_output(
                ["git", "-C", str(REPO_ROOT), "rev-parse", "HEAD"],
                stderr=subprocess.DEVNULL,
            )
            .decode()
            .strip()
        )
        return out or None
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def _peer_versions() -> dict[str, str]:
    """Extract pinned vLLM Python / SGLang versions from pyproject.toml.

    Matches a line like `"vllm[flashinfer,runai,otel]==X.Y.Z",` (TOML is
    not parsed — the regex is sufficient and avoids a tomllib import on
    older Pythons running this script outside a Python 3.11+ env)."""
    out: dict[str, str] = {}
    if not PYPROJECT_TOML.exists():
        return out
    text = PYPROJECT_TOML.read_text()
    for name in ("vllm", "sglang"):
        m = re.search(rf'"{name}(?:\[[^\]]*\])?==([0-9][^"]*)"', text)
        if m:
            out[_canonical_impl_key(name)] = m.group(1)
    return out


def _build_display_groups(
    cases: dict, labels: dict[str, str]
) -> tuple[list[tuple[str, str]], list[tuple[str, str]]]:
    """Return `(top_n, others)` as `[(label, family), ...]` lists.

    Top-N: families listed in `_V2_TOP_N_TOOL_CALLING_FAMILIES`, in that exact order.
    Others: every YAML-discovered family not in TOP_N, sorted by label.
    Missing labels fall back to the family ID.
    """
    families = {
        fam for fam, _ in cases.keys() if fam not in _HIDDEN_TOOL_CALLING_FAMILIES
    }

    def label_of(fam: str) -> str:
        return _TOOL_CALLING_LABEL_OVERRIDES.get(fam, labels.get(fam, fam))

    top_n = [
        (label_of(f), f) for f in _V2_TOP_N_TOOL_CALLING_FAMILIES if f in families
    ]
    other_fams = sorted(
        families - set(_V2_TOP_N_TOOL_CALLING_FAMILIES),
        key=lambda f: label_of(f).lower(),
    )
    others = [(label_of(f), f) for f in other_fams]
    return top_n, others


def cell_for(
    case: dict | None,
    impl_keys: tuple[str, ...] = BATCH_IMPL_KEYS,
    marker_mode: str | None = _BATCH_MODE_MARKER,
) -> str:
    if case is None:
        return "—"
    expected = _expected(case)
    dyn = _impl_get(expected, baseline_impl(impl_keys))
    if not isinstance(dyn, dict):
        return "n/a"
    # Dynamo parser v2 unavailable for this case: distinguish "not yet implemented"
    # (TODO, the whole family) from a structural n/a (e.g. a token parser can't
    # consume a character-split fixture per-chunk).
    if "unavailable" in dyn:
        return "…" if _is_todo_unavailable(dyn) else "n/a"
    parts: list[str] = []
    peer_kinds: dict[str, str] = {}
    for impl in (peer for peer in impl_keys if peer not in BASELINE_IMPLS):
        kind, unknown = peer_status(case, dyn, impl)
        peer_kinds[impl] = kind
        letter = (
            _impl_mode_letter(impl) + _impl_mode_suffix(impl, marker_mode)
            if marker_mode is not None
            else ENGINE_LETTER[impl]
        )
        if kind == "div":
            parts.append(f"{letter}?" if unknown else letter)
        elif kind == "exception":
            parts.append(f"{letter}✗")
        elif kind == "err":
            parts.append(f"{letter}!")

    # `explanation:` on the `expected.dynamo_v2` block flags Dynamo parser v2 output as
    # leaking tool call markup only when it also leaves residual
    # `normal_text`. The Dynamo parser v2 can have non-leak reasons for dropped malformed
    # markup, so don't mark those as `↯`.
    if isinstance(dyn, dict) and _dynamo_tool_call_leak(dyn):
        if all(kind in {"unavail", "na"} for kind in peer_kinds.values()):
            return "↯·"
        if parts:
            return "↯" + "".join(parts)
        return "↯"

    if parts:
        return "".join(parts)
    if all(kind in {"unavail", "na"} for kind in peer_kinds.values()):
        return "·"
    return "="


def _common_legend_html(
    peer_versions: list[tuple[str, str]] | None = None,
    peer_versions_href: str | None = None,
) -> str:
    versions_html = ""
    if peer_versions:
        versions = " · ".join(
            f"{html_lib.escape(name)} <code>{html_lib.escape(version)}</code>"
            for name, version in peer_versions
        )
        versions_html = (
            "<p>"
            "<strong>Peer parser versions</strong> pinned in "
            f'<a href="{html_lib.escape(peer_versions_href or common.LINKS["pyproject_stub"], quote=True)}">pyproject.toml</a>: '
            f"{versions}."
            "</p>"
        )
    return (
        "<p><strong>Legend:</strong></p>"
        '<ul class="marker-defs">'
        '<li><span style="color:#0a7d2c"><strong>green</strong></span> = the selected <strong>Reference</strong> parser output is clean — no structured markup (tool-call or reasoning) leaked into the visible <code>normal_text</code>. A clean Reference is green whether or not any Compare parser is selected.</li>'
        '<li><span style="color:#b00"><strong>red</strong> (↯)</span> = the Reference parser leaks structured markup (tool-call or reasoning) into the visible <code>normal_text</code>.</li>'
        '<li><span style="color:#aaa"><strong>n/a</strong></span> = the selected Reference is not applicable for this case (for example the Dynamo v2 stream parser is not implemented for this family).</li>'
        '<li><span style="color:#8a6d3b">—</span> missing fixture coverage.</li>'
        '<li>In the <strong>Detailed</strong> view the number on a cell (with a <span style="color:#8a6d3b">Δ</span> suffix, e.g. <span style="color:#8a6d3b">2Δ</span>) = how many selected <strong>Compare</strong> parsers diverge from the Reference (<span style="color:#0a7d2c">=</span> means every selected Compare matches). A divergence with no <code>explanation:</code> yet is flagged <span style="color:#b00">?</span> (research needed); <span style="color:#b00">!</span> marks an engine that errors by design; <span style="color:#b00">✗</span> means the parser ran but failed to parse.</li>'
        '<li><strong>v1</strong> = the stable batch parser crate (<code>parsers/v1/src/...</code>, <code>dynamo-parsers</code>); <strong>v2</strong> = the WIP streaming parser crate (<code>parsers/v2/src/...</code>, <code>dynamo-parsers-v2</code>).</li>'
        '<li><span class="parser-suffix">†</span> no vLLM Python peer parser for this family. &nbsp; <span class="parser-suffix">§</span> no SGLang peer parser for this family. &nbsp; <span class="parser-suffix">‡</span> Nemotron V3 (Ultra) reuses the qwen3_coder parser.</li>'
        "</ul>"
        f"{versions_html}"
    )


_IMPL_DISPLAY = IMPL_DISPLAY


def _dynamo_note_sections(case: dict) -> list[tuple[str, str]]:
    """A baseline-side rationale for the Dynamo Rust output, rendered as its own
    tooltip section. `_tooltip_for` only explains PEER divergences (it skips the
    baseline), so a deliberate Dynamo behavior — e.g. dropping an unterminated
    Harmony tool call per dynamo #10366 — has no other surface. Sourced from a
    case-level `dynamo_note:` in the fc-local v2 fixtures; include a full URL so
    `linkify_text_html` makes the PR reference clickable."""
    note = case.get("dynamo_note")
    if not note:
        return []
    return [("Dynamo recovery contract", linkify_text_html(str(note)))]


def _parser_inheritance_tooltip_html(
    family: str,
    info: dict,
    ctor_ref: tuple[str, int] | None,
    no_vllm: set[str] | None = None,
    no_sglang: set[str] | None = None,
) -> str:
    """Rich `.ttip` tooltip for the tool calling parser column.

    Keep this field-list shape aligned with the reasoning parser column tooltip
    so both tables explain "effective parser/backend -> row family" the same
    way. `ctor_ref` is unused here (was for older field-based layout) — kept
    for API stability with `_parser_cell_html`.
    """
    del ctor_ref

    variant = info["variant"] or "?"
    sub_variant = info["sub_variant"]
    backend_file = info["backend_file"]
    factory = info["factory"]
    alias_of = info.get("alias_of")  # set when this family is an alias-only entry

    head_parts = [f"ParserConfig::{variant}"]
    if sub_variant:
        head_parts[-1] = f"ParserConfig::{variant}::{sub_variant}"
    bf_href = html_lib.escape(
        common.repository_href(f"parsers/v1/src/tool_calling/{backend_file}")
    )
    bf_link = f'<a href="{bf_href}">{html_lib.escape(backend_file)}</a>'

    anchor = alias_of or family
    shared_family = sorted([anchor] + info["shared_with"])
    effective_backend = _shared_backend_short(info) or family

    implementation = f"{html_lib.escape(head_parts[0])} -> {bf_link}"
    if factory:
        factory_name = factory.split("(", 1)[0]
        implementation += html_lib.escape(f" (factory: {factory_name})")

    tooltip_lines = [
        "Tool calling parser family from fixture YAML.",
        f"Tool calling parser row: {html_lib.escape(family)}",
        f"Effective parser/backend: {html_lib.escape(effective_backend)}",
        f"Dynamo implementation: {implementation}",
    ]
    if info["shared_with"]:
        tooltip_lines.append(
            "Shared implementation family: " + html_lib.escape(", ".join(shared_family))
        )
    if alias_of:
        tooltip_lines.append(f"Alias of: {html_lib.escape(alias_of)}")
    if info["aliases"]:
        tooltip_lines.append(
            "Registered aliases: " + html_lib.escape(", ".join(info["aliases"]))
        )

    peer_notes: list[str] = []
    if no_vllm and family in no_vllm:
        peer_notes.append("no vLLM Python peer parser")
    if no_sglang and family in no_sglang:
        peer_notes.append("no SGLang peer parser")
    if peer_notes:
        tooltip_lines.append("Peer availability: " + ", ".join(peer_notes))

    if info["filed_under_xml_misleading"]:
        tooltip_lines.append(
            "Note: filed under xml/ but does not use the shared xml::parser; "
            f"it has its own ParserConfig::{html_lib.escape(variant)} variant."
        )
    # The tree draws with box-drawing characters and only lines up in a fixed-width
    # font, so it opts back into monospace while the prose around it stays proportional.
    tree_lines = _tool_parser_tree_lines(family, info, effective_backend)
    if tree_lines:
        tooltip_lines.append(
            '<span class="ttip-tree">' + "\n".join(tree_lines).strip("\n") + "</span>"
        )

    if effective_backend == family:
        head_text = f"`{family}`"
    else:
        head_text = f"`{effective_backend}` (row: `{family}`)"
    return (
        '<div class="ttip">'
        f'<div class="ttip-head">{html_lib.escape(head_text)}</div>'
        f'<pre class="ttip-pre">{"".join(line + chr(10) for line in tooltip_lines).rstrip()}</pre>'
        "</div>"
    )


_SHARED_BACKEND_SHORT = {
    ("Json", "Basic"): "base_json",
    ("Xml", None): "xml",
    ("Dsml", None): "dsml",
}


def _tool_parser_tree_lines(
    family: str,
    info: dict,
    effective_backend: str,
) -> list[str]:
    alias_of = info.get("alias_of")
    anchor = alias_of or family
    aliases = info["aliases"]
    if not info["shared_with"] and not aliases and effective_backend == family:
        return []

    fam_list = sorted([anchor] + info["shared_with"])
    lines = ["", "Shared implementation tree:"]
    root_label = html_lib.escape(effective_backend)
    if effective_backend == family:
        root_label = f"<strong>{root_label}</strong>"
    lines.append(f"{root_label} (effective parser/backend)")

    for i, fam in enumerate(fam_list):
        is_last_fam = i == len(fam_list) - 1
        branch = "└── " if is_last_fam else "├── "
        fam_label = html_lib.escape(fam)
        if fam == family and not alias_of:
            fam_label = f"<strong>{fam_label}</strong>"
        lines.append(f"{branch}{fam_label}")

        if fam == anchor and aliases:
            cont = "    " if is_last_fam else "│   "
            for j, alias in enumerate(aliases):
                alast = j == len(aliases) - 1
                ab = "└── " if alast else "├── "
                alias_label = html_lib.escape(alias)
                if alias_of and alias == family:
                    alias_label = f"<strong>{alias_label}</strong>"
                lines.append(f"{cont}{ab}{alias_label} (alias)")

    return lines


def _shared_backend_short(info: dict | None) -> str | None:
    if info and info["shared_with"]:
        return _SHARED_BACKEND_SHORT.get(info["key"])
    return None


# Dynamo parser v2 stream parsers with a standard `push`/`finish` text path:
# family -> (backend label, source file under parsers/v2/src/tool_calling/, format marker).
# Families with bespoke paths (harmony token-id/text, deepseek_v4 DSML note) keep their
# dedicated branches below; new standard families belong here, not in new if-branches.
_V2_STREAM_PARSER_CELLS: dict[str, tuple[str, str, str]] = {
    "gemma4": ("Gemma4ToolStreamParser text path", "gemma4.rs", "Gemma"),
    "glm47": ("Glm47ToolStreamParser text path", "glm47.rs", "GLM XML"),
    "kimi_k2": ("KimiK2ToolStreamParser text path", "kimi_k2.rs", "Kimi XML"),
    "minimax_m2": ("MiniMaxM2ToolStreamParser text path", "minimax_m2.rs", "MiniMax XML"),
    "minimax_m3": ("MiniMaxM3ToolStreamParser text path", "minimax_m3.rs", "MiniMax-M3 XML"),
    "qwen3_coder": ("Qwen3CoderToolStreamParser text path", "qwen3_coder.rs", "Qwen XML"),
}


def _parser_cell_html(
    family: str,
    refs: dict[str, tuple[str, int]],
    no_vllm: set[str],
    no_sglang: set[str],
    inheritance: dict[str, dict],
    stream_context: str | None = None,
) -> str:
    suff = family_suffix(family, no_vllm, no_sglang)
    row_label = html_lib.escape(family)
    if suff:
        row_label += f'<span class="parser-suffix">{html_lib.escape(suff)}</span>'
    if family == "harmony" and stream_context == "streamv1":
        return _v2_parser_cell_html(
            row_label,
            family,
            "HarmonyToolStreamParser token-id path",
            "harmony.rs",
            "parse_tool_call_streaming_incremental",
            "legacy stream fixtures",
            "TC stream token-id row. It consumes `delta_token_ids` from legacy, non-Unified stream fixtures directly.",
        )
    if family == "harmony" and stream_context == "batch_on_stream":
        return _v2_parser_cell_html(
            row_label,
            family,
            "HarmonyToolStreamParser text path",
            "harmony.rs",
            "parse_tool_call_streaming_text",
            "v1 batch fixtures",
            "TC batch-on-stream row. It feeds each v1 batch fixture's full text through the v2 streaming parser.",
        )
    if family == "harmony_text":
        return _v2_parser_cell_html(
            row_label,
            family,
            "HarmonyToolStreamParser text path",
            "harmony.rs",
            "parse_tool_call_streaming_text",
            "legacy stream fixtures",
            "Synthetic v2 row for gpt-oss text streaming. The text path re-tokenizes a held suffix, then feeds the same token-incremental Harmony stream parser used by the token-id row.",
        )
    if family == "deepseek_v4" and stream_context in ("streamv1", "batch_on_stream"):
        fixtures = "legacy stream fixtures" if stream_context == "streamv1" else "v1 batch fixtures"
        note = (
            "TC stream row. It consumes DSML text chunks and emits compact complete-invoke deltas."
            if stream_context == "streamv1"
            else "TC batch-on-stream row. It feeds each v1 batch fixture's full text through the v2 DSML streaming parser."
        )
        return _v2_parser_cell_html(
            row_label,
            family,
            "DeepSeekV4ToolStreamParser text path",
            "dsml.rs",
            "push",
            fixtures,
            note,
        )
    v2_cell = _V2_STREAM_PARSER_CELLS.get(family)
    if v2_cell and stream_context in ("streamv1", "batch_on_stream"):
        backend, source_file, marker = v2_cell
        fixtures = "legacy stream fixtures" if stream_context == "streamv1" else "v1 batch fixtures"
        note = (
            f"TC stream row. It consumes {marker} text chunks and emits per-chunk tool-call deltas."
            if stream_context == "streamv1"
            else f"TC batch-on-stream row. It feeds each v1 batch fixture's full text through the v2 {marker} streaming parser."
        )
        return _v2_parser_cell_html(
            row_label, family, backend, source_file, "push", fixtures, note
        )
    if stream_context in ("streamv1", "batch_on_stream"):
        # No Dynamo parser v2 stream parser for this family yet. Inventory-only
        # row; don't link the v1 batch parser.
        return _v2_missing_stream_parser_cell_html(family)
    ref = refs.get(family)
    info = inheritance.get(family)
    ttip = (
        _parser_inheritance_tooltip_html(family, info, ref, no_vllm, no_sglang)
        if info
        else ""
    )

    # Shared-backend rows should read as implementation -> fixture family,
    # e.g. `xml -> minimax_m2` and `xml -> qwen3_coder`. Standalone parsers
    # keep the public family name as the primary label.
    short = _shared_backend_short(info)
    if short:
        label = html_lib.escape(short)
        base_suffix = f'<span class="parser-base">→ {row_label}</span>'
    else:
        label = row_label
        base_suffix = ""

    # Family-name link points to the **actual parser code** (backend_file from
    # the inheritance map), not to the config-ctor location in config.rs. The
    # ctor location is still referenced in the inheritance tooltip body when
    # useful (factory calls). For families with no inheritance info, fall back
    # to the refs entry (config.rs or parsers.rs).
    if info and info["backend_file"] != "unknown":
        href = common.repository_href(
            f"parsers/v1/src/tool_calling/{info['backend_file']}"
        )
    elif ref is not None:
        href = common.repository_href(f"parsers/v1/src/tool_calling/{ref[0]}")
    else:
        return (
            f'<td class="parser" data-col-hide-group="parser">'
            f"{label}{base_suffix}{ttip}</td>"
        )
    return (
        f'<td class="parser" data-col-hide-group="parser">'
        f'<a href="{href}">{label}</a>{base_suffix}{ttip}</td>'
    )


def _v2_parser_cell_html(
    row_label: str,
    family: str,
    backend: str,
    source_file: str,
    entrypoint: str,
    fixtures: str,
    note: str,
) -> str:
    source_href = common.repository_href(
        f"parsers/v2/src/tool_calling/{source_file}"
    )
    tooltip = (
        '<div class="ttip">'
        f'<div class="ttip-head">`{html_lib.escape(family)}` (v2 stream)</div>'
        '<pre class="ttip-pre ttip-note">'
        f"Fixtures: {html_lib.escape(fixtures)}.\n"
        f"Tool calling parser row: {html_lib.escape(family)}\n"
        f"Effective parser/backend: {html_lib.escape(backend)}\n"
        f"Dynamo parser v2 implementation: parsers/v2/src/tool_calling/{html_lib.escape(source_file)} -> "
        f'<a href="{source_href}">{html_lib.escape(entrypoint)}</a>\n'
        f"Note: {html_lib.escape(note)}"
        "</pre></div>"
    )
    return (
        f'<td class="parser" data-col-hide-group="parser">'
        f'<a href="{source_href}">{row_label}</a>{tooltip}</td>'
    )


def _v2_missing_stream_parser_cell_html(family: str) -> str:
    label = html_lib.escape(family)
    tooltip = (
        '<div class="ttip">'
        f'<div class="ttip-head">`{label}` (v2 stream)</div>'
        '<pre class="ttip-pre ttip-note">'
        "Dynamo parser v2 is not implemented for this family yet.\n"
        "This row is inventory only; no v1 parser code runs on this tab."
        "</pre></div>"
    )
    return f'<td class="parser" data-col-hide-group="parser">{label}{tooltip}</td>'


def _has_peer_output(case: dict | None) -> bool:
    if not case:
        return False
    expected = _expected(case)
    for impl in PEER_IMPL_KEYS:
        block = _impl_get(expected, impl)
        if isinstance(block, dict) and "unavailable" not in block:
            return True
    return False


def _parse_subcase_descriptions(mode: str) -> dict[str, str]:
    """Parse `lib/parsers/TOOLCALLING_CASES.md` for per-case descriptions.

    The Quick-reference section has one-liner bullets for top-level cases
    (`TOOLCALLING.<mode>.1` …); the deeper per-case sections
    contain multi-line bullets for sub-cases (`2.a`, `4.c`, etc.). Both
    look like `- **`TOOLCALLING.<mode>.X`** <desc>`, where the bullet body may
    wrap across indented continuation lines. Returns
    `{"1": "...", "2.a": "...", ...}`.
    """
    # Streaming descriptions come from our own renumbered doc; batch/others from
    # the v1 TOOLCALLING_CASES.md.
    cases_md = TOOLCALLING_STREAMING_V1_CASES_MD if mode == "streamv1" else TOOLCALLING_CASES_MD
    if not cases_md.exists():
        return {}
    pat = re.compile(
        rf"\*\*`TOOLCALLING\.{re.escape(mode)}"
        rf"\.({common.CASE_DESCRIPTION_SUFFIX})`\*\*\s+(.+)"
    )
    out: dict[str, str] = {}
    lines = cases_md.read_text(encoding="utf-8").splitlines()
    i = 0
    while i < len(lines):
        m = pat.search(lines[i])
        if not m:
            i += 1
            continue
        sub = m.group(1)
        body_parts = [m.group(2).strip()]
        # Join indented continuation lines until blank / next bullet / unindented.
        j = i + 1
        while j < len(lines):
            nxt = lines[j]
            if not nxt.strip():
                break
            if not nxt.startswith(" "):
                break
            if pat.search(nxt):
                break
            body_parts.append(nxt.strip())
            j += 1
        desc = " ".join(body_parts).rstrip(".")
        out.setdefault(sub, desc)
        i = j
    return out


def _subcase_group_label(mode: str, sub: str) -> str:
    return _group_by_sub(mode).get(null_group(sub) or sub, "Other")


def _subcase_runs(mode: str, sub_cases: list[str]) -> list[list[str]]:
    runs: list[list[str]] = []
    start = 0
    while start < len(sub_cases):
        label = _subcase_group_label(mode, sub_cases[start])
        end = start + 1
        while (
            end < len(sub_cases) and _subcase_group_label(mode, sub_cases[end]) == label
        ):
            end += 1
        runs.append(sub_cases[start:end])
        start = end
    return runs


def _glossary_groups(
    mode: str, descriptions: dict[str, str], sub_cases: list[str]
) -> list[dict[str, object]]:
    if not descriptions:
        return []
    return [
        {
            "label": _subcase_group_label(mode, run[0]),
            "rows": [
                (
                    sub,
                    descriptions.get(sub) or descriptions.get(sub.split(".")[0]) or "",
                )
                for sub in run
            ],
        }
        for run in _subcase_runs(mode, sub_cases)
    ]


def _peer_version_items(versions: dict[str, str]) -> list[tuple[str, str]]:
    normalized = _normalize_impl_mapping(versions)
    return [
        (_IMPL_DISPLAY[name], normalized[name])
        for name in ("vllm_rust", "vllm_python", "sglang_python")
        if name in normalized
    ]


# --- per-impl version snapshots for the TC v1 (batch) tab -----------------------
# Version dirs use legacy impl prefixes (dynamo/vllm/sglang); map to the canonical
# batch impl keys the cells + radios use. Discovery/slug/sort helpers are shared
# with the parity page via fixtures.
_VERSION_LEGACY_TO_CANON = {**{key: key for key in IMPL_KEYS}, **LEGACY_IMPL_ALIASES}


def _batch_impl_versions() -> dict[str, list[str]]:
    """Legacy-impl -> versions (ascending) for impls present on the batch tab."""
    discovered = fixtures._impl_versions()
    return {
        legacy: vers
        for legacy, vers in discovered.items()
        if _VERSION_LEGACY_TO_CANON.get(legacy) in BATCH_IMPL_KEYS
    }


def _resolver_module(name: str):
    """Import a fixture resolver from the repo's conformance/utils/src.

    The resolvers are not part of the staged tree, so their directory is APPENDED to
    sys.path — never prepended — so the staged copies of fixtures/markers/tables keep
    priority over the repo-side originals sitting beside the resolvers."""
    src_dir = str(fixtures._RESOLVE_SRC_DIR)
    if src_dir not in sys.path:
        sys.path.append(src_dir)
    return importlib.import_module(name)


@functools.lru_cache(maxsize=None)
def _source_corpus(root_str: str) -> dict:
    """Parse a versioned fixture corpus ONCE, for every version selection resolved
    out of it. Each render resolves ~9 batch + ~11 stream selections; re-reading all
    ~1700 source files per selection was the single largest cost in the render."""
    return _resolver_module("fixture_corpus").load_corpus(Path(root_str))


def _batch_version_status_map() -> dict[tuple[str, str], dict[str, dict[str, str]]]:
    """{(family, sub): {canonical_impl: {version_slug: overview_status}}} for batch.

    Resolve each impl@version (others pinned) and re-run load_all_cases("batch") so
    keys match the rendered table (same normalization); classify with the same
    markers._overview_status used for the pinned cells."""
    impl_versions = _batch_impl_versions()
    if not impl_versions:
        return {}
    resolver = fixtures._RESOLVE_SRC_DIR / "resolve_fixtures.py"
    src = fixtures._SRC_FIXTURES
    if not resolver.exists() or not src.is_dir():
        return {}
    resolve_batch = _resolver_module("resolve_fixtures").resolve_docs
    corpus = _source_corpus(str(src))
    pinned = fixtures._pinned_versions(impl_versions)
    had_captured = "batch" in _CAPTURED_WITH_BY_MODE
    saved_captured = _CAPTURED_WITH_BY_MODE.get("batch")
    result: dict[tuple[str, str], dict[str, dict[str, str]]] = {}
    try:
        for legacy, versions in impl_versions.items():
            canon = _VERSION_LEGACY_TO_CANON[legacy]
            for version in versions:
                slug = fixtures._version_slug(version)
                select = [
                    f"{other}-{version if other == legacy else pinned[other]}"
                    for other in impl_versions
                ]
                # Resolve in memory and read the docs directly: this map only needs
                # each case's status/block/marker, so staging the tree to a tempdir
                # just to parse it straight back was pure overhead.
                docs, _folded = resolve_batch(src, select, corpus=corpus)
                cases, _labels = load_all_cases("batch", docs=docs)
                for key, case in cases.items():
                    block = _impl_get(case.get("expected") or {}, canon)
                    result.setdefault(key, {}).setdefault(canon, {})[slug] = {
                        "status": _overview_status(case, canon),
                        "block": block,
                        "version": version,
                        "marker": _parser_marker(case, canon),
                    }
    finally:
        # load_all_cases stamps this per call; put the pinned render's value back.
        if had_captured:
            _CAPTURED_WITH_BY_MODE["batch"] = saved_captured
        else:
            _CAPTURED_WITH_BY_MODE.pop("batch", None)
    return result


# --- compare-any-combination model (TC v1 tab) ---------------------------------
# Every (parser, version) is a "candidate". A cell reports how many of the
# user-selected candidates differ from the chosen Base; the tooltip shows Base +
# each selected candidate's output. All of it is computed client-side from the
# compact per-cell `data-cmp` payload below, so any base/compare combination works.
_CANDIDATE_SHORT = {
    "dynamo_v1": "Dynamo v1",
    "dynamo_v2": "Dynamo v2",
    "vllm_rust": "vLLM Rust",
    "vllm_python": "vLLM",
    "sglang_python": "SGLang",
}

# Standardized candidate label: "<Engine> <Runtime> <version> (<mode>)", e.g.
# "Dynamo Rust 3.0.0 (batch)", "vLLM Python 0.24.0 (stream)". The runtime is part of
# the engine display so a chip and its tooltip section read identically, and one
# merged-tab cell distinguishes a batch parser from a stream parser on the same text
# purely by the trailing "(mode)". Dynamo's parsers are Rust crates (dynamo-parsers
# v1 3.0.0, dynamo-parsers-v2 0.1.11); the version disambiguates v1 vs v2.
def _full_label(impl: str, version: object, mode: str) -> str:
    base = IMPL_DISPLAY.get(impl, _CANDIDATE_SHORT.get(impl, impl))
    if impl == BASELINE_STREAM_IMPL and mode.startswith("stream"):
        mode = "stream, UnifiedParser"
    # The v1/v2 generation is part of the impl key (dynamo_v1/dynamo_v2), so the
    # display already reads "Dynamo v1 Rust 3.0.0 (batch)" / "Dynamo v2 Rust
    # 0.1.11 (stream, UnifiedParser)". The one remaining special case: v1 run against stream
    # data goes through the streaming jail (buffer, then v1 batch parse), so on
    # the stream tab its mode reads "(jail+batch)".
    if impl == BASELINE_BATCH_IMPL and mode == "stream":
        mode = "jail+batch"
    ver = f" {version}" if version else ""
    return f"{base}{ver} ({mode})"


def _candidate_label_html(label: str) -> str:
    """Escape a compare candidate label and color the trailing mode parenthetical:
    `batch` maroon, `stream` NVIDIA green (matches the tab-label word coding). The
    plain `label` stays around for tooltips; only the compare bar uses this HTML."""
    esc = html_lib.escape(label)
    m = re.search(r"\(([^)]*)\)\s*$", esc)
    if not m:
        return esc
    s, e = m.span(1)
    inner = m.group(1)
    inner = inner.replace("batch", '<span class="cand-batch">batch</span>')
    inner = inner.replace("stream", '<span class="cand-stream">stream</span>')
    return esc[:s] + inner + esc[e:]


def _dynamo_v2_version() -> str | None:
    """Version label for the Dynamo v2 stream parser, taken from the PUBLISHED fixture
    provenance (the `dynamo_v2-<ver>` dir, e.g. 0.1.11), NOT the live
    parsers/v2/Cargo.toml.

    Sourcing from the fixtures keeps every "Dynamo v2 Rust … (stream, UnifiedParser)" label on the page
    consistent (the stream-tab candidates already read the dir version) and matching the
    captured data. Reading the live crate makes the label drift ahead — the page would
    show 0.1.16 in one place and the real captured 0.1.11 in another the moment the crate
    is bumped before a re-capture/republish."""
    # Versions are ascending; the LATEST capture is the current v2 parser build.
    vs = _stream_impl_versions().get(BASELINE_STREAM_IMPL, [])
    return vs[-1] if vs else None


def _v2_display_version(impl: str) -> str | None:
    """Display version for a v2-tab candidate: Dynamo -> the v2 crate version;
    peers -> the engine version they were captured against."""
    if impl == BASELINE_STREAM_IMPL:
        return _dynamo_v2_version()
    return _clean_version((_CAPTURED_WITH_BY_MODE.get("streamv1") or {}).get(impl))


def _clean_version(v: object) -> str | None:
    """Pull a display version from a captured_with value: 'v0.23.0 <sha>' -> '0.23.0',
    '0.5.12.post1' -> '0.5.12.post1', 'Dynamo parser v2' -> None (no numeric version)."""
    if not v:
        return None
    token = str(v).split()[0].lstrip("v")
    return token if re.match(r"\d", token) else None


def _candidate_name_key(label: str) -> str:
    """Parser name for ordering: the display label minus its trailing version token and
    "(mode)" suffix. "vLLM Rust 0.25.1 (stream)" -> "vllm rust". Sorting candidates on
    this puts PARSERS alphabetically (Dynamo < SGLang < vLLM Python < vLLM Rust)."""
    match = _CANDIDATE_VERSION_RE.search(label)
    base = label[:match.start()] if match else re.sub(r"\s*\([^)]*\)\s*$", "", label)
    return base.lower()


# Publication status belongs to display provenance, not the capture version key.
_CANDIDATE_VERSION_RE = re.compile(
    r"\s(\d[\w.+]*)\s*(?:\[unpublished sha256:[a-f0-9]+\]\s*)?(?:·\s*(?:batch|stream)\s*)?(?:\([^)]*\))?(?:\s+\(source unavailable\))?\s*$"
)


def _sort_candidates(items: list[dict]) -> list[dict]:
    """Order compare candidates PARSER-alphabetically with versions LATEST-FIRST within
    each parser. Two stable passes: version DESC first, then a stable name sort that
    groups by parser and preserves the version-desc order inside each group. The version
    pass runs EXPLICITLY — one call site (_cell_candidate_meta over __ver_status) feeds
    versions ascending, so relying on a stable name-sort alone would keep them ascending.
    Reference (bucket A) stays first because Dynamo sorts ahead of the peers. Keys and
    default_bucket flags are untouched; only display order moves."""
    def _ver_key(it: dict):
        version = _version_of_label(it["label"])
        return fixtures._version_sort_key(version) if version else ()
    ordered = sorted(items, key=_ver_key, reverse=True)
    return sorted(ordered, key=lambda it: _candidate_name_key(it["label"]))


def _candidate_items() -> list[dict[str, str]]:
    """Ordered comparison candidates for the batch tab: Dynamo, then vLLM/SGLang —
    within each engine versions run LATEST-FIRST (0.24.0 before 0.23.0). Each:
    {key, impl, version, slug, label, short, default_bucket}.

    Default layout: A (reference) = the first candidate (Dynamo's latest);
    everything else starts UNSELECTED (C) — the reader opts into comparisons."""
    impl_versions = _batch_impl_versions()
    out: list[dict[str, str]] = []
    first = True
    for canon in ("dynamo_v1", "vllm_python", "sglang_python"):
        for v in reversed(impl_versions.get(canon, [])):
            slug = fixtures._version_slug(v)
            if first:
                bucket = "A"
                first = False
            else:
                bucket = "C"
            out.append({
                "key": f"{canon}-{slug}",
                "impl": canon,
                "version": v,
                "slug": slug,
                "short": IMPL_DISPLAY.get(canon, canon),
                "label": _full_label(canon, v, "batch"),
                "default_bucket": bucket,
            })
    return _sort_candidates(out)


# --- per-impl version snapshots for the TC v2 (stream) tab ----------------------
# The streamv1 corpus is versioned like batch, but with a different physical layout:
# The legacy stream corpus is versioned like the batch corpus (no unversioned anchor):
# fixtures-stream-v1/inputs/ (shared per-chunk delta_text) + fixtures-stream-v1/
# <impl>-<version>/ (per-impl expected; lowest version = full anchor, higher =
# changed-only). resolve_stream_fixtures.py reconstructs a flat tree for any selected
# version set — the stream analogue of resolve_fixtures.py + the batch __ver_status map.
# Read from the fixture extraction cache (loose YAMLs aren't in the repo; the LFS
# tarballs under conformance/fixtures/ are extracted there on first use);
# _common.sh exports CONFORMANCE_FIXTURES_ROOT. Without this the stream tab's versioned
# candidates come up empty and the Base/Compare parser selector doesn't render.
_STREAM_SRC = (
    fixtures._fixtures_cache_root() / "toolcalling/fixtures-stream-v1"
)


_PATCH_SUFFIX_RE = re.compile(r"\.patch\d+$")


def _base_stream_version(ver: str) -> str:
    """A `X.patchN` capture is the SAME parser binary re-run to backfill newer
    cases onto version `X` (e.g. 0.1.11.patch1 = the 0.1.11 binary on streamv1.5.h).
    It folds onto `X` for display — it is not a standalone candidate version. The
    on-disk shard stays separate so the pristine `X` capture is never rewritten;
    the resolver folds same-release patches after `X`."""
    return _PATCH_SUFFIX_RE.sub("", ver)


def _stream_impl_versions() -> dict[str, list[str]]:
    """{stream_impl: versions ascending} discovered from the fixtures-stream-v1/
    <impl>-<version>/ dirs (no hardcoded anchor — the baseline is whichever version is
    lowest). Ordered dynamo_v1, dynamo_v2, vllm_rust, vllm_python, sglang_python (canonical
    stream column order)."""
    found: dict[str, list[str]] = {}
    if _STREAM_SRC.is_dir():
        corpus = _source_corpus(str(_STREAM_SRC))
        for impl, versions in corpus.version_dirs.items():
            # `.patchN` overlays are NOT standalone candidates — they fold onto their
            # base version (the resolver folds same-release patches). Collapse
            # to the base so only real versions become compare columns.
            found[impl] = [_base_stream_version(ver) for _key, ver, _directory in versions]
    for impl in list(found):
        found[impl] = sorted(set(found[impl]), key=fixtures._version_sort_key)
    order = ("dynamo_v1", "dynamo_v2", "vllm_rust", "vllm_python", "sglang_python")
    return {i: found[i] for i in order if i in found}


def _stream_candidate_items() -> list[dict[str, str]]:
    """Versioned comparison candidates for the stream tab. Keyed <impl>-<slug> like
    the batch tab. Default layout: A (reference) = the LATEST Dynamo v2 stream
    capture (this is v2's tab); everything else — the v1 jail reference, the
    peers, and older versions — starts UNSELECTED (C), the reader opts in."""
    impl_versions = _stream_impl_versions()
    latest = {i: (vs[-1] if vs else None) for i, vs in impl_versions.items()}
    out: list[dict[str, str]] = []
    for impl in ("dynamo_v1", "dynamo_v2", "vllm_rust", "vllm_python", "sglang_python"):
        # Within an engine, versions run LATEST-FIRST (0.24.0 before 0.23.0).
        for v in reversed(impl_versions.get(impl, [])):
            slug = fixtures._version_slug(v)
            if impl == BASELINE_STREAM_IMPL and v == latest.get(impl):
                bucket = "A"
            else:
                # Older captures stay SELECTABLE but unchecked. Auto-comparing every
                # version turns on a wall of columns the moment Detailed is pressed;
                # the reader picks the one build they want to diff against.
                bucket = "C"
            out.append({
                "key": f"{impl}-{slug}",
                "label": _full_label(impl, v, "stream"),
                "default_bucket": bucket,
            })
    return _sort_candidates(out)


@functools.lru_cache(maxsize=1)
def _stream_divergence_notes() -> dict:
    """Hand-maintained sidecar notes for known Dynamo divergences
    (conformance/toolcalling/known-divergences.yaml,
    read from the REAL repo root via FRONTEND_CRATES_ROOT — this module runs
    from the staged copy). Applied at render time so the notes survive capture
    re-records. {family: {case_id: {"v2"|"jail": note}}}."""
    root = os.environ.get("FRONTEND_CRATES_ROOT")
    if not root:
        return {}
    path = Path(root) / "conformance/toolcalling/known-divergences.yaml"
    if not path.exists():
        return {}
    return yaml.safe_load(path.read_text()) or {}


def _known_divergence_note(family: str, case_id: str, key: str) -> str | None:
    """One note from known-divergences.yaml: `v2`/`jail` for the stream-tab
    Dynamo candidates, `stream_vs_batch` for the batch-tab v1-vs-v2 allowlist."""
    return ((_stream_divergence_notes().get(family) or {}).get(case_id) or {}).get(key)


def _stream_divergence_note(family: str, case_id: str, impl: str) -> str | None:
    """The sidecar note for one (family, case, dynamo candidate) — `v2` = the
    dynamo_v2 stream parser, `jail` = the dynamo_v1 jail+batch reference."""
    gen = "v2" if impl == BASELINE_STREAM_IMPL else "jail"
    return _known_divergence_note(family, case_id, gen)


def _stream_version_families(impl: str, version: str) -> set[str] | None:
    """Families covered after resolving `<impl>` through `version`.

    The lowest version is the full anchor; higher directories may contain only
    changed cases. Coverage therefore accumulates through the selected version just
    as `resolve_stream_fixtures.py` accumulates their outputs. `None` means no version
    directory was found, so callers should not gate the candidate.
    """
    target = fixtures._version_sort_key(version)
    found = False
    families: set[str] = set()
    if not _STREAM_SRC.is_dir():
        return None
    corpus = _source_corpus(str(_STREAM_SRC))
    for _key, candidate_version, directory in corpus.version_dirs.get(impl, []):
        if fixtures._version_sort_key(candidate_version) > target:
            continue
        found = True
        families.update(corpus.families_by_directory[directory.name])
    return families if found else None


def _parser_ni_map() -> dict:
    """Map candidate key -> {label, families} for parsers with LIMITED family coverage
    (only the Dynamo v2 parser today, which implements a handful of families). The
    compare JS uses it to render a per-family "not implemented" reason when such a
    parser is the selected Reference, instead of the case-level "not applicable"
    (which is about whether the test case fits the family, not whether the parser
    exists). Coverage is the authoritative `dynamo_v2-<ver>` fixture dir family list."""
    v2ver = _dynamo_v2_version()
    if not v2ver:
        return {}
    fams = sorted(_stream_version_families(BASELINE_STREAM_IMPL, v2ver) or [])
    if not fams:
        return {}
    slug = fixtures._version_slug(v2ver)
    entry = {"label": _full_label(BASELINE_STREAM_IMPL, v2ver, "stream"), "families": fams}
    # The v2 candidate key differs by tab: "<impl>-s-<slug>" on the batch
    # (stream-on-batch) tab, bare "<impl>-<slug>" on the stream tab.
    return {
        f"{BASELINE_STREAM_IMPL}-s-{slug}": entry,
        f"{BASELINE_STREAM_IMPL}-{slug}": entry,
    }


def _stream_version_status_map() -> dict[tuple[str, str], dict[str, dict[str, dict]]]:
    """{(family, sub): {impl: {slug: {block, version, status}}}} for the stream tab.

    Resolve each implementation independently at each of its versions and re-run
    load_all_cases("streamv1") so keys match the rendered table (same assembly +
    split-parent normalization). `block` is the assembled per-impl
    {calls, normal_text} used for the per-cell `data-cmp` signature."""
    impl_versions = _stream_impl_versions()
    if not impl_versions:
        return {}
    resolver = fixtures._RESOLVE_SRC_DIR / "resolve_stream_fixtures.py"
    if not resolver.exists() or not _STREAM_SRC.is_dir():
        return {}
    resolve_stream = _resolver_module("resolve_stream_fixtures").resolve_docs
    corpus = _source_corpus(str(_STREAM_SRC))
    had_captured = "streamv1" in _CAPTURED_WITH_BY_MODE
    saved_captured = _CAPTURED_WITH_BY_MODE.get("streamv1")
    result: dict[tuple[str, str], dict[str, dict[str, dict]]] = {}

    def _raw_chunk_counts(impl, version):
        """{(family, case_id): n_chunks} straight from the <impl>-<version> dir docs.
        The resolver pads a folded case to the input chunk count, so alignment
        (did this capture record per-input-chunk timing?) is only visible here.
        Read out of the shared corpus — these are the same source docs the fold
        already parsed."""
        counts: dict[tuple[str, str], int] = {}
        vdir_name = f"{impl}-{version}"
        for (family, _name), doc in corpus.by_directory.get(vdir_name, {}).items():
            doc = doc or {}
            fam = doc.get("family") or family
            for cid, vc in (doc.get("cases") or {}).items():
                if isinstance(vc, dict) and isinstance(vc.get("chunks"), list):
                    counts[(fam, fixtures.canonical_toolcalling_case_key(cid))] = len(vc["chunks"])
        return counts

    def _record(cases, impl, version):
        slug = fixtures._version_slug(version)
        raw_counts = _raw_chunk_counts(impl, version)
        # Dynamo v1 and v2 are DIFFERENT parsers: v2 (dynamo_v2-0.1.11)
        # implements only a handful of families, while the v1 jail
        # (dynamo_v1-3.0.0) covers all. Gate on the version dir's actual family list
        # to distinguish unsupported families from individual unrecorded cases.
        covered = _stream_version_families(impl, version) if impl in BASELINE_IMPLS else None
        for key, case in cases.items():
            block = _impl_get(case.get("expected") or {}, impl)
            status = _overview_status(case, impl)
            # Capture this impl's per-chunk deltas at THIS version so the tooltip's
            # per-chunk grid can show a column per (impl, version) candidate.
            vchunks = None
            raw = case.get("chunks")
            if isinstance(raw, list):
                vchunks = []
                for ch in raw:
                    if not isinstance(ch, dict):
                        continue
                    exp = _normalize_impl_mapping(ch.get("expected") or {})
                    nt = _normalize_impl_mapping(ch.get("normal_text") or {})
                    vchunks.append({
                        "deltas": _impl_get(exp, impl, []) or [],
                        "normal_text": _impl_get(nt, impl, "") or "",
                    })
            if covered is not None and case.get("__family") not in covered:
                block, status, vchunks = None, "na", None
            # Attach the hand-maintained sidecar note for a KNOWN v2-vs-jail
            # divergence to this candidate's block, so the popup explains the Δ
            # and the cell drops its `?` research-needed suffix.
            if impl in (BASELINE_BATCH_IMPL, BASELINE_STREAM_IMPL) and isinstance(
                block, dict
            ):
                note = _stream_divergence_note(
                    case.get("__family") or key[0], case.get("__case_id") or "", impl
                )
                if note:
                    block = {**block, "explanation": note}
            # Aligned = the raw capture recorded one row per INPUT chunk, so a row
            # index is real consumer-visible timing. The v1 jail captures are
            # emission-packed (fewer rows than inputs) — timing NOT recorded.
            raw_n = raw_counts.get((key[0], case.get("__case_id") or ""))
            n_input = len(raw) if isinstance(raw, list) else 0
            aligned = raw_n is None or raw_n == n_input
            result.setdefault(key, {}).setdefault(impl, {})[slug] = {
                "status": status,
                "block": block,
                "version": version,
                "chunks": vchunks,
                "aligned": aligned,
            }

    def _resolve_and_load(impl, version):
        # Resolve in memory and read the docs directly. Staging each selection to a
        # tempdir only to parse it straight back was the bulk of the render's time.
        # The docs are stream-only, so load_all_cases finds no batch docs to attach
        # batch_expected from — same as when the staged tree held stream files alone.
        docs, _folded = resolve_stream(
            _STREAM_SRC, [f"{impl}-{version}"], corpus=corpus, implementations={impl}
        )
        cases, _labels = load_all_cases("streamv1", docs=docs, implementations={impl})
        return cases

    try:
        for impl, versions in impl_versions.items():
            for version in versions:
                _record(_resolve_and_load(impl, version), impl, version)
    finally:
        # load_all_cases stamps this per call; put the pinned render's value back.
        if had_captured:
            _CAPTURED_WITH_BY_MODE["streamv1"] = saved_captured
        else:
            _CAPTURED_WITH_BY_MODE.pop("streamv1", None)
    return result


# Comparison-signature semantics moved to markers.py (DIS-2434): single-sourced with
# the structured comparison model the JS view consumes. Re-exported here so existing
# callers and tests keep referring to them as module attributes.
_canon_call_for_sig = markers._canon_call_for_sig
_candidate_sig = markers.candidate_sig


# --- merged compare model ("Tool Calling (batch data)" tab) ---------------------
# The merged tab renders the v1 batch grid, but each cell compares BOTH parser
# flavors over the same batch text: the versioned batch parsers (key <impl>-b-<slug>)
# and the stream parsers run on the batch text (key <impl>-s-<slug>). A cell's
# `__cmp` (ordered [{key, label, block}]) drives its data-cmp payload + per-candidate
# tooltip sections; `_merged_candidate_items()` supplies the matching chip list.
def _stream_on_batch_versions() -> dict[str, str]:
    """{impl: display version} for the merged tab's stream candidates. Dynamo -> the
    v2 crate version; peers -> the engine version the batch-on-stream fixtures were
    captured against (their `captured_with`), since those fixtures are the source of
    the stream blocks shown here."""
    out: dict[str, str] = {}
    dynv = _dynamo_v2_version()
    if dynv:
        out[BASELINE_STREAM_IMPL] = dynv
    for fp in sorted(STREAM_ON_BATCH_FIXTURES.glob("*/TOOLCALLING.batch*.yaml")):
        doc = yaml.safe_load(fp.read_text()) or {}
        for impl, ver in (doc.get("captured_with") or {}).items():
            if impl == BASELINE_STREAM_IMPL or impl not in STREAM_IMPL_KEYS:
                continue
            cv = _clean_version(ver)
            if cv:
                out.setdefault(impl, cv)
    return out


def _merged_candidate_items() -> list[dict[str, str]]:
    """Chip list for the merged tab: batch parsers (versioned, keyed <impl>-b-<slug>)
    then the stream parsers on batch (keyed <impl>-s-<slug>). Default layout: A =
    Dynamo v1 batch (from `_candidate_items()`); B = latest vLLM Python + SGLang
    batch; C = everything else (older batch versions + all stream candidates)."""
    out: list[dict[str, str]] = []
    for c in _candidate_items():
        impl = c["impl"]
        out.append({
            "key": f"{impl}-b-{c['slug']}", "impl": impl, "version": c["version"],
            "label": _full_label(impl, c['version'], "batch"),
            "default_bucket": c["default_bucket"],
        })
    stream_versions = _stream_on_batch_versions()
    for impl in STREAM_IMPL_KEYS:
        ver = stream_versions.get(impl)
        slug = fixtures._version_slug(ver) if ver else ""
        out.append({
            "key": f"{impl}-s-{slug}" if slug else f"{impl}-s", "impl": impl, "version": ver,
            "label": _full_label(impl, ver, "stream"),
            "default_bucket": "C",
        })
    return _sort_candidates(out)


def _attach_merged_cmp(cases: dict) -> None:
    """Attach `case['__cmp']` to each merged-tab batch case: the batch parsers (from
    `__ver_status`) plus the stream parsers run on the same batch text (from the
    batch-on-stream overlay). Keys/labels mirror `_merged_candidate_items()` so the
    compare chips, data-cmp payloads, and `cand-<key>` tooltip sections line up."""
    sob_cases = _build_stream_on_batch_cases(cases)
    stream_versions = _stream_on_batch_versions()
    for key, case in cases.items():
        if not isinstance(case, dict):
            continue
        items: list[dict] = []
        ver_status = case.get("__ver_status") or {}
        for impl in ("dynamo_v1", "vllm_python", "sglang_python"):
            # Within an engine, LATEST version first (matches the compare bar).
            entries = sorted(
                (ver_status.get(impl) or {}).items(),
                key=lambda kv: fixtures._version_sort_key(str(kv[1].get("version") or "0")),
                reverse=True,
            )
            for slug, info in entries:
                items.append({
                    "key": f"{impl}-b-{slug}",
                    "label": _full_label(impl, info['version'], "batch"),
                    "block": info.get("block"),
                })
        sob = sob_cases.get(key)
        if sob is not None:
            if sob.get("__known_divergence"):
                case["__known_divergence"] = True
            if sob.get("__baseline_defect"):
                case["dynamo_note"] = sob["dynamo_note"]
            expected = _expected(sob)
            for impl in STREAM_IMPL_KEYS:
                ver = stream_versions.get(impl)
                slug = fixtures._version_slug(ver) if ver else ""
                items.append({
                    "key": f"{impl}-s-{slug}" if slug else f"{impl}-s",
                    "label": _full_label(impl, ver, "stream"),
                    "block": _impl_get(expected, impl),
                })
        if items:
            case["__cmp"] = items


def _compute_stats(
    cases: dict, sub_cases: list[str], families: list[str], cell_text=cell_for
) -> dict[str, int]:
    """Aggregate cell outcomes across the (family × sub_case) grid. `cell_text`
    maps a case to its marker text (cross-engine `cell_for` by default;
    `_sob_cell_text` for the batch-on-stream tab)."""
    s = {
        "families": len(families),
        "sub_cases": len(sub_cases),
        "slots": len(families) * len(sub_cases),
        "real": 0,
        "parity": 0,
        "dynamo_only": 0,
        "documented": 0,
        "research": 0,
        "errors": 0,
        "na": 0,
        "missing": 0,
        "todo": 0,
    }
    for fam in families:
        for sub in sub_cases:
            case = cases.get((fam, sub))
            text = cell_text(case)
            if text == "—":
                s["missing"] += 1
                continue
            if text == "n/a":
                s["na"] += 1
                continue
            if text == "…":
                # Un-implemented Dynamo v2 family: counted as plain n/a in the stats,
                # like the v1 table (no distinct "TODO" bucket). The "…" sentinel is
                # kept only to detect all-unimplemented inventory rows (see all_todo).
                s["na"] += 1
                continue
            s["real"] += 1
            if text == "=":
                s["parity"] += 1
            # `text` here is the internal compact agreement string from `cell_for` /
            # `_stream_xeng_marker` (never shown to users). A bare Dynamo-only token —
            # `·`, or the Dynamo batch/stream sentinel — buckets as dynamo_only.
            elif text == "·" or text in {"D", "D_rb", "D_rs"}:
                s["dynamo_only"] += 1
            elif "!" in text:
                s["errors"] += 1
            elif "↯" in text:
                s["documented"] += 1
            elif "?" in text:
                s["research"] += 1
            else:
                s["documented"] += 1
    return s


def _stream_on_batch_expected(overlay_case: dict, has_batch_text: bool = True) -> dict:
    """Build a standard `expected` block — `{impl: {calls, normal_text}}` (or
    `{unavailable}`) — from one batch-on-stream overlay case.

    The overlay records each engine's STREAMING parse of the v1 batch text. Some
    overlay rows are taxonomy placeholders with no batch `model_text`; render
    those as structural unavailability instead of claiming the parser is missing.
    Peer outputs are tagged with a `reason` so the divergence reads as intentional
    (a documented difference), not research-needed — text-vs-token streaming differs
    by design.
    """
    expected: dict = {}
    overlay_case = _normalize_impl_mapping(overlay_case)
    dynamo = _impl_get(overlay_case, BASELINE_STREAM_IMPL)
    if isinstance(dynamo, dict) and ("calls" in dynamo or "normal_text" in dynamo):
        expected[BASELINE_STREAM_IMPL] = {
            "calls": dynamo.get("calls") or [],
            "normal_text": dynamo.get("normal_text") or "",
        }
    elif not has_batch_text:
        expected[BASELINE_STREAM_IMPL] = {"unavailable": "No batch model_text for this case."}
    else:
        expected[BASELINE_STREAM_IMPL] = {
            "unavailable": "Dynamo parser v2 stream parser not yet implemented for this family"
        }
    for impl in PEER_IMPL_KEYS:
        block = _impl_get(overlay_case, impl)
        if not isinstance(block, dict):
            expected[impl] = {
                "unavailable": "No batch-on-stream capture for this engine."
            }
        elif "unavailable" in block:
            expected[impl] = {"unavailable": block["unavailable"]}
        else:
            expected[impl] = {
                "calls": block.get("calls") or [],
                "normal_text": block.get("normal_text") or "",
                "explanation": (
                    f"Captured from the {IMPL_DISPLAY[impl]} streaming parser on the batch text. "
                    "Streaming output differs from Dynamo parser v2 token-incremental "
                    "behavior by design (text vs token streaming)."
                ),
            }
    return expected


def _load_stream_on_batch_overlay() -> dict[tuple[str, str], dict]:
    """`{(family, case_id): {impl: stream_block}}` from the batch-on-stream overlay."""
    overlay: dict[tuple[str, str], dict] = {}
    if not STREAM_ON_BATCH_FIXTURES.exists():
        return overlay
    for fp in sorted(STREAM_ON_BATCH_FIXTURES.glob("*/TOOLCALLING.batch*.yaml")):
        doc = yaml.safe_load(fp.read_text()) or {}
        family = doc.get("family") or fp.parent.name
        for cid, block in (doc.get("cases") or {}).items():
            overlay[(family, cid)] = block
    return overlay


def _build_stream_on_batch_cases(batch_cases: dict) -> dict:
    """Standard `{(family, sub): case}` for the batch-on-stream tab.

    Reuses the v1 batch taxonomy and input text. `expected` holds each engine's
    STREAMING output (from the overlay); `batch_expected` holds the v1 batch
    reference. The cell renderer compares the two per engine (stream-vs-batch).
    Sub-cases with no overlay sample are omitted (rendered as `—`).
    """
    overlay = _load_stream_on_batch_overlay()
    cases: dict[tuple[str, str], dict] = {}
    for (family, sub), bcase in batch_cases.items():
        cid = bcase.get("__case_id") or f"TOOLCALLING.batch.{sub}"
        overlay_case = overlay.get((family, cid))
        if overlay_case is None and cid.endswith(".a"):
            # The generator promotes a bare parent id (e.g. `…13`) to its first
            # numeric sub-case; the
            # overlay may still key it by the bare parent id. Fall back to that.
            overlay_case = overlay.get((family, cid[:-2]))
        if overlay_case is None:
            continue
        cases[(family, sub)] = {
            "__family": family,
            "__case_id": cid,
            "__fixture_path": bcase.get("__fixture_path", ""),
            "description": bcase.get("description"),
            "model_text": bcase.get("model_text"),
            "ref": bcase.get("ref"),
            # Baseline rationale lives in the local overlay; fall back to the v1
            # batch fixture if it carries one.
            "dynamo_note": overlay_case.get("dynamo_note") or bcase.get("dynamo_note"),
            "expected": _stream_on_batch_expected(
                overlay_case, has_batch_text="model_text" in bcase
            ),
            "batch_expected": _normalize_impl_mapping(bcase.get("expected") or {}),
        }
        # A documented v1-batch vs v2-stream divergence (the batch-via-stream
        # parity allowlist): note the v2 block (popup `explanation:`) and flag
        # the case so the cell renders the `≠` known-divergence suffix. The
        # generator promotes a bare parent id to `.a` — fall back like the
        # overlay lookup above so `…batch.13` matches the promoted first sub-case.
        note = _known_divergence_note(family, cid, "stream_vs_batch")
        if note is None and cid.endswith(".a"):
            note = _known_divergence_note(family, cid[:-2], "stream_vs_batch")
        if note:
            blk = cases[(family, sub)]["expected"].get(BASELINE_STREAM_IMPL)
            if isinstance(blk, dict) and "unavailable" not in blk:
                blk["explanation"] = note
            cases[(family, sub)]["__known_divergence"] = True
        defect = _known_divergence_note(family, cid, "baseline_defect")
        if defect:
            # A captured defect is not an intended difference. Keep unequal
            # signatures and the existing research-needed marker visible; the
            # diagnostic explains the exact baseline without granting a badge.
            case = cases[(family, sub)]
            prior = case.get("dynamo_note")
            case["dynamo_note"] = f"{prior}\n{defect}" if prior else defect
            case["__baseline_defect"] = True
    return cases


def _filter_family(
    cases: dict[tuple[str, str], dict],
    labels: dict[str, str],
    family_filter: str | None,
) -> tuple[dict[tuple[str, str], dict], dict[str, str]]:
    if family_filter is None:
        return cases, labels
    return (
        {k: v for k, v in cases.items() if k[0] == family_filter},
        {k: v for k, v in labels.items() if k == family_filter},
    )


def _load_panel_cases(
    mode: str, family_filter: str | None = None
) -> dict[str, object]:
    """Load + augment the cases for one toolcalling tab. Shared by the HTML renderer
    (`_load_html_panel`) and the JSON model builder so both see the identical
    ver_status / merged-cmp attachment and display grouping."""
    cases, labels = load_all_cases(mode)
    cases, labels = _filter_family(cases, labels, family_filter)
    # TC v1 (batch) tab: attach per-impl per-version status so cells can emit
    # data-status-<impl>-<slug> for the version radios. Other tabs aren't versioned.
    if mode == "batch":
        ver_status = _batch_version_status_map()
        for key, case in cases.items():
            if isinstance(case, dict) and key in ver_status:
                case["__ver_status"] = ver_status[key]
        # Merged "Tool Calling (batch data)" tab: augment each cell so the compare
        # model spans both the batch parsers (from __ver_status) and the stream
        # parsers run on the same batch text (batch-on-stream overlay).
        _attach_merged_cmp(cases)
    elif mode == "streamv1":
        # Stream analogue of the batch version map: per-cell candidates are the
        # peer engine versions (vLLM 0.23.0/0.24.0, SGLang 0.5.12.post1/0.5.14),
        # plus single-version Dynamo v2 + vLLM Rust.
        ver_status = _stream_version_status_map()
        for key, case in cases.items():
            if isinstance(case, dict) and key in ver_status:
                case["__ver_status"] = ver_status[key]
    sub_cases = _discover_sub_cases(mode, cases)
    no_vllm, no_sglang = _derive_no_peer_sets(cases)
    top_n, others = _build_display_groups(cases, labels)
    # The streamv1 tab uses the stream comparison: color = stream-vs-own-batch,
    # agreement = cross-engine stream agreement (each engine's stream parser vs the
    # others').
    comparison = "stream_vs_batch" if mode == "streamv1" else "cross_engine"
    return {
        "mode": mode,
        "cases": cases,
        "labels": labels,
        "sub_cases": sub_cases,
        "no_vllm": no_vllm,
        "no_sglang": no_sglang,
        "top_n": top_n,
        "others": others,
        "comparison": comparison,
        "has_cases": bool(cases),
    }




def _tab_label(
    prefix: str,
    data: str,
    parser: str | None,
    v2: bool,
    data_word: bool = True,
    on_parser: bool = True,
) -> tuple[str, str]:
    """Build a tab label as `<prefix> vN (<data> data on <parser>-parser)`.
    Returns (plain, html); the html form wraps the parenthetical in a smaller-font
    span (`tab-sub`) and color-codes the words "batch"/"stream" (`w-batch`/`w-stream`)
    so the two axes are distinguishable. `data` is "batch" or "stream". `parser` is
    "batch"/"stream", or None for a bare "parser" (reasoning has a single parser, not
    a batch/stream split). `data_word=False` drops the literal " data" word.
    `on_parser=False` drops the `on <parser>-parser` clause entirely, so reasoning
    renders `(batch data)` — the parser axis is meaningless there (one parser)."""
    version = "v2" if v2 else "v1"
    dword = " data" if data_word else ""

    def _w(word: str) -> str:
        return f'<span class="w-{word}">{word}</span>'

    if on_parser:
        parser_plain = f"{parser}-parser" if parser else "parser"
        parser_html = f"{_w(parser)}-parser" if parser else "parser"
        on_plain = f" on {parser_plain}"
        on_html = f" on {parser_html}"
    else:
        on_plain = on_html = ""
    plain = f"{prefix} {version} ({data}{dword}{on_plain})"
    sub_html = f"({_w(data)}{dword}{on_html})"
    return plain, f'{prefix} {version} <span class="tab-sub">{sub_html}</span>'


# ===== Structured JSON model builders (DIS-2434) ================================
# Python computes the model; the JS view renders it. The comparison SEMANTICS stay in
# markers.py (cmp_model / comparison_facts / _overview_status / _sob_status); these
# functions orchestrate them into the schema documented in model.py. No verdict logic
# is reimplemented in JS.
import model as _model  # noqa: E402  (schema + serialization; leaf module)

_MODE_PAREN_RE = re.compile(r"(?:·\s*(batch|stream)(?:\s*\([^)]*\))?|\(([^)]*)\))(?:\s+\(source unavailable\))?\s*$")


def _cand_engine_group(key: str) -> str:
    for prefix in ("dynamo", "vllm", "sglang"):
        if key.startswith(prefix):
            return prefix
    return key.split("-")[0]


def _parse_mode_of_label(label: str) -> str | None:
    m = _MODE_PAREN_RE.search(label)
    if not m:
        return None
    inner = m.group(1) or m.group(2)
    if "stream" in inner:
        return "stream"
    if "batch" in inner:  # includes "jail+batch"
        return "batch"
    return None


def _version_of_label(label: str) -> str | None:
    m = _CANDIDATE_VERSION_RE.search(label)
    return m.group(1) if m else None


def _candidate_model(items: list[dict]) -> list[dict]:
    """Normalize a compare-bar candidate list to the model schema. The version is taken
    from the source item when present, else parsed from the label ("… 3.0.0 (batch)")
    so every candidate carries a `version` the view + guards can rely on."""
    out = []
    for it in items:
        key = it["key"]
        label = it["label"]
        out.append({
            "key": key,
            "impl": _cand_engine_group(key),
            "label": label,
            "label_html": _candidate_label_html(label),
            "default_bucket": it.get("default_bucket", "C"),
            "version": it.get("version") or _version_of_label(label),
            "parse_mode": _parse_mode_of_label(label),
        })
    return out


def _columns_model(mode: str, sub_cases: list[str]) -> tuple[list[dict], list[dict]]:
    descriptions = _parse_subcase_descriptions(mode)
    groups: list[dict] = []
    cols: list[dict] = []
    for run in _subcase_runs(mode, sub_cases):
        col_group = _subcase_group_key(mode, run[0])
        groups.append({
            "key": col_group,
            "label": _subcase_group_label(mode, run[0]),
            "band": _subcase_band_class(mode, run[0]),
            "span": len(run),
        })
        for sub in run:
            cols.append({
                "sub": sub,
                "group_key": col_group,
                "band": _subcase_band_class(mode, sub),
                "label": sub,
                "desc": descriptions.get(sub) or descriptions.get(sub.split(".")[0]) or "",
            })
    return groups, cols


def _explicit_case_schemas(tools: object, *, shared_signature: str | None = None) -> list[dict] | None:
    """Keep only named tools with an explicitly attached parameters schema."""
    if not isinstance(tools, list):
        return None
    schemas = [
        {"name": tool["name"], "parameters": tool["parameters"]}
        for tool in tools
        if isinstance(tool, dict) and isinstance(tool.get("name"), str)
        and "parameters" in tool and tool["parameters"] is not None
    ]
    if not schemas:
        return None
    if shared_signature is not None and _schema_signature(schemas) == shared_signature:
        return None
    return schemas


def _unified_case_schemas(input_case: dict, shared_signature: str) -> list[dict] | None:
    request = input_case.get("request") or {}
    tools = request.get("tools", input_case.get("tools"))
    return _explicit_case_schemas(tools, shared_signature=shared_signature)


def _schema_signature(schemas: list[dict]) -> str:
    return json.dumps(schemas, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _schema_variants_by_family(family_schemas: dict[str, list[dict] | None]) -> list[dict] | None:
    """Deduplicate case schemas and retain the families that authored each variant."""
    variants: dict[str, dict] = {}
    for family, schemas in family_schemas.items():
        if not schemas:
            continue
        signature = _schema_signature(schemas)
        variant = variants.setdefault(signature, {"families": [], "tools": schemas})
        variant["families"].append(family)
    return list(variants.values()) or None


def _output_block_model(blk: object) -> dict | None:
    """A candidate's expected output block reduced to the model's raw fields."""
    if not isinstance(blk, dict):
        return None
    blk = capture_stimulus.normalize_unavailable(blk)
    out: dict[str, Any] = {}
    if "unavailable" in blk:
        out["unavailable"] = blk["unavailable"]
        if "unavailable_code" in blk:
            out["unavailable_code"] = blk["unavailable_code"]
    if "exception" in blk:
        out["exception"] = blk["exception"]
    if "error" in blk:
        out["error"] = blk["error"]
    if "calls" in blk or "normal_text" in blk:
        out["calls"] = blk.get("calls") or []
        out["normal_text"] = blk.get("normal_text") or ""
    expl = _explanation(blk)
    if expl:
        out["explanation"] = expl
    return out or None


def _cell_candidate_meta(case: dict, output_kind: str) -> tuple[dict, list[dict]]:
    """Reproduce render_cell_html's candidate selection as STRUCTURED data: return
    (cmp_blocks, cand_meta). `cmp_blocks` = {cand_key: raw_block} for markers.cmp_model;
    `cand_meta` is the ordered per-candidate tooltip list {key,label,impl,version,block,
    leak}. Mirrors the __cmp / __ver_status / per-impl branches exactly so the compare
    keys line up with the compare-bar candidates and the JS cand-<key> sections."""
    meta: list[dict] = []
    cmp_items = case.get("__cmp")
    ver_status = case.get("__ver_status")
    if cmp_items:
        for item in cmp_items:
            meta.append({"key": item["key"], "label": item["label"],
                         "version": None, "block_raw": item["block"]})
    elif ver_status:
        # The mode is the TAB's, not a constant: this branch also serves the streamv1
        # tab, where dynamo_v2 and vllm_rust are stream-only impls (impls.py IMPL_SPECS)
        # and can never be "(batch)". Hardcoding it made the tooltip header contradict
        # the compare bar, which builds the same candidates via _stream_candidate_items.
        # _full_label still maps dynamo_v1 on stream data to "(jail+batch)".
        for impl in ("dynamo_v1", "dynamo_v2", "vllm_rust", "vllm_python", "sglang_python"):
            for slug, info in (ver_status.get(impl) or {}).items():
                meta.append({"key": f"{impl}-{slug}", "impl": impl,
                             "label": _full_label(impl, info["version"], output_kind),
                             "version": info["version"], "block_raw": info["block"]})
    else:
        expected = _expected(case)
        for impl in STREAM_IMPL_KEYS:
            meta.append({"key": impl, "impl": impl,
                         "label": f"{_IMPL_DISPLAY[impl]} {output_kind}",
                         "version": _v2_display_version(impl), "block_raw": _impl_get(expected, impl)})
    if case.get("golden"):
        meta.append({"key": "golden", "label": "GOLDEN (oracle)", "version": None,
                     "block_raw": case["golden"]})
    meta = _sort_candidates(meta)
    cmp_blocks = {m["key"]: m["block_raw"] for m in meta}
    for m in meta:
        blk = m.pop("block_raw")
        m["impl"] = _cand_engine_group(m["key"])
        m["parse_mode"] = _parse_mode_of_label(m["label"])
        m["leak"] = isinstance(blk, dict) and _block_tool_call_leaks(blk)
        m["block"] = _output_block_model(blk)
    return cmp_blocks, meta


def _chunk_model(chunk: dict) -> dict:
    return {
        "delta_text": chunk.get("delta_text", ""),
        "delta_token_ids": chunk.get("delta_token_ids"),
        "finish_reason": chunk.get("finish_reason"),
        # Per-impl streamed deltas + residual normal_text drive the per-chunk chart.
        "expected": _normalize_impl_mapping(chunk.get("expected") or {}),
        "normal_text": (
            _normalize_impl_mapping(chunk["normal_text"])
            if isinstance(chunk.get("normal_text"), dict)
            else chunk.get("normal_text")
        ),
    }


def _input_model(case: dict) -> dict:
    family = case.get("__family")
    chunks = case.get("chunks")
    if isinstance(chunks, list) and chunks:
        return {"kind": "chunks", "text": None, "family": family,
                "chunks": [_chunk_model(c) for c in chunks if isinstance(c, dict)]}
    model_text = case.get("model_text")
    # An EMPTY model_text is still a text input, not a missing one — dropping it to
    # `kind: None` made `TOOLCALLING.batch.9.a` ("Empty model text") indistinguishable
    # from a case with no fixture, so the grammar popup reported "no input recorded"
    # for every family instead of "empty input".
    if isinstance(model_text, str):
        return {"kind": "text", "text": model_text, "chunks": None, "family": family}
    return {"kind": None, "text": None, "chunks": None, "family": family}


def _toolcalling_tooltip_model(case: dict, output_kind: str, cand_meta: list[dict],
                               dyn: object, cmp_blocks: dict) -> dict:
    family = case.get("__family")
    case_id = case.get("__case_id", "")
    head = f"{case_id} — {family}" if (case_id and family) else (case_id or str(family or ""))
    impl_keys = _impl_keys_for_output_kind(output_kind)
    baseline = baseline_impl(impl_keys)
    expected = _expected(case)
    reason_impls = set(impl_keys) | {BASELINE_BATCH_IMPL, BASELINE_STREAM_IMPL}
    reason_cmp = markers.cmp_model({**cmp_blocks, **{
        "__reason_" + impl: _impl_get(expected, impl) for impl in sorted(reason_impls)
    }})
    reason_entries = {impl: reason_cmp["__reason_" + impl] for impl in reason_impls}
    reasons = _model.comparison_reasons(
        markers.comparison_facts(case, impl_keys, baseline), _IMPL_DISPLAY, baseline, reason_entries,
    )
    if case.get("__known_divergence"):
        batch_key = next((key for key in cmp_blocks if key.startswith(BASELINE_BATCH_IMPL + "-b-")), None)
        for stream_key, stream_block in cmp_blocks.items():
            if not batch_key or not stream_key.startswith(BASELINE_STREAM_IMPL + "-s-"):
                continue
            note = _explanation(stream_block)
            if not note:
                continue
            pair_entries = {BASELINE_BATCH_IMPL: reason_cmp[batch_key],
                            BASELINE_STREAM_IMPL: reason_cmp[stream_key]}
            known_reasons = _model.comparison_reasons(
                [{"impl": BASELINE_STREAM_IMPL, "agrees": False, "reason": note, "intentional": True}],
                _IMPL_DISPLAY, BASELINE_BATCH_IMPL, pair_entries,
            )
            reasons.extend(reason for reason in known_reasons if reason not in reasons)
    dyn_leak = _dynamo_tool_call_leak(dyn) if isinstance(dyn, dict) else None
    baseline_block = None
    dyn_batch = _impl_get(case.get("batch_expected") or {}, BASELINE_BATCH_IMPL)
    if isinstance(dyn_batch, dict) and ("calls" in dyn_batch or "normal_text" in dyn_batch):
        baseline_block = {"impl": BASELINE_BATCH_IMPL,
                          "label": f"{_IMPL_DISPLAY[BASELINE_BATCH_IMPL]} batch parser",
                          "block": _output_block_model(dyn_batch)}
    return {
        "head": head,
        "description": case.get("description") or "",
        "input": _input_model(case),
        "candidates": cand_meta,
        "baseline": baseline_block,
        "reasons": reasons,
        "dynamo_notes": [[lbl, txt] for lbl, txt in _dynamo_note_sections(case)],
        "refs": [[lbl, val] for lbl, val in (("Ref", case.get("ref")),
                                             ("Spec ref", case.get("spec_ref"))) if val],
        "leak_note": str(dyn_leak) if dyn_leak else None,
        "na_note": None,
    }


def _toolcalling_cell_model(case: dict | None, mode: str, family: str, sub: str,
                            output_kind: str, comparison: str,
                            href_rewrite) -> dict:
    col_group = _subcase_group_key(mode, sub)
    band = _subcase_band_class(mode, sub)
    if case is None:
        return _model.missing_cell(sub, family, col_group, band,
                                   head=f"TOOLCALLING.{mode}.{sub}")
    impl_keys = _impl_keys_for_output_kind(output_kind)
    baseline = baseline_impl(impl_keys)
    sob = comparison == "stream_vs_batch"
    cmp_blocks, cand_meta = _cell_candidate_meta(case, output_kind)
    cmp = markers.cmp_model(cmp_blocks) if cmp_blocks else None
    facts = markers.comparison_facts(case, impl_keys, baseline)
    status = _sob_status(case, BASELINE_STREAM_IMPL) if sob else _overview_status(case, baseline)
    dyn = _impl_get(case.get("expected") or {}, baseline)
    fp = case.get("__fixture_path", "")
    href = href_rewrite(common.fixture_href(fp)) if fp else None
    if not isinstance(dyn, dict) and not case.get("golden"):
        # n/a stub: case has only `explanation:` (no `expected:` block).
        tooltip = {"head": f"{case.get('__case_id','')} — {family}",
                   "description": case.get("description") or "",
                   "input": _input_model(case), "candidates": [], "baseline": None,
                   "reasons": [], "dynamo_notes": [], "refs": [], "leak_note": None,
                   "na_note": _explanation(case)}
        return _model.make_cell(kind="cell", case_id=case.get("__case_id"), family=family,
                                sub=sub, col_group=col_group, band=band, fixture_href=href,
                                status=status, cmp=cmp, facts=facts, tooltip=tooltip,
                                known_divergence=bool(case.get("__known_divergence")))
    tooltip = _toolcalling_tooltip_model(case, output_kind, cand_meta, dyn or {}, cmp_blocks)
    return _model.make_cell(kind="cell", case_id=case.get("__case_id"), family=family,
                            sub=sub, col_group=col_group, band=band, fixture_href=href,
                            status=status, cmp=cmp, facts=facts, tooltip=tooltip,
                            red_on_diff=bool(case.get("golden")),
                            known_divergence=bool(case.get("__known_divergence")))


def _toolcalling_tab_model(spec: dict, href_rewrite, parser_stream_context: str) -> dict:
    mode = spec["mode"]
    cases = spec["cases"]
    sub_cases = spec["sub_cases"]
    comparison = spec["comparison"]
    no_vllm, no_sglang = spec["no_vllm"], spec["no_sglang"]
    output_kind = "batch" if parser_stream_context == "batch" else "stream"
    cell_text = (
        (lambda case: _sob_cell_text(case, parser_stream_context))
        if comparison == "stream_vs_batch"
        else cell_for
    )
    refs = _build_family_to_rust_ref()
    inheritance = _build_family_inheritance(refs)
    column_groups, cols = _columns_model(mode, sub_cases)
    for col in cols:
        variants = _schema_variants_by_family({
            family: _explicit_case_schemas((cases.get((family, col["sub"])) or {}).get("tools"))
            for family in [row[1] for row in spec["top_n"] + spec["others"]]
        })
        if variants:
            col["schemas"] = variants

    def row_model(model_label: str, family: str) -> dict:
        all_todo = sub_cases and all(
            cell_text(cases.get((family, sub))) == "…" for sub in sub_cases
        )
        peer_output_exists = any(
            _has_peer_output(cases.get((family, sub))) for sub in sub_cases
        )
        cells: dict[str, dict] = {}
        for sub in sub_cases:
            if all_todo and not peer_output_exists:
                cells[sub] = _model.blank_cell(sub, _subcase_group_key(mode, sub),
                                               _subcase_band_class(mode, sub))
            else:
                cells[sub] = _toolcalling_cell_model(
                    cases.get((family, sub)), mode, family, sub, output_kind,
                    comparison, href_rewrite,
                )
        return {
            "section": None,
            "model_label": model_label,
            "model_label_html": _model_label_html(model_label),
            "family": family,
            "parser": {"html": href_rewrite(_parser_cell_html(
                family, refs, no_vllm, no_sglang, inheritance,
                stream_context=parser_stream_context))},
            "cells": cells,
        }

    rows: list[dict] = []
    if spec["top_n"]:
        rows.append({"section": "Top-N models", "model_label": "Top-N models",
                     "model_label_html": "", "family": None, "parser": None, "cells": {}})
        rows.extend(row_model(m, f) for m, f in spec["top_n"])
    if spec["others"]:
        rows.append({"section": "Others", "model_label": "Others",
                     "model_label_html": "", "family": None, "parser": None, "cells": {}})
        rows.extend(row_model(m, f) for m, f in spec["others"])

    all_families = [f for _, f in spec["top_n"]] + [f for _, f in spec["others"]]
    stats = _compute_stats(cases, sub_cases, all_families, cell_text=cell_text)
    return {
        "id": f"tab-{mode}",
        "kind": "toolcalling",
        "mode": mode,
        "column_groups": column_groups,
        "columns": cols,
        "rows": rows,
        "stats": stats,
        "glossary": _glossary_groups(mode, _parse_subcase_descriptions(mode), sub_cases),
    }


def _fixture_href_rewriter(stage_dir: str, fixture_href_root: str):
    def rewrite(text: str) -> str:
        return text.replace(
            f'href="{stage_dir}/fixtures/', f'href="{fixture_href_root}'
        ).replace('href="fixtures/', f'href="{fixture_href_root}')
    return rewrite


def _plain_href_rewriter(stage_dir: str, fixture_href_root: str):
    """A bare fixture href (no href="...") rewriter for cell links."""
    def rewrite(href: str | None) -> str | None:
        if not href:
            return href
        return href.replace(f"{stage_dir}/fixtures/", fixture_href_root).replace(
            "fixtures/", fixture_href_root, 1
        ) if href.startswith((f"{stage_dir}/fixtures/", "fixtures/")) else href
    return rewrite


_UNIFIED_LEAK_MARKERS = ("<|", "|>", "<think>", "</think>", "◁", "<channel", "channel|>")

# Per-family markers whose presence in a visible payload (text/reasoning) is a leak
# but which the shared markers above miss. gemma4's channel opener leaves `thought\n`;
# qwen3's tool envelope has NO `<|...|>` sentinels, so a `<tool_call>...</tool_call>`
# leaking into reasoning_content is invisible to the shared list — enumerate it
# explicitly (kimi's tool/section markers already contain `<|`/`|>`).
_UNIFIED_FAMILY_LEAK_MARKERS = {
    "gemma4": ("thought\n",),
    "qwen3": ("<tool_call>", "</tool_call>", "<function=", "</function>",
              "<parameter=", "</parameter>"),
}

_UNIFIED_LEGACY_PEER_VERSION = "0.25.1"
_UNIFIED_PEER_SOURCES = dict(UNIFIED_PEER_SOURCES)

for _batch_impl in UNIFIED_BATCH_IMPLS:
    _UNIFIED_PEER_SOURCES[_batch_impl] = {
        "impl": next(spec.engine for spec in IMPL_SPECS if spec.key == BATCH_SOURCE_IMPL[_batch_impl]), "label": batch_capture_label(_batch_impl, "{version}"),
        "stream": False, "legacy_key": None, "batch": True,
    }


def _unified_classify(family: str, golden: list, got: list) -> str:
    """Classify a captured event list against the golden oracle. Python port of
    the Rust `classify` in tests/unified_render.rs so vLLM (captured) and Dynamo
    (LIVE-in-Rust) are scored the same way against GOLDEN."""
    if golden == got:
        return "MATCH"

    # Shared markers + any family-specific markup that leaks invisibly to them (e.g.
    # gemma4 `thought\n`, qwen3 `<tool_call>`/`<function=`/`<parameter=`).
    markers = _UNIFIED_LEAK_MARKERS + _UNIFIED_FAMILY_LEAK_MARKERS.get(family, ())

    def _leaks(evs):
        return any(e.get("kind") in ("text", "reasoning")
                   and any(m in (e.get("text") or "") for m in markers)
                   for e in evs)

    if _leaks(got):
        return "LEAK"

    def _rcount(evs):
        return sum(1 for e in evs if e.get("kind") == "reasoning")

    if _rcount(got) < _rcount(golden):
        return "MERGE"

    def _calls(evs):
        return [(e.get("name"), json.dumps(e.get("arguments"), sort_keys=True))
                for e in evs if e.get("kind") == "tool_call"]

    gc, tc = _calls(golden), _calls(got)
    if (len(gc) == len(tc) and all(a[0] == b[0] for a, b in zip(gc, tc))
            and any(a[1] != b[1] for a, b in zip(gc, tc))):
        return "ARG_MISMATCH"

    def _cat(evs, want_reason):
        kind = "reasoning" if want_reason else "text"
        return "".join((e.get("text") or "") for e in evs if e.get("kind") == kind)

    if _cat(golden, True) == _cat(got, True) and _cat(golden, False) == _cat(got, False):
        return "ORDER"
    return "LOSS"


def _assemble_stream(chunk_deltas: list, *, recorded_assembly: list | None = None) -> list:
    """Assemble the FINAL ordered event list from a parser's per-chunk STREAMED deltas
    (not its batch final message). Coalesces consecutive reasoning/text runs and joins
    per-call tool-argument fragments (a delta with a name starts a new call; nameless
    arg deltas append to the current one). This is what a streaming client actually
    receives — and, unlike the batch assembly, it preserves reasoning<->tool order."""
    events: list = []
    cur_tool = None  # index in `events` of the tool call currently receiving arg deltas
    for deltas in chunk_deltas:
        for dl in deltas or []:
            k = dl.get("kind")
            if k in ("reasoning", "text"):
                cur_tool = None
                if events and events[-1]["kind"] == k:
                    events[-1]["text"] += dl.get("text") or ""
                else:
                    events.append({"kind": k, "text": dl.get("text") or ""})
            elif k == "tool_call":
                name, args = dl.get("name"), dl.get("arguments")
                if name:  # a name delta opens a new call
                    events.append({
                        "kind": "tool_call",
                        "name": name,
                        "_raw": args or "",
                        "_complete": dl.get("complete", True),
                    })
                    cur_tool = len(events) - 1
                elif cur_tool is not None and args:
                    prev = events[cur_tool].get("_raw", "")
                    if isinstance(prev, str) and isinstance(args, str):
                        events[cur_tool]["_raw"] = prev + args
                    else:
                        # sglang can emit a COMPLETE dict/list arg as a fragment; never
                        # string-concat across mixed types (TypeError). A dict/list arg
                        # supersedes; the finalizer below reads it as the resolved object.
                        events[cur_tool]["_raw"] = args
                if cur_tool is not None and dl.get("complete", True):
                    events[cur_tool]["_complete"] = True
    events = [e for e in events if e.get("kind") != "tool_call" or e.get("_complete", True)]
    malformed = set()
    for position, e in enumerate(events):
        if e["kind"] == "tool_call":
            raw = e.pop("_raw", "")
            e.pop("_complete", None)
            if isinstance(raw, (dict, list)):
                e["arguments"] = raw
            elif not (raw or "").strip():
                e["arguments"] = {}
            else:
                try:
                    e["arguments"] = json.loads(raw)
                except (ValueError, TypeError):
                    malformed.add(position)
                    e["arguments"] = raw
    if malformed and recorded_assembly is not None:
        calls = [(position, event) for position, event in enumerate(events) if event["kind"] == "tool_call"]
        recorded = [event for event in recorded_assembly if event["kind"] == "tool_call"]
        # Native P3 uses {}, but split-era captures preserve invalid JSON bytes.
        # Require the entire call sequence to align before using recorded fallbacks;
        # split batch assembly can differ from stream order and must not replace it.
        if len(calls) == len(recorded) and all(
            event["name"] == observed["name"] and (
                event["arguments"] == observed["arguments"] or
                position in malformed and observed["arguments"] == {}
            ) for (position, event), observed in zip(calls, recorded)
        ):
            for (position, event), observed in zip(calls, recorded):
                if position in malformed:
                    event["arguments"] = observed["arguments"]
    return events


def _unified_base(artifact_root: Path) -> Path:
    """Where the unified capture YAMLs live. In a packaged render they come from the
    extracted fixture snapshot (CONFORMANCE_FIXTURES_ROOT/unified — the
    conformance/fixtures-unified-v2 history); locally after a harness run
    they sit in the loose build tree conformance/unified/."""
    snap = os.environ.get("CONFORMANCE_FIXTURES_ROOT")
    if snap and (Path(snap) / "unified").is_dir():
        return Path(snap) / "unified"
    return artifact_root / "conformance/unified"


def _load_capture(artifact_root: Path, name: str, version_key: str) -> tuple[dict, str | None]:
    """Load a persisted LIVE capture artifact. Returns (results_by_id, version).
    Empty if absent."""
    cp = _unified_base(artifact_root) / name
    if not cp.exists():
        return {}, None
    data = yaml.safe_load(cp.read_text())
    return data.get("results", {}), data.get(version_key)


def _load_vllm_capture(artifact_root: Path) -> tuple[dict, str | None]:
    """vLLM Python parser capture (capture_vllm_unified.py, ParserManager combined path)."""
    return _load_capture(artifact_root, "vllm_capture.yaml", "vllm_version")


def _load_vllm_rust_capture(artifact_root: Path) -> tuple[dict, str | None]:
    """Native vLLM Rust UnifiedParser capture (capture_vllm_rust_unified.py)."""
    return _load_capture(artifact_root, "vllm_rust_capture.yaml", "vllm_rust_version")


def _load_sglang_capture(artifact_root: Path) -> tuple[dict, str | None]:
    """SGLang Python capture (capture_sglang_unified.py). SGLang has no unified parser —
    always a reasoning detector then a tool detector (Combined/split)."""
    return _load_capture(artifact_root, "sglang_capture.yaml", "sglang_version")


@functools.cache
def _dynamo_v2_producer() -> dict:
    # The renderer is copied into /tmp; the checker must inspect the source checkout.
    source_root = Path(os.environ.get("FRONTEND_CRATES_ROOT", Path(__file__).resolve().parents[3]))
    result = subprocess.run(
        [sys.executable, str(source_root / "conformance/utils/src/dynamo_version.py"),
         "--repo-root", str(source_root), "--format", "json"],
        check=True, capture_output=True, text=True,
    )
    return json.loads(result.stdout)


def _unified_dynamo_label() -> str:
    return _dynamo_v2_producer()["crate_version"]


def _unified_capture_failure(record: dict | None) -> dict:
    if record is None:
        return {"unavailable": "No captured result", "unavailable_code": "missing_capture"}
    record = capture_stimulus.normalize_unavailable(record)
    failure = {key: record[key] for key in ("error", "unavailable") if record.get(key)}
    if "unavailable" in failure and "unavailable_code" in record:
        failure["unavailable_code"] = record["unavailable_code"]
    return failure


def _unified_chunk_rows(input_chunks, capture_chunks):
    """Show the terminal observation when a published stimulus uses implicit EOF."""
    delivery = list(input_chunks)
    if (len(capture_chunks) == len(delivery) + 1
            and (not delivery or delivery[-1].get("delta_text") != "‹finish›")):
        delivery.append({"delta_text": "‹finish›"})
    return [
        {"delta_text": chunk.get("delta_text", ""),
         "dynamo": (capture_chunks[index].get("expected") if index < len(capture_chunks) else []) or []}
        for index, chunk in enumerate(delivery)
    ]


def _load_unified_fixtures(base: Path):
    """Read the exploded per-case / per-family / per-version unified fixtures (same
    layout as toolcalling/fixtures-stream-v1: inputs/ + golden/ + <impl>-<version>/)
    and reconstruct the (cases feed, per-engine caps, versions) the tab model expects.
    Returns None if the tree isn't present."""
    if not (base / "inputs").is_dir():
        return None

    inactive_dirs = fixture_disposition.inactive_fixture_dirs(base)
    input_bindings = {}
    input_aliases = {}
    directory_cache = {}

    def _read_dir(name):
        cached = directory_cache.get(name)
        if cached is not None:
            return cached

        out = {}
        if name in inactive_dirs:
            return out
        is_capture = re.match(r"^[a-z0-9_]+-\d", name) is not None
        if is_capture and name not in input_bindings:
            input_bindings[name] = capture_stimulus.read_bindings(base / name)
        for fp in sorted((base / name).glob("*/*.yaml")):
            raw = fp.read_bytes()
            doc = yaml.safe_load(raw) or {}
            for k, cd in (doc.get("cases") or {}).items():
                if is_capture:
                    family = fp.parent.name
                    _family, k = fixture_disposition.canonical_unified_record_key(
                        family, k, input_aliases,
                    )
                    current = inputs.get((fp.parent.name, k))
                    if current is not None:
                        implementation, version = name.split("-", 1)
                        cd = {**cd, "producer_origin": doc.get("capture_origin"), "inherited_from": doc.get("inherited_from")}
                        cd = capture_stimulus.select_peer_observation(
                            cd, current, implementation=implementation, version=version,
                        )
                        reason = capture_stimulus.comparison_failure(
                            cd, current, raw, str(fp.relative_to(base / name)), input_bindings[name],
                        )
                        if reason:
                            cd = {**cd, "unavailable": reason}
                            cd.pop("error", None)
                    if (fp.parent.name, k) in out and out[(fp.parent.name, k)] != cd:
                        raise ValueError(f"conflicting historical aliases in {name}: {fp.parent.name}/{k}")
                out[(fp.parent.name, k)] = cd
        directory_cache[name] = out
        return out

    # The canonical history materializes one authored current corpus. Historical
    # observations are sparse semantic-version YAML checkpoints, not overlays.
    inputs = _read_dir("inputs")
    golden = _read_dir("golden")

    # Shared inputs own scenario identity. Canonicalize any legacy overlay key through
    # that scenario, then use the resulting input aliases to put its golden record in
    # the same slot. Historical capture shards use the read-side aliases above; this
    # is the equivalent bridge for immutable shared input/golden overlays.
    inputs, input_aliases = fixture_disposition.canonicalize_unified_inputs(inputs)

    canonical_golden = {}
    for key, case in golden.items():
        canonical = fixture_disposition.canonical_unified_record_key(*key, input_aliases)
        prior = canonical_golden.get(canonical)
        if prior is not None and prior != case:
            raise ValueError(f"conflicting shared golden aliases for {canonical[0]}/{canonical[1]}")
        canonical_golden[canonical] = case
    golden = canonical_golden
    # A taxonomy rename changes the case key while preserving the scenario. Keep the
    # generated key so an older immutable input record cannot make the current capture
    # look incomplete beside its replacement in a sparse overlay.
    inputs = {
        key: case
        for key, case in inputs.items()
        if case.get("scenario") not in unified_taxonomy.UNIFIED_TAX
        or (key[0], unified_taxonomy.numbered_id(case["scenario"])) not in inputs
        or key[1] == unified_taxonomy.numbered_id(case["scenario"])
    }
    golden = {key: case for key, case in golden.items() if key in inputs}
    # impl -> [(version, dirname)] ascending. Dynamo keeps EVERY capture so the tab can
    # compare one parser build against another; a dict keyed by impl silently dropped
    # all but the last dir, which is why only one Dynamo column could ever render.
    # `sorted()` alone is lexicographic (0.1.9 > 0.1.10), so sort on the version key.
    engine_versions: dict[str, list[tuple[str, str]]] = {}
    for d in sorted(base.iterdir()):
        if not d.is_dir() or d.name in inactive_dirs or d.name in ("inputs", "golden"):
            continue
        m = re.match(r"^([a-z0-9_]+)-(\d.*)$", d.name)
        if m and fixture_disposition.DYNAMO_VERSION_RE.fullmatch(m.group(2)):
            engine_versions.setdefault(m.group(1), []).append((m.group(2), d.name))
    for impl in engine_versions:
        engine_versions[impl].sort(key=lambda vd: fixtures._version_sort_key(vd[0]))
    # The Unified tab compares every captured peer version. Keep each peer version
    # separate instead of silently replacing 0.25.1 with the newest 0.26.x shard.
    peer_by_ver = {}
    for impl, vers in engine_versions.items():
        if impl not in _UNIFIED_PEER_SOURCES:
            continue
        merged = peer_by_ver.setdefault(impl, {})
        for ver, dirname in vers:
            merged[ver] = _read_dir(dirname)
    engine_dirs = {impl: (vs[-1][1], vs[-1][0]) for impl, vs in engine_versions.items()}
    engine_cases = {}
    for impl, captures in peer_by_ver.items():
        latest = max(captures, key=fixtures._version_sort_key)
        engine_cases[impl] = captures[latest]
    dynamo_by_ver = {}
    for ver, dirname in engine_versions.get("dynamo_v2", []):
        dynamo_by_ver[ver] = _read_dir(dirname)

    current_dynamo_ver = _unified_dynamo_label()
    target_release = fixtures._version_sort_key(current_dynamo_ver)
    inherited_current_cases = {}
    for version in sorted(
        (
            version
            for version in dynamo_by_ver
            if fixtures._version_sort_key(version) <= target_release
        ),
        key=fixtures._version_sort_key,
    ):
        for case_key, record in dynamo_by_ver[version].items():
            inherited = dict(record)
            if version != current_dynamo_ver:
                inherited["inherited_from"] = version
            inherited_current_cases[case_key] = inherited
    inherited_current_cases.update(dynamo_by_ver.get(current_dynamo_ver, {}))
    dynamo_by_ver[current_dynamo_ver] = inherited_current_cases
    current_dynamo_cases = inherited_current_cases
    missing_current_case_keys = {
        (family, key)
        for (family, key), input_case in inputs.items()
        if (family, key) not in current_dynamo_cases
        and family in gen_unified_golden.UNIFIED_FAMILIES
        and (
            (input_case.get("scenario") or key) not in unified_taxonomy.UNIFIED_TAX
            or family in gen_unified_golden.scenario_families(input_case.get("scenario") or key)
        )
    }
    engine_cases["dynamo_v2"] = current_dynamo_cases

    shared_schema_signature = _schema_signature(_explicit_case_schemas(unified_tools()) or [])
    cases = []
    caps = {impl: {} for impl in _UNIFIED_PEER_SOURCES}
    for (fam, key), inp in sorted(inputs.items()):
        scenario = inp.get("scenario") or key
        cid = f"UNIFIED.{scenario}.{fam}"
        gdoc = golden.get((fam, key), {})
        ddoc = engine_cases.get("dynamo_v2", {}).get((fam, key), {})
        in_chunks = inp.get("chunks") or []
        dyn_chunks = ddoc.get("chunks") or []
        raw_init = inp.get("init") or {}
        cases.append({
            "id": cid, "scenario": scenario, "family": fam,
            "description": inp.get("description", ""),
            "tools": _unified_case_schemas(inp, shared_schema_signature),
            "policy": inp.get("policy") or [], "policy_tags": inp.get("policy") or [],
            "init": {
                **raw_init,
                "starting_state": raw_init.get("starting_state") or "None",
                "tool_output_mode": raw_init.get("tool_output_mode") or "Native",
                "named_tool": raw_init.get("named_tool"),
            },
            "finish_reason": inp.get("finish_reason") or "stop",
            "input": inp.get("input", ""),
            "golden": gdoc.get("assembled") or [],
            "dynamo": ddoc.get("assembled") or [],
            "dynamo_failure": _unified_capture_failure(ddoc),
            "dynamo_missing": (fam, key) in missing_current_case_keys,
            # Per-capture payloads, latest included. A version that never recorded this
            # case is ABSENT here rather than empty: an older capture predating the case
            # has no opinion about it, and scoring [] against golden would invent a
            # divergence the parser never produced.
            "dynamo_by_ver": {
                ver: {
                    **_unified_capture_failure(vdoc),
                    "assembled": (vdoc.get("assembled") or []),
                    "chunks": [c.get("expected") or [] for c in (vdoc.get("chunks") or [])],
                    "inherited_from": vdoc.get("inherited_from"),
                }
                for ver, vcases in dynamo_by_ver.items()
                if (vdoc := vcases.get((fam, key))) is not None
            },
            "dynamo_verdict": None, "vllm_verdict": None, "vllm_note": None,
            "peer_by_ver": {
                impl: {
                    ver: {"historical_capture_note": doc.get("historical_capture_note"), "batch_final": doc.get("batch_final"), "producer_origin": doc.get("producer_origin"), "inherited_from": doc.get("inherited_from"), **(_unified_capture_failure(doc) or {
                        "assembled": doc.get("assembled") or [],
                        "chunks": [chunk.get("expected") or [] for chunk in (doc.get("chunks") or [])],
                    })}
                    for ver, docs in peer_by_ver.get(impl, {}).items()
                    if (doc := docs.get((fam, key))) is not None
                }
                for impl in _UNIFIED_PEER_SOURCES
            },
            "chunks": _unified_chunk_rows(in_chunks, dyn_chunks),
        })
        for impl in _UNIFIED_PEER_SOURCES:
            edoc = engine_cases.get(impl, {}).get((fam, key))
            if edoc is None:
                continue
            if _unified_capture_failure(edoc):
                caps[impl][cid] = _unified_capture_failure(edoc)
            else:
                caps[impl][cid] = {
                    "assembled": edoc.get("assembled") or [],
                    "chunks": [c.get("expected") or [] for c in (edoc.get("chunks") or [])],
                    "parser": edoc.get("parser"),
                }
    versions = {impl: v for impl, (_d, v) in engine_dirs.items()}
    versions["dynamo_v2"] = current_dynamo_ver
    for impl, captures in peer_by_ver.items():
        versions[impl] = max(captures, key=fixtures._version_sort_key)
    # Captured history stays separate from the selected source, which may be missing.
    versions["dynamo_v2_all"] = list(dynamo_by_ver)
    for impl in _UNIFIED_PEER_SOURCES:
        versions[f"{impl}_all"] = sorted(
            peer_by_ver.get(impl, {}), key=fixtures._version_sort_key
        )
    return cases, caps, versions


def _unified_tab_model(artifact_root: Path, hrefs: dict) -> dict | None:
    import hashlib
    loaded = _load_unified_fixtures(_unified_base(artifact_root))
    if loaded is None:
        return None
    cases, _caps, _vers = loaded
    if not cases:
        return None

    authored_scenarios = {
        spec[0] for spec in (*gen_unified_golden.CLEAN, *gen_unified_golden.EDGE)
    }
    loaded_scenarios = {case["scenario"] for case in cases}
    missing_scenarios = authored_scenarios - loaded_scenarios
    if missing_scenarios:
        raise ValueError(
            "Unified fixture inputs are missing authored scenario(s): "
            + ", ".join(sorted(missing_scenarios))
        )

    def _sig(events) -> int:
        return int(hashlib.md5(json.dumps(events, sort_keys=True).encode()).hexdigest()[:8], 16)

    scenarios: list[str] = []
    families: list[str] = []
    scn_desc: dict[str, str] = {}
    by_key: dict[tuple[str, str], dict] = {}
    for c in cases:
        s, f = c["scenario"], c["family"]
        if s not in scenarios:
            scenarios.append(s)
            scn_desc[s] = c["description"]
        if f not in families:
            families.append(f)
        by_key[(f, s)] = c

    # Numbered taxonomy + axis labels — single source in unified_taxonomy.py (shared
    # with explode_unified_fixtures.py so the numbering can't drift). See UNIFIED_CASES.md.
    UNIFIED_GROUP_LABEL = unified_taxonomy.UNIFIED_GROUP_LABEL

    def _tax(s):
        return unified_taxonomy.display_tax(s)

    def _band(group_num):
        if isinstance(group_num, int):
            return "case-band-0" if group_num % 2 == 1 else "case-band-1"
        return "case-band-0"

    ordered = sorted(scenarios, key=unified_taxonomy.display_sort_key)
    columns = []
    for s in ordered:
        g, sub = _tax(s)
        column = {"sub": s, "group_key": unified_taxonomy.display_section(s)[0], "band": _band(g),
                  "label": unified_taxonomy.case_label(s), "desc": scn_desc.get(s, ""),
                  "init": None}
        variants = _schema_variants_by_family({
            family: by_key.get((family, s), {}).get("tools") for family in families
        })
        if variants:
            column["schemas"] = variants
        columns.append(column)
    column_groups = []
    seen_groups = []
    for s in ordered:
        g, _sub = _tax(s)
        section_key, section_label = unified_taxonomy.display_section(s)
        if section_key not in seen_groups:
            seen_groups.append(section_key)
            column_groups.append({"key": section_key, "label": section_label,
                                  "band": _band(g),
                                  "span": sum(unified_taxonomy.display_section(x)[0] == section_key for x in ordered)})

    def _cand(key, label, bucket, version=None, source=BASELINE_STREAM_IMPL):
        canonical = BATCH_SOURCE_IMPL.get(source, source)
        language = next(spec.language for spec in IMPL_SPECS if spec.key == canonical) if source else None
        return {"key": key, "impl": key, "label": label, "label_html": label,
                "default_bucket": bucket, "version": version, "parse_mode": "unified", "language": language}
    # Alphabetical by label so non-Reference popup columns sort alphabetically
    # (the selected Reference is pulled to the left by the view). Unified keeps the
    # released Combined captures beside newer native UnifiedParser captures so the
    # table shows the actual version-to-version history.
    # THIS tab's own capture version. It used to borrow _dynamo_v2_version(), which reads
    # the STREAM tree (toolcalling/fixtures-stream-v1) — a different tree on a different
    # release cadence — so the column was labelled with a version that did not produce
    # these rows (0.1.23 on 0.1.24 data).
    dynamo_all_vers = _vers.get("dynamo_v2_all") or []
    dynamo_ver_label = _vers["dynamo_v2"]
    dynamo_history_vers = [
        version for version in dynamo_all_vers if version != dynamo_ver_label
    ]
    dynamo_label = _full_label(BASELINE_STREAM_IMPL, dynamo_ver_label, "stream")
    peer_specs = []
    for source, spec in _UNIFIED_PEER_SOURCES.items():
        for ver in reversed(_vers.get(f"{source}_all") or []):
            # Existing shared links retain the original vLLM control keys.
            key = (spec["legacy_key"]
                   if ver == _UNIFIED_LEGACY_PEER_VERSION and spec["legacy_key"]
                   else f"{source}@{ver}")
            peer_specs.append({
                "key": key, "impl": spec["impl"], "source": source,
                "version": ver, "label": batch_capture_label(source, ver) if spec.get("batch") else spec["label"].format(version=ver),
                "stream": spec["stream"], "batch": spec.get("batch", False),
            })
    candidates = [
        # Dynamo is the default REF (starred): the cell color reflects Dynamo vs GOLDEN.
        # golden stays a candidate as the fixed NΔ baseline (cmp.golden) but is no longer
        # the base — a golden REF never diverges from itself, so it would color every cell
        # green. See conformance_view.compareBarHtml (golden's hidden ref radio is dropped
        # when an engine is the default REF).
        _cand("dynamo", dynamo_label, "A", dynamo_ver_label),  # Reference (default, starred)
        # Only the Reference is on by default — same rule as the stream and batch tabs.
        # Reset reloads at these defaults, so anything B here comes back checked every
        # time the reader clears the board, which reads as the page re-selecting itself.
        _cand("golden", "GOLDEN (oracle)", "C", source=None),  # fixed NΔ baseline, not the base
    ]
    # Older Dynamo captures, newest-first, each its own clickable column — UNCHECKED,
    # so pressing Detailed does not switch on every historical build at once. The point
    # is that the version is THERE to click, not that it is compared by default.
    # impl="dynamo" groups them under the one Dynamo engine block of the compare bar.
    for v in reversed(dynamo_history_vers):
        pc = _cand(f"dynamo@{v}", _full_label(BASELINE_STREAM_IMPL, v, "stream"), "C", v)
        pc["impl"] = "dynamo"
        candidates.append(pc)
    for spec in peer_specs:
        pc = _cand(spec["key"], spec["label"], "C", spec["version"], spec["source"])
        pc["impl"] = spec["impl"]
        pc["stream"] = spec["stream"]
        if spec["batch"]:
            pc["source_blocker"] = BATCH_SOURCE_BLOCKERS.get((spec["source"], spec["version"]))
            pc["parse_mode"] = "batch"
        candidates.append(pc)

    rows = []

    duplicate_cases = {
        ("deepseek_v41", "prefilled_reasoning_with_tool"): "UNIFIED.11-1",
        ("deepseek_v41", "prefilled_reasoning_then_text_then_tool"): "UNIFIED.11-5",
        ("deepseek_v41", "prefilled_reasoning_then_text"): "UNIFIED.10-2",
    }
    duplicate_cases.update({
        (family, "guided_json_quoted_bare_tool_header_in_answer"): "UNIFIED.35-1"
        for family in families if family != "muse_glimmer"
    })
    no_native_unified_note = (
        "No native Dynamo Unified parser is registered for this family; recorded legacy "
        "batch captures are compared separately against GOLDEN."
    )

    def _dynamo_path(family: str, version: str) -> dict:
        # GPT-OSS gained UnifiedParser in 0.7.28 (#434); older captures used the split adapter.
        native = family in gen_unified_golden.UNIFIED_FAMILIES and (
            family != "gpt_oss"
            or fixtures._version_sort_key(version) >= fixtures._version_sort_key("0.7.28")
        )
        mode = "stream" if native else "split: v1 reasoning + v2 tool parser"
        return {"label": _full_label(BASELINE_STREAM_IMPL, version, mode),
                "parse_mode": "unified" if native else "split"}

    def _unified_na_cell(family: str, scenario: str, group_num: int) -> dict:
        duplicate_of = duplicate_cases.get((family, scenario))
        note = f"This scenario is not applicable to {family}."
        if scenario == "guided_json_quoted_bare_tool_header_in_answer":
            note = (
                f"This is a duplication of {unified_taxonomy.numbered_id('guided_json_quoted_bare_header_in_answer')} for this family: the existing "
                "variant changes only the literal text inside its reasoning markers. "
                "Muse's to=get_weather header exercises a separate recipient boundary."
            )
        elif duplicate_of:
            note = f"Duplicate of {duplicate_of}: same observable event contract for {family}."
        unavailable = {"unavailable": note, "unavailable_code": "duplicate_scenario" if duplicate_of else "scenario_not_applicable"}
        return {
            "kind": "cell",
            "case_id": unified_taxonomy.numbered_id(scenario),
            "family": family,
            "sub": scenario,
            "col_group": unified_taxonomy.display_section(scenario)[0],
            "band": _band(group_num),
            "status": "na",
            "duplicate_of": duplicate_of,
            "red_on_diff": False,
            "cmp": {candidate["key"]: markers.cmp_entry(0, na=1) for candidate in candidates},
            "facts": [],
            "tooltip": {
                "head": f"{unified_taxonomy.numbered_id(scenario)} ({scenario}) — {family}",
                "description": note,
                "init": None,
                "finish_reason": None,
                "input": {"kind": None, "text": None, "chunks": None,
                           "family": unified_taxonomy.marker_family(family)},
                "candidates": [
                    {"key": candidate["key"], "label": candidate["label"],
                     "impl": candidate["impl"], "version": candidate["version"],
                     "parse_mode": candidate["parse_mode"], "leak": False,
                     **(_dynamo_path(family, candidate["version"])
                        if candidate["impl"] == "dynamo" else {}),
                     "block": unavailable}
                    for candidate in candidates
                ],
                "baseline": None,
                "reasons": [],
                "dynamo_notes": [],
                "refs": [],
                "leak_note": None,
                "na_note": note,
                "duplicate_of": duplicate_of,
            },
        }

    for f in families:
        cells = {}
        for s in scenarios:
            c = by_key.get((f, s))
            if not c:
                duplicate_of = duplicate_cases.get((f, s))
                if duplicate_of:
                    g_num, _g_sub = _tax(s)
                    cells[s] = _unified_na_cell(f, s, g_num)
                    continue
                applicable = gen_unified_golden.scenario_families(s)
                if f not in applicable:
                    g_num, _g_sub = _tax(s)
                    cells[s] = _unified_na_cell(f, s, g_num)
                    continue
                if f not in gen_unified_golden.UNIFIED_FAMILIES:
                    g_num, _g_sub = _tax(s)
                    cells[s] = _unified_na_cell(f, s, g_num)
                    continue
                authored = gen_unified_golden.build_cases(f)[f"UNIFIED.{s}.{f}"]
                c = {
                    **authored,
                    "dynamo_missing": True,
                }
            missing_reason = (
                f"Missing Unified capture for applicable case {f}/{s}. "
                "Regenerate the current Dynamo capture before publishing this report."
                if c.get("dynamo_missing") else None
            )
            dynamo_failure = ({"error": missing_reason} if missing_reason else c.get("dynamo_failure") or {})
            gold = c["golden"]
            # Assemble every engine's FINAL from its STREAMED per-chunk deltas (not its
            # batch final message). For Dynamo this is decisive: streaming preserves the
            # reasoning<->tool order that the batch assembly (detect_and_parse_reasoning)
            # collapses. Verdict is recomputed against GOLDEN on the streamed assembly.
            dyn_chunk_deltas = [ch.get("dynamo") or [] for ch in (c.get("chunks") or [])]
            if dynamo_failure:
                dyn_chunk_deltas = []
            dyn = _assemble_stream(dyn_chunk_deltas, recorded_assembly=c.get("dynamo"))
            gsig, dsig = _sig(gold), _sig(dyn)
            is_native = f in gen_unified_golden.UNIFIED_FAMILIES
            has_dynamo_capture = is_native or bool(c.get("dynamo_by_ver"))
            dverd = _unified_classify(f, gold, dyn) if has_dynamo_capture else "NA"
            if dynamo_failure:
                # Missing evidence must stay red even when the oracle expects no events.
                dsig = gsig ^ 1
                dverd = "ERROR"
            # Score every captured peer version. Missing family coverage and a case that
            # postdates a capture are both n/a, never an assumed match.
            peer_results = {}
            for spec in peer_specs:
                cap = (c.get("peer_by_ver", {}).get(spec["source"], {})
                       .get(spec["version"]))
                failure = _unified_capture_failure(cap)
                chunks = [] if failure else (cap.get("chunks") if cap else None) or []
                events = (None if cap is None or failure else
                          (_assemble_stream(chunks) if spec["stream"] else
                           cap.get("assembled")))
                err = cap.get("error") if cap else None
                verdict = "ERROR" if err else (_unified_classify(f, gold, events)
                                                   if events is not None else None)
                peer_results[spec["key"]] = {
                    "cap": cap, "chunks": chunks, "events": events,
                    "error": err, "verdict": verdict,
                    "failure": failure,
                }
            cmp = {
                "golden": markers.cmp_entry(gsig),
                "dynamo": (
                    markers.cmp_entry(
                        dsig, leak=1 if dverd == "LEAK" else 0, err=1 if dynamo_failure else 0,
                    )
                    if has_dynamo_capture else markers.cmp_entry(0, na=1)
                ),
            }
            for spec in peer_specs:
                result = peer_results[spec["key"]]
                if result["error"]:
                    cmp[spec["key"]] = markers.cmp_entry(gsig ^ 1, err=1)
                elif result["events"] is None:
                    cmp[spec["key"]] = markers.cmp_entry(0, na=1)
                else:
                    sig = _sig(result["events"])
                    if result["error"]:
                        sig ^= 0xE44
                    cmp[spec["key"]] = markers.cmp_entry(
                        sig, leak=1 if result["verdict"] == "LEAK" else 0,
                        err=1 if result["error"] else 0,
                    )
            # Older Dynamo builds, scored against GOLDEN exactly like the latest one, so a
            # cell that changed between builds shows a real NΔ instead of a styling hint.
            prev_by_ver = c.get("dynamo_by_ver") or {}
            prev_results_by_ver = {}
            for pv in dynamo_history_vers:
                if not has_dynamo_capture:
                    cmp[f"dynamo@{pv}"] = markers.cmp_entry(0, na=1)
                    prev_results_by_ver[pv] = {"chunks": [], "block": {"unavailable": no_native_unified_note}}
                    continue
                pdoc = prev_by_ver.get(pv)
                if pdoc is None:
                    # Absence alone cannot establish parser support or the case's age.
                    cmp[f"dynamo@{pv}"] = markers.cmp_entry(0, na=1)
                    prev_results_by_ver[pv] = {"chunks": [], "block": _unified_capture_failure(None)}
                    continue
                pchunks = pdoc.get("chunks") or []
                failure = _unified_capture_failure(pdoc)
                if failure:
                    cmp[f"dynamo@{pv}"] = markers.cmp_entry(
                        gsig ^ 1, err=1 if "error" in failure else 0,
                        na=1 if "unavailable" in failure else 0,
                    )
                    prev_results_by_ver[pv] = {"chunks": [], "block": failure}
                    continue
                pevents = _assemble_stream(pchunks, recorded_assembly=pdoc.get("assembled"))
                pverd = _unified_classify(f, gold, pevents)
                cmp[f"dynamo@{pv}"] = markers.cmp_entry(
                    _sig(pevents), leak=1 if pverd == "LEAK" else 0
                )
                prev_results_by_ver[pv] = {"chunks": pchunks, "block": {
                    "events": pevents, "verdict": pverd,
                    "explanation": (
                        f"Inherited unchanged from Dynamo v2 {pdoc.get('inherited_from')}."
                        if pdoc.get("inherited_from") else None
                    ),
                }}
            desc = c["description"]
            if c.get("policy_tags"):
                desc = f"{desc}  [policy: {', '.join(c['policy_tags'])}]"
            chunk_rows = []
            for i, ch in enumerate(c.get("chunks") or []):
                expected = {"dynamo": [] if dynamo_failure else ch.get("dynamo") or []}
                for spec in peer_specs:
                    chunks = peer_results[spec["key"]]["chunks"]
                    expected[spec["key"]] = ({"unavailable": "Order/chunk not applicable for batch"} if spec["batch"] else chunks[i] if i < len(chunks) else [])
                for pv, result in prev_results_by_ver.items():
                    pchunks = result["chunks"]
                    expected[f"dynamo@{pv}"] = pchunks[i] if i < len(pchunks) else []
                chunk_rows.append({"delta_text": ch["delta_text"],
                                   "finish_reason": None, "expected": expected})
            reasons = []
            for spec in peer_specs:
                cap = peer_results[spec["key"]]["cap"]
                if cap and cap.get("historical_capture_note"):
                    reasons.append({"label": spec["label"], "reason": cap["historical_capture_note"]})
            if dverd in ("MERGE", "ORDER"):
                reasons.append({
                    "label": "stream vs final message",
                    "reason": ("per-chunk deltas stream IN ORDER (see the chunk rows), but Dynamo's "
                               "final message merges all reasoning into one reasoning_content field "
                               "(the assembled row) — losing the reasoning/tool interleaving. The "
                               "UnifiedParser keeps one ordered stream, so the final message preserves order."),
                })
            g_num, _g_sub = _tax(s)
            tooltip = {
                "head": f'{unified_taxonomy.numbered_id(s)} ({s}) — {f}',
                "description": desc,
                "init": c.get("init"),
                "finish_reason": c.get("finish_reason"),
                # `family` here selects the GRAMMAR the colorizer types markup with,
                # so it must be the marker-registry family, not the corpus one.
                "input": {"kind": "chunks" if chunk_rows else "text", "text": c["input"], "chunks": chunk_rows,
                          "family": unified_taxonomy.marker_family(f)},
                "candidates": [
                    {"key": "dynamo", **_dynamo_path(f, dynamo_ver_label), "impl": "dynamo",
                     "version": dynamo_ver_label, "leak": dverd == "LEAK",
                      "block": ({"unavailable": no_native_unified_note} if not has_dynamo_capture else
                                dynamo_failure if dynamo_failure else
                               {"events": dyn, "verdict": dverd,
                                "todo": None,
                                "explanation": (
                                    f"Inherited unchanged from Dynamo v2 {c['dynamo_by_ver'].get(dynamo_ver_label, {}).get('inherited_from')}."
                                    if c['dynamo_by_ver'].get(dynamo_ver_label, {}).get('inherited_from')
                                    else None
                                )})},
                    {"key": "golden", "label": "GOLDEN (oracle)", "impl": "golden",
                     "version": None, "parse_mode": "unified", "leak": False,
                     "pin_first": True,  # oracle is always the leftmost popup column
                     "block": {"events": gold}},
                ] + [
                    {"key": spec["key"], "label": spec["label"], "impl": spec["impl"],
                     "version": spec["version"], "parse_mode": "batch" if spec["batch"] else "unified",
                     "leak": peer_results[spec["key"]]["verdict"] == "LEAK",
                     "block": (peer_results[spec["key"]]["failure"]
                                if peer_results[spec["key"]]["events"] is None else
                               ({"error": peer_results[spec["key"]]["error"]}
                                if peer_results[spec["key"]]["error"] else
                                {"events": peer_results[spec["key"]]["events"],
                                 "verdict": peer_results[spec["key"]]["verdict"],
                                 **({"batch_final": peer_results[spec["key"]]["cap"]["batch_final"],
                                     "producer_origin": peer_results[spec["key"]]["cap"].get("producer_origin"),
                                     "inherited_from": peer_results[spec["key"]]["cap"].get("inherited_from")}
                                    if spec["batch"] else {})}))}
                    for spec in peer_specs
                ] + [
                    # One popup column per older Dynamo capture, newest-first. A version
                    # that never recorded this case says so instead of showing an empty
                    # event list that reads like the parser produced nothing.
                    {"key": f"dynamo@{pv}",
                     **_dynamo_path(f, pv),
                     "impl": "dynamo", "version": pv,
                     "leak": bool(cmp.get(f"dynamo@{pv}", {}).get("leak")),
                     "block": prev_results_by_ver[pv]["block"]}
                    for pv in reversed(dynamo_history_vers)
                ],
                "baseline": None, "reasons": reasons, "dynamo_notes": [], "refs": [],
                "leak_note": None,
                "na_note": None if has_dynamo_capture else no_native_unified_note,
                "duplicate_of": None,
            }
            for spec in peer_specs:
                if spec["batch"]:
                    cap = peer_results[spec["key"]]["cap"] or {}
                    payload = next(item["block"] for item in tooltip["candidates"] if item["key"] == spec["key"])
                    payload.update({"producer_origin": cap.get("producer_origin"), "inherited_from": cap.get("inherited_from")})
            cells[s] = {
                "kind": "cell", "case_id": unified_taxonomy.numbered_id(s), "family": f, "sub": s,
                "col_group": unified_taxonomy.display_section(s)[0], "band": _band(g_num),
                "status": "problem" if dynamo_failure else "ok", "red_on_diff": True,
                "duplicate_of": None,
                "cmp": cmp, "facts": [], "tooltip": tooltip,
            }
        rows.append({"family": f, "model_label": f, "model_label_html": f, "section": None,
                     "parser": None, "cells": cells})

    for column in columns:
        # Include reconstructed missing captures; their native prefills can differ.
        configs = [row["cells"][column["sub"]]["tooltip"]["init"] for row in rows
                   if row["cells"][column["sub"]]["status"] != "na"]
        if configs and all(config == configs[0] for config in configs):
            column["init"] = configs[0]

    total = sum(len(r["cells"]) for r in rows)
    na = sum(cell.get("status") == "na" for row in rows for cell in row["cells"].values())
    missing = sum(cell.get("kind") == "missing" for row in rows for cell in row["cells"].values())
    stats = {"families": len(families), "sub_cases": len(scenarios), "slots": total,
             "real": total - na - missing, "parity": 0, "dynamo_only": 0, "documented": 0,
             "research": 0, "errors": 0, "na": na, "missing": missing}
    cases_href = str(hrefs.get("reasoning_cases", "#")).replace("REASONING_CASES", "UNIFIED_CASES")

    # "Case descriptions" section under the table, grouped by taxonomy — same shape as
    # every other tab's glossary ([{label, rows:[(short_id, description), ...]}]). The
    # view prepends case_prefix ("UNIFIED."), so short_id is the descriptive taxonomy label.
    unified_glossary = []
    for grp in column_groups:
        group_key = grp["key"]
        grp_rows = [(unified_taxonomy.case_label(s), scn_desc.get(s, ""))
                    for s in ordered if unified_taxonomy.display_section(s)[0] == group_key]
        unified_glossary.append({"label": grp["label"], "rows": grp_rows})

    return {
        "id": "tab-unified", "kind": "unified", "active": False, "mode": "unified",
        "no_parser_col": True,  # parser variant is already encoded in each engine's name
        "label": "Unified",
        "label_html": 'Unified',
        "tab_title": ("Unified: one ordered event stream (reasoning + content + tool calls) "
                      "measured against the GOLDEN oracle"),
        "columns": columns, "column_groups": column_groups,
        "candidates": candidates, "rows": rows, "stats": stats, "glossary": unified_glossary,
        "comparison_defaults": UNIFIED_COMPARISON_DEFAULTS,
        "comparison_slot_engines": UNIFIED_COMPARISON_SLOT_ENGINES,
        "comparison_languages": UNIFIED_DISPLAY["comparison_languages"],
        "case_prefix": "UNIFIED.", "case_section_id": "unified",
        "case_docs_href": cases_href, "case_docs_label": "lib/parsers/UNIFIED_CASES.md",
        "captured_note": ("vLLM captures include every packaged 0.25.1 and 0.26.x "
                          "parser version. vLLM Rust 0.26.0 uses the native "
                          "UnifiedParser for Gemma4 and CombinedParser for Qwen3/Kimi K2."),
        "toolbar_desc_html": None,
        "details_note_html": None,
    }


def _legacy_tab_models(hrefs: dict) -> list[dict]:
    tabs = []
    # --- Tool Calling (batch data): merged v1-batch + v2-stream-on-batch ---
    batch_spec = _load_panel_cases("batch")
    batch_href = _plain_href_rewriter("toolcalling", hrefs["toolcalling_fixtures"])
    batch_tab = _toolcalling_tab_model(batch_spec, batch_href, parser_stream_context="batch")
    batch_tab.update({
        "id": "tab-toolcalling-batch",
        "label": "Tool Calling v1 (batch data)",
        "label_html": ('Tool Calling v1 <span class="tab-sub">'
                       '(<span class="w-batch">batch</span> data)</span>'),
        "tab_title": ("Tool Calling (batch data): v1 batch parsers plus v2 stream "
                      "parsers on the same v1 batch fixtures"),
        "case_prefix": "TOOLCALLING.batch.",
        "case_section_id": "toolcalling-batch",
        "case_docs_href": hrefs["toolcalling_cases"],
        "case_docs_label": "lib/parsers/TOOLCALLING_CASES.md",
        "candidates": _candidate_model(_merged_candidate_items()),
        "captured_note": _captured_note("batch"),
        "toolbar_desc_html": (
            f'Parsers: <strong>v1</strong> batch '
            f'(<a href="{hrefs["toolcalling_src"]}">parsers/src/tool_calling/</a>) '
            f'plus <strong>v2</strong> streaming on the same batch text '
            f'(<a href="{hrefs["streaming_src"]}">parsers_v2/src/tool_calling/*</a>) · '
            f'Input: <strong>v1</strong> batch fixtures '
            f'(<a href="{hrefs["toolcalling_fixture_store"]}">conformance/fixtures/toolcalling/fixtures-batch-v1/</a>).'),
        "details_note_html": None,
    })
    tabs.append(batch_tab)

    # --- Tool Calling (legacy stream corpus): per-chunk streamv1 ---
    stream_spec = _load_panel_cases("streamv1")
    stream_href = _plain_href_rewriter("toolcalling", hrefs["toolcalling_stream_fixtures"])
    stream_tab = _toolcalling_tab_model(stream_spec, stream_href, parser_stream_context="streamv1")
    stream_tab.update({
        "id": "tab-toolcalling-streamv1",
        "label": "Tool Calling legacy stream (v1 corpus)",
        "label_html": ('Tool Calling legacy stream <span class="tab-sub">'
                       '(<span class="w-stream">stream</span> data)</span>'),
        "tab_title": "Tool Calling (legacy stream corpus): Dynamo parser v2",
        "case_prefix": "TOOLCALLING.streamv1.",
        "case_section_id": "toolcalling-streamv1",
        "case_docs_href": hrefs["toolcalling_streaming_cases"],
        "case_docs_label": "lib/parsers/TOOLCALLING_STREAMING_V1_CASES.md",
        "candidates": _candidate_model(_stream_candidate_items()),
        "captured_note": _captured_note("streamv1"),
        "toolbar_desc_html": (
            f'Parser: <strong>v2</strong> Dynamo parser v2 token-incremental streaming '
            f'(<a href="{hrefs["streaming_src"]}">parsers_v2/src/tool_calling/*</a>) · '
            f'Input: <strong>legacy v1</strong> non-Unified stream fixtures '
            f'(<a href="{hrefs["toolcalling_stream_fixture_store"]}">conformance/fixtures/toolcalling/fixtures-stream-v1/</a>).'),
        "details_note_html": f"<p>{_stream_parity_explainer_html('streamv1')}</p>",
    })
    tabs.append(stream_tab)

    # --- Reasoning tabs (delegated to the v1 reasoning module's model builder) ---
    r_rows, r_columns, r_refs = reasoning_table._load()
    r_no_vllm, r_no_sglang = reasoning_table._derive_no_peer_sets(r_rows)
    reasoning_href = _plain_href_rewriter("reasoning", hrefs["reasoning_fixtures"])
    for rmode in ("batch", "stream"):
        mode_columns = reasoning_table._columns_for_mode(r_columns, rmode)
        rtab = reasoning_table.build_model_panel(
            r_rows, mode_columns, r_refs, r_no_vllm, r_no_sglang, mode=rmode, active=False)
        # Rebase fixture cell links + parser-cell links onto the reasoning root.
        for row in rtab["rows"]:
            if row.get("parser") and row["parser"].get("html"):
                row["parser"]["html"] = _fixture_href_rewriter("reasoning", hrefs["reasoning_fixtures"])(row["parser"]["html"])
            for cell in row.get("cells", {}).values():
                if cell.get("fixture_href"):
                    cell["fixture_href"] = reasoning_href(cell["fixture_href"])
        _r_label, _r_label_html = _tab_label("Reasoning", rmode, None, False, on_parser=False)
        rtab.update({
            "id": f"tab-reasoning-{rmode}",
            "label": _r_label,
            "label_html": _r_label_html,
            "tab_title": f"Reasoning {rmode}: v1 code on v1 fixtures",
            "case_prefix": "REASONING.",
            "case_section_id": f"reasoning-{rmode}",
            "case_docs_href": hrefs["reasoning_cases"],
            "case_docs_label": "lib/parsers/REASONING_CASES.md",
            "candidates": _candidate_model(rtab.get("candidates", [])),
            "captured_note": "",
            "toolbar_desc_html": (
                f'Parser: <strong>v1</strong> reasoning parser '
                f'(<a href="{hrefs["reasoning_src"]}">parsers/v1/src/reasoning/</a>) · '
                f'Input: <strong>v1</strong> reasoning fixtures '
                f'(<a href="{hrefs["reasoning_fixture_store"]}">conformance/fixtures/reasoning/fixtures-v1/</a>).'),
            "details_note_html": None,
        })
        tabs.append(rtab)

    return tabs


def build_combined_model(output_path: Path | None = None,
                         artifact_root: Path | None = None,
                         *, stamp: str, sha: str | None, include_legacy: bool = False,
                         github_repository: str | None = None,
                         github_revision: str | None = None,
                         fixture_base_url: str | None = None) -> dict:
    """Build the public Unified report; legacy tabs are opt-in regression fixtures."""
    artifact_root = (artifact_root or REPO_ROOT).resolve()
    resolved_output_path = _resolve_output_path(
        output_path, artifact_root, "tests/parity/CONFORMANCE.html")
    hrefs = common.set_links(
        resolved_output_path,
        artifact_root,
        github_repository=github_repository,
        github_revision=github_revision,
        fixture_base_url=fixture_base_url,
    )

    tabs: list[dict] = _legacy_tab_models(hrefs) if include_legacy else []

    unified_tab = _unified_tab_model(artifact_root, hrefs)
    if unified_tab is None:
        raise ValueError("Unified inputs are required for the conformance report")
    tabs.append(unified_tab)

    if tabs:
        default_tab = next((tab for tab in tabs if tab["id"] == "tab-unified"), tabs[0])
        for tab in tabs:
            tab["active"] = tab is default_tab

    meta = {
        "title": "Dynamo Parser Conformance Table",
        "stamp": stamp,
        "sha": sha,
        "short_sha": sha[:12] if sha else "",
        "command": "conformance/utils/render_table_v2.sh",
        "output": _display_path(resolved_output_path, artifact_root),
        "generated_by": "generate_conformance_table.build_combined_model",
    }
    legend_html = _common_legend_html(_peer_version_items(_peer_versions()))
    for tab in tabs:
        if tab["id"] in {"tab-toolcalling-batch", "tab-toolcalling-streamv1"} and any(
            "golden" in (cell.get("cmp") or {})
            for row in tab["rows"] for cell in row["cells"].values()
        ):
            tab["candidates"].append({"key": "golden", "impl": "golden", "label": "GOLDEN (oracle)",
                                      "label_html": "GOLDEN (oracle)", "default_bucket": "B",
                                      "version": None,
                                      "parse_mode": "batch" if tab["mode"] == "batch" else "stream"})
        group_null_variants(tab)
        group_unified_variants(tab)
        if tab["id"] == "tab-unified":
            # Rank the visible columns after variants have been folded into parents.
            labels = unified_taxonomy.display_case_labels(column["sub"] for column in tab["columns"])
            display_by_label = {column["label"]: labels[column["sub"]]["label"] for column in tab["columns"]}
            for column in tab["columns"]:
                column["case_id"] = "UNIFIED." + column["label"]
                column.update(labels[column["sub"]])
            for group in tab["glossary"]:
                group["rows"] = [(display_by_label.get(label, label), desc) for label, desc in group["rows"]]
    return _model.build_page(meta, tabs, parser_ni=_parser_ni_map(),
                             legend_html=legend_html)


def _captured_note(mode: str) -> str:
    captured = _CAPTURED_WITH_BY_MODE.get(mode) or {}
    if not captured:
        return ""
    pairs = ", ".join(f"{impl} {ver}" for impl, ver in sorted(captured.items()))
    return (f"Peer streaming output captured against: {pairs}. "
            "A divergence is relative to these versions; re-capture when bumping.")


def render_combined_html(
    output_path: Path | None = None,
    artifact_root: Path | None = None,
    *,
    github_repository: str | None = None,
    github_revision: str | None = None,
    fixture_base_url: str | None = None,
    include_legacy: bool = False,
) -> str:
    artifact_root = (artifact_root or REPO_ROOT).resolve()
    resolved_output_path = _resolve_output_path(
        output_path,
        artifact_root,
        "tests/parity/CONFORMANCE.html",
    )
    common.set_links(
        resolved_output_path,
        artifact_root,
        github_repository=github_repository,
        github_revision=github_revision,
        fixture_base_url=fixture_base_url,
    )

    now = datetime.datetime.now(zoneinfo.ZoneInfo("America/Los_Angeles"))
    stamp = now.strftime("%Y-%m-%d %H:%M %Z")
    sha = github_revision.lower() if github_revision else _commit_sha()

    # DIS-2434: the page is now rendered ENTIRELY by the JS view from this JSON model —
    # the Python HTML emitters (render_html_panel/render_cell_html/tooltip builders) are
    # gone; the template emits a skeleton and the model blob, the view builds the DOM.
    page_model = build_combined_model(
        include_legacy=include_legacy,
        output_path=output_path,
        artifact_root=artifact_root,
        stamp=stamp,
        sha=sha,
        github_repository=github_repository,
        github_revision=github_revision,
        fixture_base_url=fixture_base_url,
    )
    # Per-family declared markers (pairs/singletons) for the JS colorizer's declared
    # lookup — the same table markup.py's _declared_lookup consults server-side.
    page_model["family_markers"] = declared_markers()
    model_json = _model.to_script_json(page_model)

    html = (
        _make_jinja_env()
        .get_template("conformance_table.html.j2")
        .render(
            title="Dynamo Parser Conformance Table",
            title_html="Dynamo Parser Conformance Table",
            stamp=stamp,
            conformance_css=_read_asset("conformance.css"),
            conformance_js=_read_asset("conformance.js"),
            colorize_js=_read_asset("colorize.js"),
            conformance_view_js=_read_asset("conformance_view.js"),
            comparison_layout_js=_read_asset("comparison_layout.js"),
            sha=sha,
            short_sha=sha[:12] if sha else "",
            command="conformance/utils/render_table_v2.sh",
            output=_display_path(resolved_output_path, artifact_root),
            parser_ni_json=json.dumps(_parser_ni_map()),
            model_json=model_json,
        )
    )
    return _scrub_visible_conformance_text(html)


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        description="Generate frontend-crate conformance tables.",
    )
    parser.add_argument(
        "stage",
        choices=("all",),
        help="Conformance stage to render.",
    )
    args, rest = parser.parse_known_args(argv)

    stage_parser = argparse.ArgumentParser(
        description="Generate the combined frontend-crate parser conformance HTML page.",
    )
    stage_parser.add_argument(
        "--html",
        action="store_true",
        help="Emit the combined HTML page.",
    )
    stage_parser.add_argument(
        "--output-path",
        type=Path,
        help="Output file path used to compute relative links. The HTML is still written to stdout.",
    )
    stage_parser.add_argument(
        "--artifact-root",
        type=Path,
        help="Repo root that output links should target. Defaults to the staged repo root.",
    )
    stage_parser.add_argument(
        "--github-repository",
        help="GitHub OWNER/REPO used for immutable source links (requires the other web-link options).",
    )
    stage_parser.add_argument(
        "--github-revision",
        help="Full commit SHA used for immutable source links (requires the other web-link options).",
    )
    stage_parser.add_argument(
        "--fixture-base-url",
        help="HTTPS base URL for published fixture YAMLs (requires the other web-link options).",
    )
    stage_args = stage_parser.parse_args(rest)
    if not stage_args.html:
        parser.error("stage 'all' currently supports --html only")
    print(
        render_combined_html(
            output_path=stage_args.output_path,
            artifact_root=stage_args.artifact_root,
            github_repository=stage_args.github_repository,
            github_revision=stage_args.github_revision,
            fixture_base_url=stage_args.fixture_base_url,
        )
    )


if __name__ == "__main__":
    main()
