# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Shared Unified descriptive IDs, ordering, display placement, and historical aliases.

Numeric groups identify shared behavior; named groups identify family-specific
behavior. Published numeric labels remain immutable aliases and ordering metadata.
Parser configuration and golden behavior remain owned by the authored corpus.
Groups 1-9 mirror the tool-calling STREAM taxonomy (TOOLCALLING.streamv1.N) as
tool-only unified cases (UNIFIED subsumes STREAM). Group 10 is the reasoning axis
(REASONING.*). Group 11 is unique to unified: reasoning<->tool interleaving that
neither STREAM (no reasoning) nor REASONING (no ordered tool events) can express.
Group 12 is adversarial nesting (a marker of one channel inside another).
Groups 30-39 are Guided Decoding, split by the behavior under test. Groups 40/41
cover prefilled reasoning and 50/51 prefilled response. Model-specific cases use
named groups and sort after every numeric group.
There is no separate "input stream mode" axis: which channel the prompt pre-opened IS
`init.starting_state`, so a case that varies only that duplicates an existing behavioral
case, and one that varies nothing but a finish_reason label duplicates groups 1-12 (the
parser cannot see that value — `finish()` takes no argument).
"""

import re

from impls import UNIFIED_DISPLAY, UNIFIED_MARKER_FAMILIES
from null_cases import NULL_VARIANTS
from schema_cases import ARGUMENT_SECTIONS, CONFORMANCE_CASES, SCHEMA_GROUPS, XML_COMPATIBILITY_CASES, argument_section, schema_fold, schema_group

UNIFIED_TAX = {
    "default_reasoning_without_opener": (10, "6"),
    "default_reasoning_tool_without_closer": (12, "5"),
    "structured_response_after_reasoning": (36, "1"),
    'harmony_guided_json_gt_in_argument_bare_opener': ("gpt_oss", "1"),
    'harmony_guided_json_gt_in_argument_named_bare_opener': ("gpt_oss", "2"),
    'harmony_guided_json_narrated_prefix_inside_reasoning': ("gpt_oss", "3"),
    'harmony_guided_json_schema_error_nameless_element_bare_opener': ("gpt_oss", "4"),
    'harmony_guided_json_schema_error_not_a_call_bare_opener': ("gpt_oss", "5"),
    'harmony_guided_json_stray_prefix_before_reasoning': ("gpt_oss", "6"),
    'harmony_guided_json_syntax_error_bare_opener': ("gpt_oss", "7"),
    'harmony_guided_json_tool_open_before_payload': ("gpt_oss", "8"),

    # Group 1 — Single call
    "tool_only": (1, "1"),
    "dotted_name_minimal": (1, "3"),
    "dotted_name_mixed_punctuation": (1, "4"),
    "dotted_name_multiple_segments": (1, "5"),
    # TODO: restore 1-2 in the follow-up to PR #232 (deferred-cases). Completed below; the family-scoped alias retains its historical ID.
    "kimi_k2_optional_prefix_name_overlap": ("kimi_k2", "1"),
    # Group 2 — Multiple calls (streamv1.2)
    "two_calls": (2, "1"), "two_calls_same_name": (2, "2"),
    "adjacent_calls_partial_header": (2, "3"),
    "three_calls_partial_header": (2, "4"),
    "dotted_name_shared_prefix": (2, "5"),
    # Group 3 — No call (streamv1.3)
    "text_only": (3, "1"),
    # Group 4 — Malformed envelope. Labelled but EMPTY until now.
    "tool_block_never_closed_then_text": (4, "1"),
    "tool_markup_only_emits_nothing": (4, "2"),

    # Group 5 — Truncation / recovery (streamv1.5)
    "truncated_tool_eof": (5, "1"), "tool_no_close": (5, "2"),
    "orphan_close_after_prose": (5, "3"),
    "malformed_json_then_two_valid_calls": (5, "4"),
    # Group 6 — Empty body (streamv1.6)
    "empty_args": (6, "1"),
    # Group 7 — Argument fidelity (streamv1.7)
    "arg_unicode": (7, "1"), "arg_marker_in_string": (7, "2"),
    "deepseek_v41_mixed_control_text_in_string": (7, "3"),
    **{scenario: (7, label.split("-", 1)[1]) for scenario, label, *_ in NULL_VARIANTS},
    "arg_json_null_ref": (7, "4.ref"),
    "arg_string_null_ref": (7, "5.ref"),
    "arg_null_mixed_labels": (7, "4.mixed_labels"),
    "glm_ref_object": (7, "9"),
    "glm_ref_encoded_targets": (7, "11"),
    "glm_ref_json_looking_strings": (7, "12"),
    "glm_ref_scalar_types": (7, "13"),
    "unused_reference_graph_parameter_types": (7, "14"),
    "nullable_reference_alias_literals": (7, "15"),
    "local_schema_id_preserves_type": (7, "16"),
    **{case["name"]: (7, f"26.{index}") for index, case in enumerate(XML_COMPATIBILITY_CASES, 1)},
    "deepseek_v41_json_invocation_body": ("deepseek", "1"),
    "glm47_reference_type_intersection": ("glm5", "2"),
    **{f"schema_{case['name']}": (7, f"{SCHEMA_GROUPS[schema_group(case['name'])][1]}.{case['name']}")
       for case in CONFORMANCE_CASES},
    # Group 8 — Content / narration position (streamv1.8)
    "text_before_tool": (8, "1"), "trailing_text_after_tool": (8, "2"),
    "text_sandwich": (8, "3"), "text_between_calls": (8, "4"),
    "narrated_calls": (8, "5"),
    "native_quoted_control_in_response": (8, "6"),
    "native_single_quoted_word_control": (8, "7"),
    "native_quoted_control_then_call": (8, "8"),
    "native_unmatched_quote_then_call": (8, "9"),
    "native_quoted_control_in_reasoning": (40, "5"),
    "native_quoted_incomplete_header": (8, "10"),
    "native_single_quote_contraction_response": (8, "11"),
    "native_single_quote_contraction_reasoning": (40, "6"),
    "guided_quoted_reasoning_closer_named": (34, "8"),
    "guided_quoted_reasoning_closer_required": (34, "9"),
    "guided_response_quoted_control_braces_named": (35, "3"),
    "guided_response_quoted_control_braces_required": (35, "4"),
    "guided_response_rejected_header_quote_ownership": (35, "5"),
    # Beam-specific: only Beam's grammar admits a bare tool header at EOS as a call.
    "empty_args_no_close": ("beam", "1"), "optional_args_no_close": ("beam", "2"),
    "muse_quoted_reserved_eom_argument": ("muse", "2"),
    "muse_quoted_reserved_eot_argument": ("muse", "3"),
    "muse_quoted_reserved_start_argument": ("muse", "4"),
    # Group 10 — Reasoning span (REASONING.*), reasoning-only
    "reason_only": (10, "1"), "reason_then_content": (10, "2"),
    "two_reason_spans": (10, "3"), "reason_unterminated": (10, "4"),
    "two_adjacent_reason_spans": (10, "5"),
    # Group 11 — Reasoning <-> tool interleaving (UNIQUE to unified)
    "reason_then_tool": (11, "1"), "reason_after_tool": (11, "2"),
    "reason_interleaved": (11, "3"), "reason_tool_text_reason_tool": (11, "4"),
    "interstitial_text": (11, "5"), "content_then_reason_then_tool": (11, "6"),
    "content_then_reason": (11, "7"), "reason_tool_reason_tool_reason": (11, "8"),
    "reason_between_calls": (11, "9"), "text_reason_tool_text_reason_tool": (11, "10"),
    # Group 12 — Adversarial nesting (a marker of one channel inside another)
    "reason_markup_in_arg": (12, "1"), "tool_in_reason": (12, "2"),
    "reason_markup_in_arg_with_text": (12, "3"), "tool_in_reason_with_text": (12, "4"),
    "kimi_k3_typed_argument_values": ("kimi", "1"),
    "kimi_k3_raw_json_arguments": ("kimi", "2"),
    "kimi_k3_spaced_xtml_markers": ("kimi", "3"),
    "kimi_k3_message_end_after_response": ("kimi", "4"),
    "kimi_k3_elided_think_close_to_response": ("kimi", "5"),
    "kimi_k3_malformed_call_then_valid": ("kimi", "6"),
    "kimi_k3_raw_json_eof": ("kimi", "7"),
    "kimi_k3_guided_native_wrapper": ("kimi", "8"),
    # Group 30 — Guided decoding: baseline and argument fidelity.
    "guided_json_named_tool": (30, "1"), "guided_json_required_tool": (30, "2"),
    "guided_json_two_calls": (30, "3"),
    "guided_json_escaped_string_args": (30, "4"), "guided_json_array_argument": (30, "5"),
    "guided_json_after_reasoning": (30, "6"), "guided_json_marker_inside_argument": (30, "7"),

    # Group 31 — Guided decoding: invalid JSON or call structure.
    "guided_json_invalid_call": (31, "1"), "guided_json_malformed_json": (31, "2"),
    "guided_json_partial_calls": (31, "3"),
    "guided_json_list_with_broken_element": (31, "4"),
    # Group 32 — Guided decoding: tool markup around the payload.
    "guided_json_tool_open_before_payload": (32, "1"),
    "guided_json_tool_close_after_payload": (32, "2"),
    "guided_json_wrapped_in_tool_markup": (32, "3"),
    "guided_json_orphan_tool_close_before_payload": (32, "4"),
    "guided_json_native_markup_only": (32, "5"),
    # Generated crossings (`_guided_product` in gen_unified_golden.py): payload
    # shape x surrounding grammar. The 31-12 through 31-20 rows are the quadrant that had ZERO
    # cases — markup present AND no call recoverable — where both the P2 recovery
    # leak and the unbounded invoke-header scan lived.
    "guided_json_syntax_error_trailing_close": (33, "1"),
    "guided_json_syntax_error_wrapped": (33, "2"),
    "guided_json_syntax_error_bare_opener": (33, "3"),
    "guided_json_schema_error_not_a_call_trailing_close": (33, "4"),
    "guided_json_schema_error_not_a_call_wrapped": (33, "5"),
    "guided_json_schema_error_not_a_call_bare_opener": (33, "6"),
    "guided_json_schema_error_nameless_element_trailing_close": (33, "7"),
    "guided_json_schema_error_nameless_element_wrapped": (33, "8"),
    "guided_json_schema_error_nameless_element_bare_opener": (33, "9"),

    # Devin-found crossings, added as AXIS entries so the next payload/surrounding
    # combination is generated rather than noticed later.
    "guided_json_gt_in_argument_trailing_close": (30, "11"),
    "guided_json_gt_in_argument_wrapped": (30, "12"),
    "guided_json_gt_in_argument_bare_opener": (30, "13"),
    # TODO: restore 30-14 in the follow-up to PR #232 (deferred-cases). Completed below with the same published ID.
    "guided_json_gt_in_argument_named_bare_opener": (30, "14"),

    # Marker OWNERSHIP: which control marker owns a `>` when two compete. The
    # corpus had no such case, and the gap leaked private reasoning as text.
    # Group 34 — Guided decoding: reasoning boundaries.
    "guided_json_narrated_invoke_in_reasoning": (34, "1"),
    "guided_json_prose_before_reasoning": (34, "2"),
    "guided_json_orphan_reason_close_before_payload": (34, "3"),
    "guided_json_stray_prefix_before_reasoning": (34, "4"),
    "guided_json_narrated_prefix_inside_reasoning": (34, "5"),
    "guided_json_unterminated_reasoning_then_wrapped_payload": (34, "6"),
    "guided_json_bare_tool_header_recovers_inside_a_thought": (34, "7"),
    # Group 35 — Guided decoding: markers in visible answers.
    "guided_json_quoted_bare_header_in_answer": (35, "1"),
    "guided_json_quoted_bare_header_after_payload": (35, "2"),
    "guided_json_quoted_bare_tool_header_in_answer": ("muse", "1"),
    "muse_unterminated_parameter_then_empty_call": ("muse", "7"),
    "muse_unterminated_parameter_then_call": ("muse", "8"),
    # 31-29 and 31-30 remain reserved for the historical Gemma-only cases.
    # TODO: restore 31-31 through 31-40 in the follow-up to PR #232 (deferred-cases). Completed below; FAMILY_LEGACY_CASE_LABELS preserves family-specific IDs.
    "qwen3_guided_non_ascii_header_in_truncated_reasoning": ("qwen3", "1"),
    "qwen3_guided_non_ascii_header_in_closed_reasoning": ("qwen3", "2"),
    "guided_json_native_parameter_body_inside_reasoning": (34, "10"),
    "guided_json_native_parameter_object_before_payload": (35, "6"),
    "guided_json_native_parameter_array_before_payload": (35, "7"),
    "qwen3_guided_reasoning_opener_inside_native_header": ("qwen3", "3"),
    "muse_glimmer_guided_message_end_inside_native_header": ("muse", "5"),
    "deepseek_v4_guided_reasoning_opener_inside_native_body": ("deepseek_v4", "1"),
    "gemma4_guided_reasoning_opener_after_call_prefix": ("gemma", "3"),
    "guided_json_reasoning_markers_inside_native_parameter": (34, "11"),
    "gemma4_guided_json_visible_call_prose_before_reasoning": ("gemma", "1"),
    "gemma4_guided_json_malformed_call_prefix_before_reasoning": ("gemma", "2"),
    "glm47_parameterless_call_shape_inside_argument": ("glm5", "1"),

    'guided_json_noncall_before_native_array_before_payload': (35, "8"),
    'guided_json_native_parameter_string_before_payload': (35, "9"),
    'gemma4_guided_response_extra_body_opener': ("gemma", "4"),
    'gpt_oss_channel_header_variants': ("gpt_oss", "1"),
    'gpt_oss_channel_first_tool_header': ("gpt_oss", "6"),
    'gpt_oss_chat_template_tool_header': ("gpt_oss", "7"),
    'gpt_oss_multiple_unknown_and_empty_tools': ("gpt_oss", "2"),
    'gpt_oss_control_marker_inside_argument_string': ("gpt_oss", "3"),
    'gpt_oss_truncated_tool_resynchronizes_at_next_message': ("gpt_oss", "4"),
    'gpt_oss_truncated_tool_at_eof_is_dropped': ("gpt_oss", "5"),
    'gpt_oss_interrupted_reasoning_then_tool': ("gpt_oss", "8"),
    'gpt_oss_interrupted_reasoning_then_tool_with_text': ("gpt_oss", "9"),
    'gpt_oss_invalid_tool_body_then_empty_call': ("gpt_oss", "10"),
    'gpt_oss_invalid_tool_body_then_valid_call': ("gpt_oss", "11"),
    'gpt_oss_interrupted_reasoning_then_response': ("gpt_oss", "12"),
    "gpt_oss_tool_body_whitespace": ("gpt_oss", "13"),
    "gpt_oss_constrained_final_header": ("gpt_oss", "14"),
    "gpt_oss_implicit_recipient_first_header": ("gpt_oss", "15"),
    "gpt_oss_quoted_truncated_tool_then_final": ("gpt_oss", "16"),
    "gpt_oss_quoted_message_header_literal": ("gpt_oss", "17"),
    "gpt_oss_complete_alternate_message_ends": ("gpt_oss", "18"),

    # Group 40 — Prefilled reasoning, happy
    "prefilled_reasoning_with_tool": (40, "1"), "prefilled_reasoning_with_guided_json": (40, "2"),
    "prefilled_reasoning_then_text_then_tool": (40, "3"), "prefilled_reasoning_then_text": (40, "4"),
    # Group 41 — Prefilled reasoning, weird / malformed
    "prefilled_reasoning_redundant_opener": (41, "1"), "prefilled_reasoning_truncated": (41, "2"),
    "prefilled_response_reasoning_markers_literal": (50, "4"),
    # TODO: restore 50-1 and 50-2 in the follow-up to PR #232 (deferred-cases). Completed below with family-scoped aliases.
    "prefilled_response_guided_pending_invoke_header": ("deepseek_v41", "2"),
    "prefilled_response_guided_closer_inside_invoke_quote": ("muse", "6"),
    # DeepSeek V4 and V4.1 — DSML tool-call separator framing.
    **{scenario: ("dsml", str(index)) for index, scenario in enumerate([
        "dsml_separator_two_lf", "dsml_separator_four_lf", "dsml_no_separator",
        "dsml_empty_content_separator", "dsml_bare_invoke_two_lf", "dsml_bare_invoke_four_lf",
        "dsml_whitespace_content_separator", "dsml_reasoning_then_separator",
    ], 1)},
}

# Axis prefix makes each group's channel explicit: "TC" = tool-calling only (groups
# 1-9 mirror the tool STREAM suite), "Reasoning" = reasoning only, groups 11-12 mix both.
UNIFIED_GROUP_LABEL = UNIFIED_DISPLAY["group_labels"]


def tax(scenario):
    """(group_label, subcase_label) for a scenario slug; group 9 for anything unmapped.

    NUMBERING ONLY. A case's parser configuration (`init`) and its stream
    properties (`finish_reason`) are declared per case in `gen_unified_golden.py` and flow
    through the fixtures to the page. Keeping a second copy here would be a
    divergent copy of the same fact, free to drift from what the harness applies.
    """
    return UNIFIED_TAX.get(scenario, (9, scenario))


# Display placement may change without renumbering published capture IDs.
_DISPLAY_GROUP = UNIFIED_DISPLAY["group_overrides"]


def display_tax(scenario):
    group, sub = tax(scenario)
    parent = case_fold(scenario)
    if parent and parent[0] != scenario:
        return display_tax(parent[0])[0], sub
    return _DISPLAY_GROUP.get(scenario, group), sub


def display_section(scenario):
    group, _ = display_tax(scenario)
    if group == 7:
        section = argument_section((case_fold(scenario) or (scenario, ""))[0])
        return f"unified_g7_{section}", ARGUMENT_SECTIONS[section]
    return f"unified_g{group}", UNIFIED_GROUP_LABEL.get(group, "Other")


def display_sort_key(scenario):
    group, _ = display_tax(scenario)
    group_key = (0, group) if isinstance(group, int) else (1, str(group))
    section_rank = list(ARGUMENT_SECTIONS).index(argument_section((case_fold(scenario) or (scenario, ""))[0])) if group == 7 else 0
    return group_key, section_rank, case_description(scenario), scenario


DISPLAY_PREFIXES = {group: tuple(prefixes) for group, prefixes in UNIFIED_DISPLAY["prefixes"].items()}


def display_case_labels(scenarios):
    """Display ranks belong to the visible corpus, never to capture identities."""
    labels = {}
    counts = {}
    for scenario in sorted(set(scenarios), key=display_sort_key):
        group, _ = display_tax(scenario)
        full_prefix, compact_prefix = DISPLAY_PREFIXES.get(group, (str(group), str(group)))
        counts[compact_prefix] = counts.get(compact_prefix, 0) + 1
        labels[scenario] = {
            "label": f"{full_prefix}-{case_description(scenario)}",
            "compact_prefix": compact_prefix,
            "display_number": counts[compact_prefix],
        }
    return labels


def taxonomy_sort_key(scenario):
    """Sort numeric groups first and their numeric suffixes numerically."""
    group, sub = tax(scenario)
    group_key = (0, group) if isinstance(group, int) else (1, str(group))
    if sub.isdecimal():
        return group_key, int(sub), ""
    return group_key, 10_000, sub


GPT_OSS_PR424_REQUEST_VARIANTS = {
    'arg_marker_in_string': True,
    'deepseek_v41_mixed_control_text_in_string': True,
    'guided_json_after_reasoning': True,
    'guided_json_array_argument': False,
    'guided_json_bare_tool_header_recovers_inside_a_thought': True,
    'guided_json_escaped_string_args': False,
    'guided_json_gt_in_argument_trailing_close': True,
    'guided_json_gt_in_argument_wrapped': True,
    'guided_json_invalid_call': False,
    'guided_json_list_with_broken_element': False,
    'guided_json_malformed_json': False,
    'guided_json_marker_inside_argument': True,
    'guided_json_named_tool': False,
    'guided_json_narrated_invoke_in_reasoning': True,
    'guided_json_narrated_prefix_inside_reasoning': True,
    'guided_json_native_markup_only': True,
    'guided_json_native_parameter_body_inside_reasoning': True,
    'guided_json_orphan_reason_close_before_payload': True,
    'guided_json_orphan_tool_close_before_payload': True,
    'guided_json_partial_calls': False,
    'guided_json_prose_before_reasoning': True,
    'guided_json_quoted_bare_header_after_payload': True,
    'guided_json_quoted_bare_header_in_answer': True,
    'guided_json_reasoning_markers_inside_native_parameter': True,
    'guided_json_required_tool': False,
    'guided_json_schema_error_nameless_element_bare_opener': False,
    'guided_json_schema_error_nameless_element_trailing_close': True,
    'guided_json_schema_error_nameless_element_wrapped': True,
    'guided_json_schema_error_not_a_call_trailing_close': True,
    'guided_json_schema_error_not_a_call_wrapped': True,
    'guided_json_stray_prefix_before_reasoning': True,
    'guided_json_syntax_error_bare_opener': False,
    'guided_json_syntax_error_trailing_close': True,
    'guided_json_syntax_error_wrapped': True,
    'guided_json_tool_close_after_payload': True,
    'guided_json_two_calls': False,
    'guided_json_unterminated_reasoning_then_wrapped_payload': True,
    'guided_json_wrapped_in_tool_markup': True,
    'guided_quoted_reasoning_closer_named': True,
    'guided_quoted_reasoning_closer_required': True,
    'prefilled_reasoning_with_guided_json': True,
}

for _scenario, _active in GPT_OSS_PR424_REQUEST_VARIANTS.items():
    if not _active:
        continue
    _group, _sub = UNIFIED_TAX[_scenario]
    _next_sub = max(
        int(sub) for group, sub in UNIFIED_TAX.values()
        if group == _group and sub.isdecimal()
    ) + 1
    UNIFIED_TAX[_scenario + "_pr424"] = (_group, str(_next_sub))



# Assign new numeric IDs after historical variants so their published ranks do not move.
UNIFIED_TAX["guided_response_native_wrapper_whitespace_before_prose"] = (35, "12")


# Historical requests remain separate executions, but share one semantic heading.
RETIRED_SCENARIOS = frozenset({"gpt_oss_truncated_tool_at_eof_is_dropped"})
SHARED_CASE_VARIANTS = {
    **{scenario + "_pr424": (scenario, "Retained #424 delivery / input")
       for scenario, active in GPT_OSS_PR424_REQUEST_VARIANTS.items() if active},
    **{scenario: (scenario.removeprefix("harmony_"), "Harmony partial header")
       for scenario in UNIFIED_TAX if scenario.startswith("harmony_")},
    "gpt_oss_multiple_unknown_and_empty_tools": ("two_calls", "Empty body and unoffered names"),
    "gpt_oss_control_marker_inside_argument_string": ("arg_marker_in_string", "All Harmony controls"),
    "gpt_oss_truncated_tool_resynchronizes_at_next_message": ("tool_no_close", "Next message recovery"),
    "gpt_oss_interrupted_reasoning_then_tool": ("tool_in_reason", "Interrupted Harmony reasoning"),
    "gpt_oss_interrupted_reasoning_then_tool_with_text": ("tool_in_reason_with_text", "Interrupted Harmony reasoning"),
    "gpt_oss_interrupted_reasoning_then_response": ("reason_then_content", "Elided Harmony reasoning close"),
    "kimi_k3_elided_think_close_to_response": ("reason_then_content", "Elided Kimi K3 reasoning close"),
    "gpt_oss_invalid_tool_body_then_empty_call": ("malformed_json_then_two_valid_calls", "Invalid text then empty call"),
    "gpt_oss_invalid_tool_body_then_valid_call": ("malformed_json_then_two_valid_calls", "Truncated JSON then valid call"),
    "gpt_oss_tool_body_whitespace": ("tool_only", "Leading JSON body whitespace"),
    "gpt_oss_quoted_truncated_tool_then_final": ("tool_no_close", "Malformed argument then visible response"),
    "gpt_oss_quoted_message_header_literal": ("arg_marker_in_string", "Quoted closer and response header"),
}
_SHARED_VARIANT_PARENTS = {parent for parent, _ in SHARED_CASE_VARIANTS.values()}


def case_fold(scenario):
    """One grouping owner for schema, native grammar, and delivery variants."""
    return (schema_fold(scenario) or SHARED_CASE_VARIANTS.get(scenario)
            or ((scenario, "Standard") if scenario in _SHARED_VARIANT_PARENTS else None))


def legacy_case_label(scenario):
    """Published numeric identity, retained for ordering and compatibility."""
    group, sub = tax(scenario)
    return f"{group}-{sub}"


GROUP_DESCRIPTION_PREFIXES = {
    "kimi": ("kimi_k3_",),
    "gemma": ("gemma4_",),
    "glm5": ("glm47_",),
    "deepseek": ("deepseek_v41_",),
    "muse": ("muse_",),
    "dsml": ("dsml_",),
    "gpt_oss": ("gpt_oss_",),
}


def case_description(scenario):
    """The tested behavior, independent of its ordering and display placement."""
    if scenario.startswith("schema_"):
        return scenario.removeprefix("schema_")
    for prefix in GROUP_DESCRIPTION_PREFIXES.get(tax(scenario)[0], ()):
        if scenario.startswith(prefix):
            return scenario.removeprefix(prefix)
    return scenario


def case_label(scenario):
    return f"{tax(scenario)[0]}-{case_description(scenario)}"


def numbered_id(scenario):
    """Scenario slug -> canonical descriptive ID (historical API name)."""
    return f"UNIFIED.{case_label(scenario)}"


# Historical capture archives remain byte-for-byte evidence. This map is the one
# read-side bridge from their former labels to the scenario-owned current label.
# Current inputs and goldens use ``numbered_id`` and never write these aliases.
LEGACY_CASE_LABELS = {
    "7-6": "deepseek_v41_json_invocation_body",
    "7-7": "glm47_reference_type_intersection",
    "1.a": "tool_only",
    "2.a": "two_calls", "2.b": "two_calls_same_name",
    "3.a": "text_only",
    "4.a": "tool_block_never_closed_then_text", "4.b": "tool_markup_only_emits_nothing",
    "5.a": "truncated_tool_eof", "5.b": "tool_no_close", "5.c": "orphan_close_after_prose",
    "6.a": "empty_args",
    "7.a": "arg_unicode", "7.b": "arg_marker_in_string",
    "qwen-1": "arg_json_null",
    "8.a": "text_before_tool", "8.b": "trailing_text_after_tool", "8.c": "text_sandwich",
    "8.d": "text_between_calls", "8.e": "narrated_calls",
    "10.a": "reason_only", "10.b": "reason_then_content", "10.c": "two_reason_spans",
    "10.d": "reason_unterminated", "10.e": "two_adjacent_reason_spans",
    "11.a": "reason_then_tool", "11.b": "reason_after_tool", "11.c": "reason_interleaved",
    "11.d": "reason_tool_text_reason_tool", "11.e": "interstitial_text",
    "11.f": "content_then_reason_then_tool", "11.g": "content_then_reason",
    "11.h": "reason_tool_reason_tool_reason", "11.i": "reason_between_calls",
    "11.j": "text_reason_tool_text_reason_tool",
    "12.a": "reason_markup_in_arg", "12.b": "tool_in_reason",
    "12.c": "reason_markup_in_arg_with_text", "12.d": "tool_in_reason_with_text",
    "k3-1": "kimi_k3_typed_argument_values", "k3-2": "kimi_k3_raw_json_arguments",
    "k3-3": "kimi_k3_spaced_xtml_markers", "k3-4": "kimi_k3_message_end_after_response",
    "k3-5": "kimi_k3_elided_think_close_to_response", "k3-6": "kimi_k3_malformed_call_then_valid",
    "k3-7": "kimi_k3_raw_json_eof", "k3-8": "kimi_k3_guided_native_wrapper",
    "30.a": "guided_json_named_tool", "30.b": "guided_json_required_tool",
    "30.c": "guided_json_two_calls", "30.d": "guided_json_escaped_string_args",
    "30.e": "guided_json_array_argument", "30.f": "guided_json_after_reasoning",
    "30.g": "guided_json_marker_inside_argument", "30.k": "guided_json_gt_in_argument_trailing_close",
    "30.l": "guided_json_gt_in_argument_wrapped", "30.m": "guided_json_gt_in_argument_bare_opener",
    "31-1": "guided_json_invalid_call", "31-2": "guided_json_malformed_json",
    "31-3": "guided_json_partial_calls", "31-4": "guided_json_list_with_broken_element",
    "31-5": "guided_json_tool_open_before_payload", "31-6": "guided_json_tool_close_after_payload",
    "31-7": "guided_json_wrapped_in_tool_markup", "31-8": "guided_json_narrated_invoke_in_reasoning",
    "31-9": "guided_json_prose_before_reasoning", "31-10": "guided_json_orphan_reason_close_before_payload",
    "31-11": "guided_json_orphan_tool_close_before_payload",
    "31-12": "guided_json_syntax_error_trailing_close", "31-13": "guided_json_syntax_error_wrapped",
    "31-14": "guided_json_syntax_error_bare_opener",
    "31-15": "guided_json_schema_error_not_a_call_trailing_close",
    "31-16": "guided_json_schema_error_not_a_call_wrapped",
    "31-17": "guided_json_schema_error_not_a_call_bare_opener",
    "31-18": "guided_json_schema_error_nameless_element_trailing_close",
    "31-19": "guided_json_schema_error_nameless_element_wrapped",
    "31-20": "guided_json_schema_error_nameless_element_bare_opener",
    "31-21": "guided_json_stray_prefix_before_reasoning",
    "31-22": "guided_json_narrated_prefix_inside_reasoning",
    "31-23": "guided_json_native_markup_only",
    "31-24": "guided_json_unterminated_reasoning_then_wrapped_payload",
    "31-25": "guided_json_quoted_bare_header_in_answer",
    "31-26": "guided_json_quoted_bare_tool_header_in_answer",
    "31-27": "guided_json_quoted_bare_header_after_payload",
    "31-28": "guided_json_bare_tool_header_recovers_inside_a_thought",
    "31-33": "guided_json_native_parameter_body_inside_reasoning",
    "31-34": "guided_json_native_parameter_object_before_payload",
    "31-35": "guided_json_native_parameter_array_before_payload",
    "31-40": "guided_json_reasoning_markers_inside_native_parameter",
    "g4-1": "gemma4_guided_json_visible_call_prose_before_reasoning",
    "g4-2": "gemma4_guided_json_malformed_call_prefix_before_reasoning",
    "40.a": "prefilled_reasoning_with_tool", "40.b": "prefilled_reasoning_with_guided_json",
    "40.c": "prefilled_reasoning_then_text_then_tool", "40.d": "prefilled_reasoning_then_text",
    "41.a": "prefilled_reasoning_redundant_opener", "41.b": "prefilled_reasoning_truncated",
    "50.d": "prefilled_response_reasoning_markers_literal",
}


def _label_owners(scenario_labels, historical_labels):
    owners = {}
    for scenario, labels in scenario_labels.items():
        for label in labels:
            owners.setdefault(label, set()).add(scenario)
    for label, scenario in historical_labels.items():
        owners.setdefault(label, set()).add(scenario)
    return owners


_LABEL_OWNERS = _label_owners(
    {scenario: (case_label(scenario), legacy_case_label(scenario)) for scenario in UNIFIED_TAX},
    LEGACY_CASE_LABELS,
)

FAMILY_LEGACY_CASE_LABELS = {
    ("deepseek_v41", "deepseek_v41-1"): "deepseek_v41_mixed_control_text_in_string",
    ("deepseek_v4", "31-38"): "deepseek_v4_guided_reasoning_opener_inside_native_body",
    ("deepseek_v41", "50-1"): "prefilled_response_guided_pending_invoke_header",
    ("gemma4", "31-29"): "gemma4_guided_json_visible_call_prose_before_reasoning",
    ("gemma4", "31-30"): "gemma4_guided_json_malformed_call_prefix_before_reasoning",
    ("gemma4", "31-39"): "gemma4_guided_reasoning_opener_after_call_prefix",
    ("kimi_k2", "1-2"): "kimi_k2_optional_prefix_name_overlap",
    ("muse_glimmer", "31-37"): "muse_glimmer_guided_message_end_inside_native_header",
    ("muse_glimmer", "50-2"): "prefilled_response_guided_closer_inside_invoke_quote",
    ("qwen3", "31-31"): "qwen3_guided_non_ascii_header_in_truncated_reasoning",
    ("qwen3", "31-32"): "qwen3_guided_non_ascii_header_in_closed_reasoning",
    ("qwen3", "31-36"): "qwen3_guided_reasoning_opener_inside_native_header",
}


def scenario_for_label(label, family=None, scenario=None):
    """Resolve aliases without changing the meaning of older published labels."""
    label = label.removeprefix("UNIFIED.")
    if family and label.endswith(f".{family}"):
        label = label[:-(len(family) + 1)]
    family_scenario = FAMILY_LEGACY_CASE_LABELS.get((family, label))
    if family_scenario is not None:
        if scenario is not None and scenario != family_scenario:
            raise ValueError(f"conflicting Unified scenario ownership: {label}: {family_scenario}, {scenario}")
        return family_scenario
    if label in UNIFIED_TAX:
        return label
    if family == "gemma4":
        label = {"31-29": "g4-1", "31-30": "g4-2"}.get(label, label)
    dotted_group_31 = re.fullmatch(r"31\.([a-x])", label)
    if dotted_group_31:
        label = f"31-{ord(dotted_group_31[1]) - ord('a') + 1}"
    owners = _LABEL_OWNERS.get(label, set())
    if len(owners) > 1 and scenario in owners:
        return scenario
    if len(owners) > 1:
        raise ValueError(f"conflicting Unified alias ownership: {label}: {sorted(owners)}")
    owner = next(iter(owners), None)
    if owner is not None and family:
        family_names = sorted({name for name, _label in FAMILY_LEGACY_CASE_LABELS}, key=len, reverse=True)
        owner_family = next((name for name in family_names if owner.startswith(f"{name}_")), None)
        if owner_family is not None and owner_family != family:
            return None
    return owner


def historical_case_label(label, family=None, scenario=None):
    owner = scenario_for_label(label, family, scenario)
    if scenario in UNIFIED_TAX:
        if owner is not None and owner != scenario:
            raise ValueError(f"conflicting Unified scenario ownership: {label}: {owner}, {scenario}")
        owner = scenario
    return case_label(owner) if owner is not None else label


# The unified corpus names a family by its MODEL family (`qwen3`); the grammar-token
# registry in parser_families.yaml names the SAME grammar by its parser family
# (`qwen3_coder`). The popup colorizer is driven by the registry, so a corpus family
# has to be translated before it is used to color markup — otherwise the family has no
# declared markers, the colorizer falls back to heuristics, and its opaque
# argument-value regions (`opaque:`) are not applied.
# Derived from the ONE declaration in parser_families.yaml (`unified:` -> `registry`),
# so a family whose corpus name differs from its registry name says so in one place.
MARKER_FAMILY = UNIFIED_MARKER_FAMILIES


def marker_family(family):
    """Corpus family -> the parser_families.yaml `markers:` family that types it."""
    return MARKER_FAMILY.get(family, family)
