#!/usr/bin/env python3
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Refresh the DYNAMO capture dirs of the local fixture staging tree after an
intentional parser behavior change, without touching any peer (vLLM/SGLang)
capture. Peers need engine containers to re-capture; the Dynamo captures come
from this repo's own crates, so they can (and must) be refreshed whenever the
parser output changes — the parity tests compare the live parsers against them.

Modes (any subset; default all):
  batch            fixtures-batch-v1/dynamo_v1-<v1 crate ver>/    (expected.dynamo_v1,
                   via the record_dynamo_batch bin — the v1 batch parser).
  stream           fixtures-stream-v1/dynamo_v2-<crate version>/ (per-chunk
                   expected, via record_dynamo_stream — the v2 stream parser).
                   Both paths use their crate version. Other version dirs
                   remain as historical comparison candidates.
  batch-on-stream  fixtures-batch-on-stream-v1/<family>/*.yaml    (the dynamo_v2
                   case blocks + captured_with stamp, via record_batch_via_stream —
                   the v2 stream parser fed each batch sample as one chunk).

The tree is the working copy that package_and_publish.py packages
(conformance/toolcalling/...). If a fixture tree is missing there, it is first
copied from the immutable snapshot resolved by `extract_fixtures.py` so peer data
carries over unchanged.

Usage:
  python3 refresh_dynamo_captures.py                # all three modes
  python3 refresh_dynamo_captures.py batch stream   # a subset
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import yaml

from dynamo_version import capture_source_fingerprint, crate_version, dynamo_v2_label, dynamo_v2_provenance
from fixture_snapshot import fixture_snapshot_root
import stream_capture_archive

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent.parent  # conformance/utils/src -> repo root
TREE = ROOT / "conformance" / "toolcalling"
CARGO = os.environ.get("CARGO", "cargo").split()

SPDX = [
    "# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.",
    "# SPDX-License-Identifier: Apache-2.0",
]

_FAMILIES = yaml.safe_load((HERE / "parser_families.yaml").read_text())["families"]
# Families the Dynamo v2 stream parser implements (the registry's single source
# of truth) — these get stream + batch-on-stream captures.
V2_FAMILIES = sorted(f for f, s in _FAMILIES.items() if s.get("dynamo_v2"))


def ensure_tree(name: str) -> Path:
    """Return TREE/<name>, copying it from the fixture cache on first use."""
    dst = TREE / name
    if not (dst / "inputs").is_dir() and not any(dst.glob("*/*.yaml")):
        src = fixture_snapshot_root() / "toolcalling" / name
        if not src.is_dir():
            raise SystemExit(f"{src} not cached — run extract_fixtures.py first")
        print(f"[refresh] copying {src} -> {dst}")
        shutil.copytree(src, dst, dirs_exist_ok=True)
    return dst


def run_bin(crate: str, bin_name: str, args: list[str]) -> str:
    cmd = [*CARGO, "run", "-q", "-p", crate, "--bin", bin_name, "--", *args]
    return subprocess.run(
        cmd, cwd=ROOT, check=True, stdout=subprocess.PIPE, text=True
    ).stdout


def dump_yaml(data: dict, header: list[str] | None = None) -> str:
    body = yaml.safe_dump(
        data, sort_keys=False, allow_unicode=True, width=100000, default_flow_style=False
    )
    return "\n".join((header or []) + ["", body]) if header else body


def run_json_bin(crate: str, bin_name: str, payload: dict) -> dict:
    """Run a JSON-file-in / JSON-stdout-out recorder bin."""
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as tf:
        json.dump(payload, tf)
        tmp = tf.name
    try:
        return json.loads(run_bin(crate, bin_name, [tmp]))
    finally:
        os.unlink(tmp)


def _sorted_value(v):
    """Recursively sort mapping keys so decoded call arguments are deterministic
    across captures (the v1 parser serializes arguments from a hash map)."""
    if isinstance(v, dict):
        return {k: _sorted_value(v[k]) for k in sorted(v)}
    if isinstance(v, list):
        return [_sorted_value(x) for x in v]
    return v


def _assemble_jail_chunks(chunks: list) -> dict:
    """Assemble record_dynamo_jail_stream per-chunk output into the legacy stream
    fixture's {calls, normal_text} block (concatenate per tool index, decode args)."""
    names: dict[int, str] = {}
    args: dict[int, str] = {}
    normal_text = ""
    for ch in chunks:
        normal_text += ch.get("normal_text") or ""
        for d in ch.get("deltas") or []:
            idx = d["index"]
            if d.get("name"):
                names[idx] = names.get(idx, "") + d["name"]
            if d.get("arguments"):
                args[idx] = args.get(idx, "") + d["arguments"]
    calls = []
    for idx in sorted(names):
        raw = args.get(idx, "")
        try:
            arguments = _sorted_value(json.loads(raw))
        except (json.JSONDecodeError, ValueError):
            arguments = raw
        calls.append({"name": names[idx], "arguments": arguments})
    return {"calls": calls, "normal_text": normal_text}


def refresh_batch(v1_ver: str) -> None:
    tree = ensure_tree("fixtures-batch-v1")
    inputs = tree / "inputs"
    # The current-version dir is (re)written in place; OLDER version dirs are
    # capture history and MUST stay — the chart compares them as candidates and
    # readers resolve versions ascending (never delete an existing version).
    out_root = tree / f"dynamo_v1-{v1_ver}"
    if out_root.is_dir():
        shutil.rmtree(out_root)
    header = SPDX + [
        f"# Full anchor for dynamo@{v1_ver}. expected.dynamo_v1 only."
    ]
    n_batch = n_stream = 0
    for fam_dir in sorted(p for p in inputs.iterdir() if p.is_dir()):
        family = fam_dir.name
        for fp in sorted(fam_dir.glob("TOOLCALLING.*.yaml")):
            src = yaml.safe_load(fp.read_text())
            mode = src.get("mode")
            cases_out = {}
            if mode == "batch":
                cases_in = {
                    cid: {"model_text": c["model_text"], "tools": c.get("tools") or []}
                    for cid, c in (src.get("cases") or {}).items()
                    if isinstance(c, dict) and c.get("model_text") is not None
                }
                if not cases_in:
                    continue
                rec = run_json_bin(
                    "dynamo-parsers",
                    "record_dynamo_batch",
                    {"family": family, "cases": cases_in},
                )
                cases_out = {
                    cid: {"expected": {"dynamo_v1": rec[cid]}} for cid in cases_in if cid in rec
                }
                n_batch += len(cases_out)
            elif mode == "stream":
                # Legacy v1 jail expected (assembled): feed the per-chunk delta_text
                # through JailedStream + the v1 batch parser.
                # Tool schemas ride along so the batch parse coerces argument types.
                cases_in = {
                    cid: {
                        "chunks": [ch.get("delta_text", "") for ch in (c.get("chunks") or [])],
                        "tools": c.get("tools") or [],
                    }
                    for cid, c in (src.get("cases") or {}).items()
                    if isinstance(c, dict) and c.get("chunks")
                }
                if not cases_in:
                    continue
                rec = run_json_bin(
                    "dynamo-parsers",
                    "record_dynamo_jail_stream",
                    {"family": family, "cases": cases_in},
                )
                cases_out = {
                    cid: {"expected": {"dynamo_v1": _assemble_jail_chunks(rec[cid])}}
                    for cid in cases_in
                    if cid in rec
                }
                n_stream += len(cases_out)
            if not cases_out:
                continue
            doc = {"family": family, "mode": mode, "cases": cases_out}
            dst = out_root / family / fp.name
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_text(dump_yaml(doc, header))
        print(f"[batch] {family}: recorded")
    print(f"[batch] wrote {out_root.name} ({n_batch} batch + {n_stream} jail-stream cases)")


def refresh_stream(v2_ver: str, receipt_path: Path | None = None) -> None:
    producer = None
    if receipt_path is not None:
        dynamo_v2_label(ROOT, v2_ver)
        producer = dynamo_v2_provenance(ROOT, "current")
        if producer["source_sha256"] != capture_source_fingerprint(ROOT, v2_ver):
            raise ValueError(f"stream capture source does not match release {v2_ver}; pin a new unpublished version")
    tree = ensure_tree("fixtures-stream-v1")
    inputs = tree / "inputs"
    # The current-version dir is (re)written in place; OLDER version dirs
    # (earlier 0.x v2 captures, the v1-major jail references) are capture
    # history and MUST stay — never delete an existing version.
    out_root = tree / f"dynamo_v2-{v2_ver}"
    if out_root.is_dir():
        shutil.rmtree(out_root)
    n_cases = 0
    receipt_cases = {}
    for family in V2_FAMILIES:
        fam_dir = inputs / family
        if not fam_dir.is_dir():
            print(f"[stream] {family}: no inputs, skipped")
            continue
        for fp in sorted(fam_dir.glob("TOOLCALLING.stream*.yaml")):
            input_payload = fp.read_bytes()
            src = yaml.safe_load(input_payload)
            extra = ["--text"] if family == "harmony_text" else []
            with tempfile.TemporaryDirectory(prefix="dynamo-stream-input-") as temporary:
                snapshot_path = Path(temporary) / fp.name
                snapshot_path.write_bytes(input_payload)
                rec = json.loads(
                    run_bin(
                        "dynamo-parsers-v2",
                        "record_dynamo_stream",
                        [str(snapshot_path), *extra],
                    )
                )
            cases_out = {}
            source_cases = src.get("cases") or {}
            for cid, case in source_cases.items():
                unavailable = (case.get("unavailable") or {}).get("dynamo_v2")
                if unavailable:
                    cases_out[cid] = {"unavailable": unavailable}
                    continue
                if cid not in rec:
                    raise SystemExit(
                        f"[stream] {family}: recorder omitted supported case {cid} "
                        f"from {fp.name}"
                    )
                chunks = rec[cid]
                out_chunks = []
                for ch in chunks:
                    entry = {"expected": ch.get("deltas") or []}
                    if ch.get("normal_text"):
                        entry["normal_text"] = ch["normal_text"]
                    out_chunks.append(entry)
                cases_out[cid] = {"chunks": out_chunks}
            relative = fp.relative_to(inputs).as_posix()
            receipt_cases[relative] = {
                cid: {
                    "input_sha256": stream_capture_archive.case_sha256(case),
                    "result_sha256": stream_capture_archive.case_sha256(cases_out[cid]),
                }
                for cid, case in source_cases.items()
            }
            n_cases += len(cases_out)
            doc = {
                "family": family,
                "mode": src.get("mode", "streamv1"),
                "captured_with": {"dynamo_v2": v2_ver},
                "cases": cases_out,
            }
            dst = out_root / family / fp.name
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_text(dump_yaml(doc, SPDX))
        print(f"[stream] {family}: recorded")
    print(f"[stream] wrote {out_root.name} ({n_cases} cases)")
    if receipt_path is not None:
        receipt_path.parent.mkdir(parents=True, exist_ok=True)
        receipt_captures = {}
        if receipt_path.exists():
            prior_receipt = json.loads(receipt_path.read_text())
            if (
                not isinstance(prior_receipt, dict)
                or prior_receipt.get("format") != "dynamo-stream-capture-receipt-v2"
                or not isinstance(prior_receipt.get("captures"), dict)
            ):
                raise ValueError(f"invalid stream capture receipt: {receipt_path}")
            receipt_captures = prior_receipt["captures"]
        receipt_captures[out_root.name] = {
            "producer_source_sha256": producer["source_sha256"],
            "cases": receipt_cases,
        }
        receipt_path.write_text(
            json.dumps(
                {
                    "format": "dynamo-stream-capture-receipt-v2",
                    "captures": receipt_captures,
                },
                indent=2,
                sort_keys=True,
            )
            + "\n"
        )
        print(f"[stream] wrote capture receipt {receipt_path}")


def refresh_batch_on_stream(v2_ver: str) -> None:
    tree = ensure_tree("fixtures-batch-on-stream-v1")
    batch_inputs = ensure_tree("fixtures-batch-v1") / "inputs"
    for family in V2_FAMILIES:
        fam_dir = tree / family
        if not (batch_inputs / family).is_dir():
            print(f"[batch-on-stream] {family}: no batch inputs, skipped")
            continue
        rec = json.loads(
            run_bin(
                "dynamo-parsers-v2",
                "record_batch_via_stream",
                ["--family", family, "--root", str(batch_inputs)],
            )
        )
        if not fam_dir.is_dir():
            # First capture for this family (e.g. a newly registered v2 parser):
            # create the dir from the batch inputs' file layout, Dynamo-only.
            # Peer keys stay absent — the peers were never captured on
            # batch-on-stream for this family (needs engine containers) and the
            # renderer shows an absent impl as unavailable, not as clean output.
            for src in sorted((batch_inputs / family).glob("TOOLCALLING.batch*.yaml")):
                src_doc = yaml.safe_load(src.read_text())
                if src_doc.get("mode") != "batch":
                    continue
                cases = {
                    cid: {"dynamo_v2": rec[cid]}
                    for cid in (src_doc.get("cases") or {})
                    if cid in rec
                }
                if not cases:
                    continue
                doc = {
                    "family": family,
                    "mode": "batch-on-stream",
                    "captured_with": {"dynamo_v2": v2_ver},
                    "cases": cases,
                }
                fam_dir.mkdir(parents=True, exist_ok=True)
                (fam_dir / src.name).write_text(dump_yaml(doc))
            print(f"[batch-on-stream] {family}: created dir, recorded {len(rec)} cases")
            continue
        # A new authored batch file must also acquire a stream-on-batch capture
        # when this family already has older files in the overlay.
        for src in sorted((batch_inputs / family).glob("TOOLCALLING.batch*.yaml")):
            dst = fam_dir / src.name
            if dst.exists():
                continue
            source = yaml.safe_load(src.read_text())
            if source.get("mode") != "batch":
                continue
            cases = {cid: {"dynamo_v2": rec[cid]}
                     for cid in (source.get("cases") or {}) if cid in rec}
            if cases:
                dst.write_text(dump_yaml({
                    "family": family, "mode": "batch-on-stream",
                    "captured_with": {"dynamo_v2": v2_ver}, "cases": cases,
                }))
        for fp in sorted(fam_dir.glob("TOOLCALLING.batch*.yaml")):
            doc = yaml.safe_load(fp.read_text())
            # Refuse a partial refresh: if the recorder omitted a case that already
            # carries a dynamo_v2 capture, folding would leave that stale value in
            # place while captured_with advances to v2_ver — publishing a mixed,
            # lying snapshot. Fail before touching provenance.
            stale = [
                cid
                for cid, case in (doc.get("cases") or {}).items()
                if isinstance(case, dict) and "dynamo_v2" in case and cid not in rec
            ]
            if stale:
                raise SystemExit(
                    f"[batch-on-stream] {family}: recorder omitted cases {sorted(stale)} "
                    f"that already have a dynamo_v2 capture in {fp.name}; refusing to "
                    f"publish a partial refresh under {v2_ver}"
                )
            changed = False
            for cid, case in (doc.get("cases") or {}).items():
                if cid in rec and isinstance(case, dict):
                    # dynamo_v2 leads each case block, like the previously
                    # captured families.
                    case.pop("dynamo_v2", None)
                    new_case = {"dynamo_v2": rec[cid], **case}
                    doc["cases"][cid] = new_case
                    changed = True
            if changed:
                doc.setdefault("captured_with", {})["dynamo_v2"] = v2_ver
                fp.write_text(dump_yaml(doc))
        print(f"[batch-on-stream] {family}: folded {len(rec)} cases")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "modes", nargs="*", choices=[[], "batch", "stream", "batch-on-stream"],
        help="subset of captures to refresh (default: all)",
    )
    ap.add_argument(
        "--label", default=None,
        help="current crate version or 'current'; source-qualified labels are rejected.",
    )
    ap.add_argument(
        "--receipt",
        type=Path,
        default=None,
        help="accumulate per-version input/result hashes and parser source identity",
    )
    args = ap.parse_args()
    modes = args.modes or ["batch", "stream", "batch-on-stream"]
    if args.receipt is not None and "stream" not in modes:
        ap.error("--receipt requires the stream mode")

    v1_ver = crate_version(ROOT / "parsers" / "v1" / "Cargo.toml")
    v2_ver = dynamo_v2_label(ROOT, args.label)
    print(f"[refresh] dynamo-parsers {v1_ver}, dynamo-parsers-v2 {v2_ver}")

    if "batch" in modes:
        refresh_batch(v1_ver)
    if "stream" in modes:
        refresh_stream(v2_ver, args.receipt)
    if "batch-on-stream" in modes:
        refresh_batch_on_stream(v2_ver)
    return 0


if __name__ == "__main__":
    sys.exit(main())
