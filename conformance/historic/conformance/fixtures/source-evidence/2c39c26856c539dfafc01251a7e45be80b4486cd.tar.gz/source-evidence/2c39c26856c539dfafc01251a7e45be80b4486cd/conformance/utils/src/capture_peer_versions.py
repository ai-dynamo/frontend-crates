#!/usr/bin/env python3
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Re-capture a peer engine's parser output against a NEWER version and write
changed-only version overlays, so every conformance tab can compare peer versions
the way the batch tab does. ONE engine x corpus core, replacing the per-corpus
capture_streamv1_versions.py.

Corpora (`--corpus`):
  batch      fixtures-batch-v1: vLLM/SGLang non-streaming `extract_tool_calls`
             over `inputs/<family>/TOOLCALLING.batch*.yaml`, diffed against the
             LOWEST `<impl>-<version>/` anchor's `expected.<impl>` {calls,
             normal_text} block. Writes changed-only top-level
             `fixtures-batch-v1/<impl>-<version>/<family>/TOOLCALLING.batch*.yaml`.
  stream     fixtures-stream-v1: per-chunk streaming deltas. Container engines
             (vllm_python/sglang_python) run capture.py in the engine container,
             diff each chunk against the lowest-version resolved anchor's
             per-chunk `expected.<impl>`/`normal_text.<impl>`, and write a
             changed-only full-case dir `fixtures-stream-v1/<impl>-<version>/`.
             vllm_rust runs the cargo probe over the
             shared `inputs/` cases, diffs whole cases against the lowest
             `vllm_rust-<version>/` anchor, and writes a full-chunk changed-case
             dir `fixtures-stream-v1/vllm_rust-<version>/`.
  reasoning  reasoning/fixtures-v1: vLLM/SGLang reasoning parser over
             `inputs/<family>/REASONING.{batch,stream}.yaml`, diffed against the
             inputs' `expected.<impl>` {reasoning_text, normal_text} anchor.
             Writes changed-only `<impl>-<version>/<family>/REASONING.{mode}.yaml`.

Engines (`--impl`):
  vllm_python   vLLM Python container (default vllm-localdev); tool-calling map
                capture_driver.VLLM, reasoning map _FAMILY_TO_VLLM_REASONING.
  sglang_python SGLang Python container (default sglang-localdev); tool-calling
                map capture_driver.SGLANG, reasoning map _FAMILY_TO_SGLANG_REASONING.
  vllm_rust     source-only cargo probe (stream corpus only; needs a vLLM source
                checkout via --vllm-rust-source / VLLM_RUST_SOURCE); map
                capture_driver.VLLM_RUST.

All engine versions are read LIVE at capture time (container `__version__` /
source tag), never hardcoded. Only cases that DIVERGE from the anchor are written,
unless `--replace-stream-case` explicitly records a recaptured stream case. Existing
version dirs are never touched; a same-version stream recapture writes the next `.patchN` overlay.

Usage:
  python3 capture_peer_versions.py --corpus batch                       # all impls
  python3 capture_peer_versions.py --corpus batch --impl sglang_python  # one impl
  python3 capture_peer_versions.py --corpus stream --impl vllm_rust \
      --vllm-rust-source ~/dev/vllm-0.25.1
  python3 capture_peer_versions.py --corpus reasoning --family qwen3
"""
import argparse
import glob
import os
import re
import shutil
import sys
import tempfile
from dataclasses import dataclass
from typing import Optional

import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
# This module lives in conformance/utils/src/, so the repo root is 3 up.
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(HERE)))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import capture_driver as cd  # noqa: E402  (parser maps + container/probe capture plumbing)
import capture_reasoning as cr  # noqa: E402  (reasoning worker + _container_run + _blocks_match)
import fixture_disposition  # noqa: E402  (append-only capture layer ordering)
import resolve_fixtures  # noqa: E402  (batch anchor resolution)
import resolve_stream_fixtures  # noqa: E402  (stream anchor staging)
import validate  # noqa: E402  (run_container ships the tool-calling parity adapter)
from tables.common import (  # noqa: E402  (shared family maps; moved from tests.parity.common)
    _FAMILY_TO_SGLANG_REASONING,
    _FAMILY_TO_VLLM_REASONING,
    canonical,
)


# --------------------------------------------------------------------------- #
# Engine specs. The engine axis is what SGLang batch/reasoning support adds to:
# a corpus loop asks the engine for its parser-family map and how to run one case.
# --------------------------------------------------------------------------- #
@dataclass
class EngineSpec:
    name: str  # canonical impl key + version-dir prefix (vllm_python / sglang_python / vllm_rust)
    short: str  # capture.py / adapter short name (vllm / sglang); "" for source-only
    tc_map: dict  # family -> tool-calling parser name for this engine
    reasoning_map: Optional[dict]  # family -> reasoning parser name (None: no reasoning path)
    corpora: frozenset  # which corpora this engine can run
    source_based: bool = False  # vllm_rust: cargo probe over a source checkout, no container

    def container(self, args) -> Optional[str]:
        if self.source_based:
            return None
        return getattr(args, f"{self.short}_container", None)


ENGINES = {
    "vllm_python": EngineSpec(
        name="vllm_python", short="vllm",
        tc_map=cd.VLLM, reasoning_map=_FAMILY_TO_VLLM_REASONING,
        corpora=frozenset({"batch", "stream", "reasoning"}),
    ),
    "sglang_python": EngineSpec(
        name="sglang_python", short="sglang",
        tc_map=cd.SGLANG, reasoning_map=_FAMILY_TO_SGLANG_REASONING,
        corpora=frozenset({"batch", "stream", "reasoning"}),
    ),
    "vllm_rust": EngineSpec(
        name="vllm_rust", short="",
        tc_map=cd.VLLM_RUST, reasoning_map=None,
        corpora=frozenset({"stream"}), source_based=True,
    ),
}


class _QuotedStr(str):
    """Version string forced to single-quoted YAML, matching the batch overlays'
    `captured_with: {<impl>: '<version>'}` shape."""


def _represent_quoted(dumper, data):
    return dumper.represent_scalar("tag:yaml.org,2002:str", str(data), style="'")


# Register on EVERY dumper `yaml.safe_dump` might use. yaml_fast patches safe_dump to
# route through CSafeDumper when libyaml is available, and importing any resolver pulls
# that patch in — so registering only on SafeDumper made _batch_write raise
# RepresenterError('cannot represent an object') before writing a single byte.
for _dumper in (yaml.SafeDumper, getattr(yaml, "CSafeDumper", None)):
    if _dumper is not None:
        _dumper.add_representer(_QuotedStr, _represent_quoted)

_SPDX = (
    "# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.\n"
    "# SPDX-License-Identifier: Apache-2.0\n"
)


def _report(impl, version, n_cases, n_files, families_touched, n_errored):
    print(f"[{impl}] version {version}: {n_cases} changed case(s) across {n_files} "
          f"file(s) in {len(families_touched)} family(ies); {n_errored} errored/carried-forward",
          file=sys.stderr)


# final `<impl>-<version>` root -> the staging dir its files are being written into.
_STAGED_VERSION_ROOTS: dict[str, str] = {}


def _version_outdir(fixtures_root, impl, version, family, append_patch=False):
    """The `<family>/` dir to write for this run's `<impl>-<version>` capture.

    Version dirs are append-only, and publication is ATOMIC: a run writes its whole
    version tree into a staging dir and `_publish_staged()` renames it into place only
    after the run succeeds. `os.rename` onto an existing non-empty directory fails with
    ENOTEMPTY, so the rename IS the claim -- two concurrent runs cannot both publish, and
    the loser fails instead of interleaving files into one half-old, half-new tree. A run
    that dies midway leaves only the staging dir; the final path never appears, so the
    next run starts clean rather than inheriting a partial capture.

    An `exists()` check alone was not enough: two processes both passed it and both wrote
    (verified -- a synchronized two-process repro had both claim the same root). The check
    below stays as the early, friendly error; the rename is what actually enforces it.

    Staging lives BESIDE the corpus, not inside it: package_fixtures.py shards every
    immediate subdir of a corpus via `iterdir()`, so a leftover staging dir inside the
    corpus would be published as a bogus shard.
    """
    root = os.path.join(fixtures_root, f"{impl}-{version}")
    if append_patch and os.path.exists(root):
        base_root, _base_patch = fixture_disposition.capture_layer_sort_key(os.path.basename(root))
        existing_patches = [
            fixture_disposition.capture_layer_sort_key(os.path.basename(path))[1]
            for path in glob.glob(f"{root}.patch*")
            if os.path.isdir(path)
        ]
        root = os.path.join(fixtures_root, f"{base_root}.patch{max(existing_patches, default=0) + 1}")
    staging_root = _STAGED_VERSION_ROOTS.get(root)
    if staging_root is None:
        if os.path.exists(root):
            raise SystemExit(
                f"{root} already exists. Version dirs are append-only; remove it "
                f"explicitly to re-record {impl}-{version}."
            )
        staging_root = f"{fixtures_root.rstrip('/')}.staging-{os.getpid()}/{impl}-{version}"
        shutil.rmtree(staging_root, ignore_errors=True)
        os.makedirs(staging_root)
        _STAGED_VERSION_ROOTS[root] = staging_root
    outdir = os.path.join(staging_root, family)
    os.makedirs(outdir, exist_ok=True)
    return outdir


def _publish_staged():
    """Move every staged version tree into its final path. Call ONCE, after the run has
    otherwise succeeded. The rename is atomic and fails if the final path already holds
    files, which is the concurrency guard."""
    for root, staging_root in sorted(_STAGED_VERSION_ROOTS.items()):
        try:
            os.rename(staging_root, root)
        except OSError as exc:
            raise SystemExit(
                f"cannot publish {root}: {exc}. Another run may have published it "
                f"first; the captured tree is left at {staging_root}."
            ) from exc
        parent = os.path.dirname(staging_root)
        if not os.listdir(parent):
            os.rmdir(parent)
    _STAGED_VERSION_ROOTS.clear()


def _lowest_impl_dir(fixtures_root, impl):
    """The lowest `<impl>-<version>` dir = that impl's full anchor (every case)."""
    vdirs = [
        d for d in glob.glob(os.path.join(fixtures_root, f"{impl}-*")) if os.path.isdir(d)
    ]
    if not vdirs:
        raise SystemExit(f"no {impl}-* anchor under {fixtures_root}")
    return min(
        vdirs,
        key=lambda d: resolve_fixtures.version_key(os.path.basename(d).split("-", 1)[1]),
    )


# =========================================================================== #
# Block corpora (batch, reasoning): per-case expected block, changed-only
# top-level version dir. One shared loop, two specs.
# =========================================================================== #
@dataclass
class BlockCorpus:
    name: str
    fixtures_root_rel: str
    require_anchor: bool  # reasoning skips cases with no valid anchor; batch writes them

    def fixtures_root(self, root):
        return os.path.join(root, self.fixtures_root_rel)

    # --- filled in per corpus below ---
    build_anchor: object = None       # (engine, fixtures_root, work) -> ({(fam,base,cid): block}, desc)
    run_all: object = None            # (engine, container, fixtures_root, families, work) -> (result, version)
    is_error: object = None           # (cap) -> bool
    captured_matches: object = None   # (cap, anchor_block) -> bool
    changed_block: object = None      # (engine, cap) -> dict
    write: object = None              # (fixtures_root, engine, version, family, base, mode, changed)


def _run_block(corpus: BlockCorpus, engine: EngineSpec, args):
    fixtures_root = corpus.fixtures_root(args.root)
    work = args.work or tempfile.mkdtemp(prefix=f"{corpus.name}_ver_")
    os.makedirs(work, exist_ok=True)
    container = engine.container(args)

    anchor, desc = corpus.build_anchor(engine, fixtures_root, work)
    print(f"[{engine.name}] anchor = {desc} ({len(anchor)} baseline cases)", file=sys.stderr)

    # `--family` is ONE name; the hooks take a list. Normalize here, or they iterate the
    # string character by character ('qwen3' -> q,w,e,n,3), match nothing, and report a
    # clean "no cases" instead of failing.
    families = [args.family] if args.family else None
    result, version = corpus.run_all(engine, container, fixtures_root, families, work)
    if not result:
        print(f"[{engine.name}] no input cases; nothing to do", file=sys.stderr)
        return
    print(f"[{engine.name}] engine version {version}", file=sys.stderr)

    n_files = n_cases = n_errored = 0
    families_touched = set()
    for (family, base, mode), caps in sorted(result.items()):
        changed = {}
        for cid, cap in caps.items():
            anchor_block = anchor.get((family, base, cid))
            if corpus.require_anchor and anchor_block is None:
                continue
            if corpus.is_error(cap):
                n_errored += 1
                print(f"  [{engine.name}] {family}/{base} {cid}: parser error, carried forward",
                      file=sys.stderr)
                continue
            if anchor_block is not None and corpus.captured_matches(cap, anchor_block):
                continue
            changed[cid] = corpus.changed_block(engine, cap)
        if not changed:
            continue
        corpus.write(fixtures_root, engine, version, family, base, mode, changed)
        n_files += 1
        n_cases += len(changed)
        families_touched.add(family)
        print(f"  [{engine.name}] wrote {family}/{base} ({len(changed)} changed case(s))",
              file=sys.stderr)

    _report(engine.name, version, n_cases, n_files, families_touched, n_errored)


# --------------------------------------------------------------------------- #
# batch corpus hooks
# --------------------------------------------------------------------------- #
def _batch_build_anchor(engine, fixtures_root, work):
    """Fold the lowest `<impl>-<version>` dir onto inputs and return
    {(family, base, cid): {calls, normal_text}} baseline blocks."""
    lowest = os.path.basename(_lowest_impl_dir(fixtures_root, engine.name)).split("-", 1)[1]
    staged = os.path.join(work, "baseline")
    resolve_fixtures.resolve(fixtures_root, staged, [f"{engine.name}-{lowest}"])
    baseline = {}
    for fp in sorted(glob.glob(os.path.join(staged, "*", "*.yaml"))):
        family = os.path.basename(os.path.dirname(fp))
        base = os.path.basename(fp)
        doc = yaml.safe_load(open(fp))
        for cid, case in (doc.get("cases") or {}).items():
            if not isinstance(case, dict):
                continue
            exp = (case.get("expected") or {}).get(engine.name)
            if isinstance(exp, dict) and "unavailable" not in exp:
                baseline[(family, base, cid)] = {
                    "calls": exp.get("calls", []),
                    "normal_text": exp.get("normal_text"),
                }
    return baseline, f"{engine.name}-{lowest}"


def _batch_run_all(engine, container, fixtures_root, families, work):
    """Every input batch case with a model_text through the engine's batch parser,
    grouped as {(family, base, 'batch'): {cid: cap}}."""
    version = validate.engine_version(engine.short, container)
    if not version:
        raise SystemExit(f"could not read {engine.short} version from {container}")
    inputs = os.path.join(fixtures_root, "inputs")
    fam_dirs = families or sorted(
        d for d in os.listdir(inputs) if os.path.isdir(os.path.join(inputs, d))
    )
    cases, by_file = [], {}
    for family in fam_dirs:
        for fp in sorted(glob.glob(os.path.join(inputs, family, "TOOLCALLING.batch*.yaml"))):
            base = os.path.basename(fp)
            doc = yaml.safe_load(open(fp))
            fam = doc["family"]
            for cid, case in (doc.get("cases") or {}).items():
                if not isinstance(case, dict) or "model_text" not in case:
                    continue
                key = f"{fam}/{base}/{cid}"
                cases.append({
                    "key": key, "family": fam, "mode": "batch",
                    "tools": case.get("tools"), "model_text": case.get("model_text"),
                })
                by_file.setdefault((fam, base, "batch"), []).append((cid, key))
    if not cases:
        return {}, version
    print(f"[{engine.name}] capturing {len(cases)} batch cases in {container} (1 import)...",
          file=sys.stderr)
    got = validate.run_container(engine.short, container, cases)
    result = {}
    for key3, cids in by_file.items():
        d = {}
        for cid, jobkey in cids:
            cap = got.get(jobkey)
            if cap is not None:
                d[cid] = cap
        result[key3] = d
    return result, version


def _batch_matches(cap, anchor_block):
    captured = {"calls": cap.get("calls", []), "normal_text": cap.get("normal_text")}
    return canonical(captured) == canonical(anchor_block)


def _batch_changed_block(engine, cap):
    # vLLM emits None for "no narration"; the corpus renders that as '' — normalize
    # so the stored shape matches (the diff already treats ''/None equal via canonical).
    return {"expected": {engine.name: {
        "calls": cap.get("calls", []),
        "normal_text": cap.get("normal_text") or "",
    }}}


def _batch_write(fixtures_root, engine, version, family, base, mode, changed):
    outdir = _version_outdir(fixtures_root, engine.name, version, family)
    out = {
        "family": family, "mode": "batch",
        "captured_with": {engine.name: _QuotedStr(version)},
        "cases": changed,
    }
    with open(os.path.join(outdir, base), "w") as f:
        f.write(_SPDX)
        f.write("# Version overlay (changed-only): cases where this impl@version diverges from baseline.\n")
        yaml.safe_dump(out, f, allow_unicode=True, sort_keys=False, default_flow_style=False)


BATCH = BlockCorpus(
    name="batch",
    fixtures_root_rel="conformance/toolcalling/fixtures-batch-v1",
    require_anchor=False,
    build_anchor=_batch_build_anchor,
    run_all=_batch_run_all,
    is_error=lambda cap: bool(cap.get("error")),
    captured_matches=_batch_matches,
    changed_block=_batch_changed_block,
    write=_batch_write,
)


# --------------------------------------------------------------------------- #
# reasoning corpus hooks
# --------------------------------------------------------------------------- #
def _reasoning_build_anchor(engine, fixtures_root, work):
    """The inputs' `expected.<impl>` {reasoning_text, normal_text} blocks are the
    anchor; only cases with a real (non-unavailable) block AND a parser input count."""
    inputs = os.path.join(fixtures_root, "inputs")
    baseline = {}
    for fp in sorted(glob.glob(os.path.join(inputs, "*", "REASONING.*.yaml"))):
        family = os.path.basename(os.path.dirname(fp))
        base = os.path.basename(fp)
        doc = yaml.safe_load(open(fp))
        for cid, case in (doc.get("cases") or {}).items():
            if not isinstance(case, dict) or "expected" not in case:
                continue
            b = (case.get("expected") or {}).get(engine.name)
            if not isinstance(b, dict) or "unavailable" in b:
                continue
            if "model_text" not in case and "chunks" not in case:
                continue
            baseline[(family, base, cid)] = b
    return baseline, "inputs/"


def _reasoning_run_all(engine, container, fixtures_root, families, work):
    """Drive the engine's reasoning parser over each inputs REASONING.{mode}.yaml,
    grouped as {(family, base, mode): {cid: cap}}. Families without a parser and
    whole-fixture failures are skipped (carried forward)."""
    inputs = os.path.join(fixtures_root, "inputs")
    fam_dirs = families or sorted(
        d for d in os.listdir(inputs) if os.path.isdir(os.path.join(inputs, d))
    )
    result, version = {}, None
    no_parser = []
    for family in fam_dirs:
        parser = engine.reasoning_map.get(family)
        if parser is None:
            no_parser.append(family)
            continue
        for mode in ("batch", "stream"):
            fixture = os.path.join(inputs, family, f"REASONING.{mode}.yaml")
            if not os.path.exists(fixture):
                continue
            try:
                captured = cr._container_run(container, engine.short, fixture, parser)
            except Exception as e:  # noqa: BLE001 - whole-fixture failure, carry forward
                print(f"  [{engine.name}] {family}/REASONING.{mode}: capture error, carried "
                      f"forward ({str(e)[:120]})", file=sys.stderr)
                continue
            version = captured["version"]
            base = f"REASONING.{mode}.yaml"
            result[(family, base, mode)] = dict(captured["cases"])
    if no_parser:
        print(f"[{engine.name}] no reasoning parser (skipped): {', '.join(no_parser)}",
              file=sys.stderr)
    return result, version


def _reasoning_changed_block(engine, cap):
    # Render "absent text" as '' (None -> '') to match the anchor overlay shape;
    # _blocks_match already treats ''/None equal for the diff decision.
    return {"expected": {engine.name: {
        "reasoning_text": cap.get("reasoning_text") or "",
        "normal_text": cap.get("normal_text") or "",
    }}}


def _reasoning_write(fixtures_root, engine, version, family, base, mode, changed):
    outdir = _version_outdir(fixtures_root, engine.name, version, family)
    out = {"family": family, "mode": mode, "cases": changed}
    with open(os.path.join(outdir, base), "w") as f:
        f.write(_SPDX)
        f.write(f"# Changed-only {engine.short} {version} reasoning overlay (vs the inputs/ anchor).\n")
        yaml.safe_dump(out, f, allow_unicode=True, sort_keys=False, default_flow_style=False)


REASONING = BlockCorpus(
    name="reasoning",
    fixtures_root_rel="conformance/reasoning/fixtures-v1",
    require_anchor=True,
    build_anchor=_reasoning_build_anchor,
    run_all=_reasoning_run_all,
    is_error=lambda cap: "error" in cap,
    captured_matches=lambda cap, anchor_block: cr._blocks_match(cap, anchor_block),
    changed_block=_reasoning_changed_block,
    write=_reasoning_write,
)


# =========================================================================== #
# stream corpus: per-chunk deltas. Container engines write a per-chunk overlay;
# vllm_rust writes a full-chunk changed-case dir.
# =========================================================================== #
STREAM_ROOT_REL = "conformance/toolcalling/fixtures-stream-v1"

# gemma4 keeps a `vllm_rust` parser name in parser_families.yaml, but vLLM 0.25.0
# turned it into a native unified parser not reachable through the tool::ToolParser
# probe, so it is recorded unavailable with this explicit note rather than dropped.
GEMMA4_UNAVAILABLE = (
    "gemma4 moved to the native unified parser in vLLM 0.25.0; "
    "not exposed via the tool::ToolParser probe."
)


# --- container engines (vllm_python / sglang_python): streamv1-overlay format --- #
def _ov_norm_deltas(deltas):
    """Canonical per-chunk delta list for the streamv1-overlay format (raw dicts,
    keeping id): YAML and JSON load id/name/arguments the same way, so plain
    dict/list equality works once both sides are lists of dicts."""
    return [dict(d) for d in (deltas or []) if isinstance(d, dict)]


def _anchor_chunk_impl(chunk, impl):
    """(deltas, normal_text) the resolved anchor recorded for `impl` at this chunk."""
    exp = chunk.get("expected") or {}
    nt = chunk.get("normal_text") or {}
    return _ov_norm_deltas(exp.get(impl)), (nt.get(impl) or "")


def _stream_capture_cases(anchor_doc, force_case_ids):
    # The packager permits only explicitly approved cases in a correction patch.
    for cid, case in (anchor_doc.get("cases") or {}).items():
        if not force_case_ids or cid in force_case_ids:
            yield cid, case


def _changed_stream_cases(anchor_doc, captured_cases, impl, force_case_ids=frozenset()):
    """Return changed cases, or only explicitly requested corrections, plus error IDs.

    FULL chunk lists, not just the differing indices. resolve_stream_fixtures folds a
    version dir by CLEARING the impl from every anchor chunk and then applying that
    version's `chunks` list, so a body keyed by chunk index resolves to nothing at all:
    the capture reported changed cases, the shards shipped, and the table silently
    rendered the anchor while stamping the newer version. Same shape the vllm_rust
    writer emits, so both stream writers serialize identically.
    """
    changed_cases, errored = {}, []
    for cid, case in _stream_capture_cases(anchor_doc, force_case_ids):
        if impl in (case.get("unavailable") or {}):
            continue
        cap = captured_cases.get(cid)
        if cap is None:
            continue
        if any(isinstance(c, dict) and c.get("error") for c in cap):
            errored.append(cid)
            continue
        chunks, differs = [], False
        for idx, anchor_chunk in enumerate(case.get("chunks") or []):
            if not isinstance(anchor_chunk, dict) or idx >= len(cap):
                break
            a_deltas, a_nt = _anchor_chunk_impl(anchor_chunk, impl)
            c_deltas = _ov_norm_deltas(cap[idx].get("deltas"))
            c_nt = cap[idx].get("normal_text") or ""
            entry = {"expected": c_deltas}
            if c_nt:
                entry["normal_text"] = c_nt
            chunks.append(entry)
            if c_deltas != a_deltas or c_nt != a_nt:
                differs = True
        if differs or cid in force_case_ids:
            changed_cases[cid] = {"chunks": chunks}
    return changed_cases, errored


def _run_stream_container(engine, args):
    """vLLM Python / SGLang Python stream capture -> changed-only per-chunk overlay
    under fixtures-stream-v1/overlays/<impl>-<version>/."""
    sv1_root = os.path.join(args.root, STREAM_ROOT_REL)
    work = args.work or tempfile.mkdtemp(prefix="streamv1_ver_")
    os.makedirs(work, exist_ok=True)
    container = engine.container(args)

    # The anchor is the lowest-version-per-impl resolved tree: each chunk carries
    # per-impl `expected`/`normal_text` PLUS the shared delta_text the parser reads.
    staged = os.path.join(work, "anchor")
    resolve_stream_fixtures.resolve(sv1_root, staged, [])

    families = [args.family] if args.family else sorted(engine.tc_map.keys())
    anchor_files = {}
    for family in families:
        fs = sorted(glob.glob(os.path.join(staged, family, "TOOLCALLING.streamv1.*.yaml")))
        if fs:
            anchor_files[family] = fs

    jobs, job_family = [], {}
    for family, files in anchor_files.items():
        parser = engine.tc_map.get(family)
        if not parser:
            continue
        for fp in files:
            jobs.append({"src": fp, "container_path": cd._cpath(fp, "stream"), "parser": parser})
            job_family[fp] = family
    if not jobs:
        print(f"[{engine.name}] no fixtures with a parser; skipping", file=sys.stderr)
        return

    cd._copy_worker((container,))
    print(f"[{engine.name}] capturing {len(jobs)} fixtures in {container} (1 import)...",
          file=sys.stderr)
    version, caps = cd._container_capture(container, engine.short, "stream", jobs, work)
    print(f"[{engine.name}] engine version {version}", file=sys.stderr)

    n_files = n_cases = n_errored = 0
    families_touched = set()
    forced_cases_written = set()
    force_case_ids = set(args.replace_stream_case)
    for fp, family in job_family.items():
        entry = caps.get(fp, {})
        if "cases" not in entry:
            print(f"  [{engine.name}] {family}/{os.path.basename(fp)}: capture error, carried "
                  f"forward ({str(entry.get('error', '?'))[:120]})", file=sys.stderr)
            n_errored += 1
            continue
        anchor_doc = yaml.safe_load(open(fp))
        changed_cases, errored = _changed_stream_cases(
            anchor_doc, entry["cases"], engine.name, force_case_ids
        )
        forced_cases_written.update(force_case_ids & changed_cases.keys())
        n_errored += len(errored)
        if not changed_cases:
            continue
        outdir = _version_outdir(sv1_root, engine.name, version, family, append_patch=True)
        out = {
            "family": family, "mode": "streamv1",
            "captured_with": {engine.name: version},
            "cases": changed_cases,
        }
        with open(os.path.join(outdir, os.path.basename(fp)), "w") as f:
            yaml.safe_dump(out, f, allow_unicode=True, sort_keys=False, width=4096)
        n_files += 1
        n_cases += len(changed_cases)
        families_touched.add(family)
        print(f"  [{engine.name}] wrote {family}/{os.path.basename(fp)} "
              f"({len(changed_cases)} changed case(s))", file=sys.stderr)

    _report(engine.name, version, n_cases, n_files, families_touched, n_errored)
    missing_forced_cases = force_case_ids - forced_cases_written
    if missing_forced_cases:
        raise SystemExit(f"requested stream cases were not captured: {sorted(missing_forced_cases)}")


# --- vllm_rust: full-chunk changed-case streamv1 dir --- #
def _clean_version(raw):
    """'v0.25.1 <sha>' -> '0.25.1' (dir name + captured_with stamp)."""
    return raw.split()[0].lstrip("v") if raw else raw


def _rust_norm_deltas(deltas):
    """Probe/anchor delta list -> canonical [{index, name?, arguments?}] for diff and
    serialization (drop absent name/arguments and the id flag, keep first-seen order)."""
    out = []
    for d in deltas or []:
        if not isinstance(d, dict):
            continue
        e = {"index": d["index"]}
        if d.get("name") is not None:
            e["name"] = d["name"]
        if d.get("arguments") is not None:
            e["arguments"] = d["arguments"]
        out.append(e)
    return out


def _rust_anchor_case_form(case):
    """Comparable form of vllm_rust's projection of one resolved anchor case."""
    unavailable = case.get("unavailable") or {}
    if "vllm_rust" in unavailable:
        return ("unavail",)
    exception = (case.get("exception") or {}).get("vllm_rust")
    if exception is not None:
        return ("exception", exception)
    chunks = []
    for chunk in case.get("chunks") or []:
        if not isinstance(chunk, dict):
            continue
        deltas, normal_text = _anchor_chunk_impl(chunk, "vllm_rust")
        chunks.append((_rust_norm_deltas(deltas), normal_text))
    return ("chunks", chunks)


def _rust_captured_case_form(cap):
    """Comparable form of one probe case result (chunk list or {error}). A probe
    `{error}` is a parser that RAN and threw -> `exception` (carry the message)."""
    if isinstance(cap, dict):  # {"error": ...}
        return ("exception", cap["error"])
    return ("chunks", [(_rust_norm_deltas(ch.get("deltas")), ch.get("normal_text") or "") for ch in cap])


def _rust_captured_case_doc(cap):
    """0.23.0-shaped case dict for the overlay from one probe case result. A thrown
    parser is recorded as a verbatim `exception` (the named `ToolParserError` variant),
    NOT `unavailable` — the parser exists and ran, it just failed on this input."""
    if isinstance(cap, dict):  # {"error": ...}
        return {"exception": cap["error"]}
    chunks = []
    for ch in cap:
        entry = {"expected": _rust_norm_deltas(ch.get("deltas"))}
        nt = ch.get("normal_text") or ""
        if nt:
            entry["normal_text"] = nt
        chunks.append(entry)
    return {"chunks": chunks}


def _run_stream_rust(engine, args):
    """vLLM Rust cargo-probe stream capture -> full-chunk changed-case dir
    fixtures-stream-v1/vllm_rust-<version>/ (diffed against the lowest vllm_rust anchor)."""
    source = args.vllm_rust_source or os.environ.get("VLLM_RUST_SOURCE")
    if not source:
        raise SystemExit("--vllm-rust-source or VLLM_RUST_SOURCE is required for vllm_rust")
    sv1 = os.path.join(args.root, STREAM_ROOT_REL)
    inputs_root = os.path.join(sv1, "inputs")
    work = args.work or tempfile.mkdtemp(prefix="vllm_rust_ver_")
    os.makedirs(work, exist_ok=True)
    anchor_root = os.path.join(work, "anchor")
    resolve_stream_fixtures.resolve(sv1, anchor_root, [])

    families = sorted(engine.tc_map)
    if args.family:
        families = [f for f in families if f == args.family]

    jobs, job_meta = [], {}
    for family in families:
        parser = engine.tc_map[family]
        for fp in sorted(glob.glob(os.path.join(inputs_root, family, "TOOLCALLING.streamv1.*.yaml"))):
            jobs.append({"src": fp, "parser": parser})
            job_meta[fp] = (family, os.path.basename(fp))
    if not jobs:
        raise SystemExit("no vllm_rust stream inputs found")

    print(f"[vllm_rust] capturing {len(jobs)} fixtures through the vLLM Rust probe...",
          file=sys.stderr)
    raw_version, caps = cd._vllm_rust_capture(source, "stream", jobs, work)
    version = _clean_version(raw_version)
    print(f"[vllm_rust] vLLM Rust source {raw_version} -> version {version}", file=sys.stderr)

    n_files = n_cases = n_errored = n_missing_anchor = 0
    families_touched = set()
    forced_cases_written = set()
    force_case_ids = set(args.replace_stream_case)
    for fp, (family, base) in job_meta.items():
        entry = caps.get(fp, {})
        if "cases" not in entry:
            print(f"  [vllm_rust] {family}/{base}: whole-fixture capture error "
                  f"({str(entry.get('error'))[:120]})", file=sys.stderr)
            n_errored += 1
            continue
        anchor_fp = os.path.join(anchor_root, family, base)
        if not os.path.exists(anchor_fp):
            n_missing_anchor += 1
            print(f"  [vllm_rust] {family}/{base}: no anchor; skipping", file=sys.stderr)
            continue
        anchor_doc = yaml.safe_load(open(anchor_fp))
        changed = {}
        for cid, anchor_case in _stream_capture_cases(anchor_doc, force_case_ids):
            cap = entry["cases"].get(cid)
            if cap is None:
                continue
            if (
                _rust_captured_case_form(cap) != _rust_anchor_case_form(anchor_case)
                or cid in force_case_ids
            ):
                changed[cid] = ({"unavailable": GEMMA4_UNAVAILABLE} if family == "gemma4"
                                else _rust_captured_case_doc(cap))
                forced_cases_written.update(force_case_ids & {cid})
        if not changed:
            continue
        outdir = _version_outdir(sv1, "vllm_rust", version, family, append_patch=True)
        doc = {
            "family": family, "mode": "streamv1",
            "captured_with": {"vllm_rust": version}, "cases": changed,
        }
        with open(os.path.join(outdir, base), "w") as f:
            yaml.safe_dump(doc, f, allow_unicode=True, sort_keys=False, width=4096)
        n_files += 1
        n_cases += len(changed)
        families_touched.add(family)

    print(f"[vllm_rust] wrote vllm_rust-{version}: {n_cases} changed case(s) across {n_files} "
          f"file(s) in {len(families_touched)} family(ies); {n_missing_anchor} without an anchor",
          file=sys.stderr)
    missing_forced_cases = force_case_ids - forced_cases_written
    if missing_forced_cases:
        raise SystemExit(f"requested stream cases were not captured: {sorted(missing_forced_cases)}")


def _run_stream(engine: EngineSpec, args):
    if engine.source_based:
        _run_stream_rust(engine, args)
    else:
        _run_stream_container(engine, args)


# stream is NOT here: _run_stream branches before this lookup.
CORPORA = {"batch": BATCH, "reasoning": REASONING}


def main():
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    ap.add_argument("--corpus", required=True, choices=("batch", "stream", "reasoning"))
    ap.add_argument("--impl", choices=tuple(ENGINES),
                    help="capture only this engine (default: all engines valid for the corpus)")
    ap.add_argument("--root", default=ROOT, help="repo root (default: src/../../..)")
    ap.add_argument("--family", help="capture only this family (default: all)")
    ap.add_argument("--vllm-container", default="vllm-localdev")
    ap.add_argument("--sglang-container", default="sglang-localdev")
    ap.add_argument("--vllm-rust-source", help="vLLM source checkout root; defaults to VLLM_RUST_SOURCE")
    ap.add_argument("--work", help="work dir (default: a fresh temp dir)")
    ap.add_argument(
        "--replace-stream-case",
        action="append",
        default=[],
        metavar="CASE_ID",
        help="force this stream result into the next append-only patch for its existing capture version",
    )
    args = ap.parse_args()

    invalid_replacements = [
        case_id
        for case_id in args.replace_stream_case
        if re.fullmatch(r"TOOLCALLING\.streamv1\.\d+(?:-\d+)?(?:\.[a-z][a-z0-9_-]*)*", case_id) is None
    ]
    if args.replace_stream_case and args.corpus != "stream":
        ap.error("--replace-stream-case requires --corpus stream")
    if args.replace_stream_case and not args.family:
        ap.error("--replace-stream-case requires --family because case IDs recur across model families")
    if invalid_replacements:
        ap.error(f"invalid stream case IDs: {invalid_replacements}")

    corpus = args.corpus
    if args.impl:
        impls = [args.impl]
        if corpus not in ENGINES[args.impl].corpora:
            raise SystemExit(f"--impl {args.impl} does not support --corpus {corpus} "
                             f"(supported: {', '.join(sorted(ENGINES[args.impl].corpora))})")
    else:
        impls = [name for name, spec in ENGINES.items() if corpus in spec.corpora]

    for name in impls:
        engine = ENGINES[name]
        if corpus == "stream":
            _run_stream(engine, args)
        else:
            _run_block(CORPORA[corpus], engine, args)
    # Publish ONLY after every engine finished. Anything that raises above leaves the
    # staging trees untouched and no `<impl>-<version>/` on disk, so a failed run cannot
    # leave a half-written version dir behind for the next run to inherit.
    _publish_staged()


if __name__ == "__main__":
    main()
